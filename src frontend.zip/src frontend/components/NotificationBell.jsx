import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';

const NotificationBell = ({ refreshTrigger }) => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  const fetchUnreadCount = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;
      const response = await axios.get('/notifications/unread-count', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setUnreadCount(response.data);
    } catch (error) {
      setUnreadCount(0);
    }
  };

  const fetchNotifications = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) return;

      const response = await axios.get('/notifications', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const notificationData = response.data;
      setNotifications(notificationData);
      await fetchUnreadCount();
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
    }
  };

  // Initial fetch and polling every 5 seconds for near real-time updates
  useEffect(() => {
    fetchNotifications();

    const interval = setInterval(() => {
      fetchNotifications();
    }, 5000); // 5 seconds for near real-time

    // Listen for custom event to refresh bell instantly
    const handler = () => fetchNotifications();
    window.addEventListener('refresh-bell', handler);

    return () => {
      clearInterval(interval);
      window.removeEventListener('refresh-bell', handler);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Fetch notifications when refreshTrigger changes
  useEffect(() => {
    fetchNotifications();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshTrigger]);

  // When bell is clicked, redirect to notifications page
  const handleBellClick = () => {
    navigate('/notifications');
  };

  const markAsRead = async (notificationId) => {
    try {
      const token = localStorage.getItem('token');
      // Optimistically update state
      setNotifications((prev) =>
        prev.map((n) =>
          n.id === notificationId ? { ...n, read: true, isRead: true } : n
        )
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
      await axios.put(
        `/notifications/${notificationId}/read`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // Always fetch latest notifications from backend
      await fetchNotifications();
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Bell Button */}
      <button
        ref={dropdownRef}
        onClick={handleBellClick}
        className="relative focus:outline-none"
        aria-label="Notifications"
      >
        {/* Professional SVG bell icon */}
        <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7 text-gray-700 dark:text-gray-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
        </svg>
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-600 text-white rounded-full text-xs px-2 py-0.5 font-bold min-w-[20px] text-center">
            {unreadCount}
          </span>
        )}
      </button>
    </div>
  );
};

export default NotificationBell;

