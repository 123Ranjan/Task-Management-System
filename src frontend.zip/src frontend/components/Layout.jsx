import React from 'react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 transition-colors duration-200">
      <Navbar />
      <Sidebar />
      <main className="pt-16 pl-64 transition-all duration-300">
        <div className="p-6">{children}</div>
      </main>
    </div>
  );
};

export default Layout;

