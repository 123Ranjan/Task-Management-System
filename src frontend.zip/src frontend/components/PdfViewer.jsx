import React from 'react';

// Usage: <PdfViewer pdfUrl={backendProxyUrl} />
const PdfViewer = ({ pdfUrl }) => {
  return (
    <iframe
      src={pdfUrl}
      title="PDF Viewer"
      width="100%"
      height="600px"
      style={{ border: 'none' }}
      allowFullScreen
    />
  );
};

export default PdfViewer;
