import React, { useState, useEffect } from 'react';
import axios from '../api/axios';
import { toast } from 'react-toastify';

const IssueLinkModal = ({ isOpen, onClose, issueId, onLinkAdded }) => {
  const [issues, setIssues] = useState([]);
  const [links, setLinks] = useState([]);
  const [loadingIssues, setLoadingIssues] = useState(true);
  const [loadingLinks, setLoadingLinks] = useState(true);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState(null);

  // Link form state
  const [linkForm, setLinkForm] = useState({
    targetIssueId: '',
    linkType: 'RELATES_TO',
  });

  const linkTypes = [
    { value: 'RELATES_TO', label: 'Relates to' },
    { value: 'BLOCKS', label: 'Blocks' },
    { value: 'BLOCKED_BY', label: 'Blocked by' },
    { value: 'DUPLICATES', label: 'Duplicates' },
    { value: 'DUPLICATED_BY', label: 'Duplicated by' },
    { value: 'PARENT_OF', label: 'Parent of' },
    { value: 'CHILD_OF', label: 'Child of' },
  ];

  const fetchIssues = async () => {
    setLoadingIssues(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/issues', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      // Filter out the current issue from the dropdown
      const filteredIssues = response.data.filter(
        (issue) => issue.id.toString() !== issueId.toString()
      );
      setIssues(filteredIssues);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to fetch issues.';
      toast.error(errorMessage);
    } finally {
      setLoadingIssues(false);
    }
  };

  const fetchLinks = async () => {
    setLoadingLinks(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/issues/${issueId}/links`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setLinks(response.data);
    } catch (error) {
      // Links endpoint might not exist, silently handle
      console.error('Failed to fetch links:', error);
      setLinks([]);
    } finally {
      setLoadingLinks(false);
    }
  };

  useEffect(() => {
    if (isOpen && issueId) {
      fetchIssues();
      fetchLinks();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, issueId]);

  const handleCreateLink = async (e) => {
    e.preventDefault();
    if (!linkForm.targetIssueId) {
      toast.error('Please select an issue to link.');
      return;
    }

    setCreating(true);

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        '/issuelink',
        {
          sourceIssueId: issueId,
          targetIssueId: linkForm.targetIssueId,
          linkType: linkForm.linkType,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Issue linked successfully!');
      setLinkForm({ targetIssueId: '', linkType: 'RELATES_TO' });
      fetchLinks();
      if (onLinkAdded) onLinkAdded();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to link issue.';
      toast.error(errorMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleDeleteLink = async (linkId) => {
    setDeleting(linkId);

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/issuelink/${linkId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Link removed successfully!');
      fetchLinks();
      if (onLinkAdded) onLinkAdded();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to remove link.';
      toast.error(errorMessage);
    } finally {
      setDeleting(null);
    }
  };

  const getLinkTypeLabel = (type) => {
    const linkType = linkTypes.find((lt) => lt.value === type);
    return linkType ? linkType.label : type;
  };

  const getLinkTypeColor = (type) => {
    const colors = {
      RELATES_TO: 'bg-blue-100 text-blue-700',
      BLOCKS: 'bg-red-100 text-red-700',
      BLOCKED_BY: 'bg-orange-100 text-orange-700',
      DUPLICATES: 'bg-purple-100 text-purple-700',
      DUPLICATED_BY: 'bg-purple-100 text-purple-700',
      PARENT_OF: 'bg-green-100 text-green-700',
      CHILD_OF: 'bg-teal-100 text-teal-700',
    };
    return colors[type] || 'bg-gray-100 text-gray-700';
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg mx-4 max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b">
          <h2 className="text-xl font-semibold text-gray-800">Link Issues</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700 text-2xl"
          >
            ×
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1">
          {/* Create Link Form */}
          <form onSubmit={handleCreateLink} className="mb-6">
            <h3 className="text-sm font-semibold text-gray-700 mb-3">
              Create New Link
            </h3>
            <div className="space-y-3">
              <div>
                <label
                  htmlFor="linkType"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Link Type
                </label>
                <select
                  id="linkType"
                  value={linkForm.linkType}
                  onChange={(e) =>
                    setLinkForm({ ...linkForm, linkType: e.target.value })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {linkTypes.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label
                  htmlFor="targetIssue"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Target Issue
                </label>
                {loadingIssues ? (
                  <div className="text-sm text-gray-500 py-2">
                    Loading issues...
                  </div>
                ) : (
                  <select
                    id="targetIssue"
                    value={linkForm.targetIssueId}
                    onChange={(e) =>
                      setLinkForm({ ...linkForm, targetIssueId: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select an issue...</option>
                    {issues.map((issue) => (
                      <option key={issue.id} value={issue.id}>
                        {issue.title || issue.name} (#{issue.id})
                      </option>
                    ))}
                  </select>
                )}
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={creating || !linkForm.targetIssueId}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors disabled:bg-blue-400 disabled:cursor-not-allowed"
                >
                  {creating ? 'Linking...' : 'Link Issue'}
                </button>
              </div>
            </div>
          </form>

          {/* Existing Links */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-3">
              Existing Links
            </h3>
            {loadingLinks ? (
              <div className="text-center py-4 text-gray-600">
                Loading links...
              </div>
            ) : links.length === 0 ? (
              <div className="text-center py-4 text-gray-500 bg-gray-50 rounded-md">
                No linked issues yet.
              </div>
            ) : (
              <div className="space-y-2">
                {links.map((link) => (
                  <div
                    key={link.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-md"
                  >
                    <div className="flex items-center space-x-3">
                      <span
                        className={`px-2 py-1 text-xs font-semibold rounded ${getLinkTypeColor(
                          link.linkType || link.type
                        )}`}
                      >
                        {getLinkTypeLabel(link.linkType || link.type)}
                      </span>
                      <div>
                        <p className="font-medium text-gray-800">
                          {link.targetIssue?.title ||
                            link.linkedIssue?.title ||
                            link.targetIssueName ||
                            `Issue #${link.targetIssueId || link.linkedIssueId}`}
                        </p>
                        {(link.targetIssue?.id || link.linkedIssue?.id || link.targetIssueId) && (
                          <p className="text-sm text-gray-500">
                            #{link.targetIssue?.id || link.linkedIssue?.id || link.targetIssueId}
                          </p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteLink(link.id)}
                      disabled={deleting === link.id}
                      className="text-red-600 hover:text-red-800 p-1 rounded hover:bg-red-50 transition-colors disabled:opacity-50"
                      title="Remove link"
                    >
                      {deleting === link.id ? (
                        <span className="text-sm">...</span>
                      ) : (
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          className="h-5 w-5"
                          viewBox="0 0 20 20"
                          fill="currentColor"
                        >
                          <path
                            fillRule="evenodd"
                            d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                            clipRule="evenodd"
                          />
                        </svg>
                      )}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t bg-gray-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default IssueLinkModal;

