import React, { useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import NotificationBell from './NotificationBell';
import { ThemeToggleButton } from './ThemeToggle';
import { isAdmin } from '../utils/permissions';
import axios from '../api/axios';

const Navbar = () => {
  const navigate = useNavigate();
  const username = localStorage.getItem('username') || 'User';
  const admin = isAdmin();

  // Add a state for refreshBell if not using context
  const [refreshBell, setRefreshBell] = React.useState(0);

  // --- Autocomplete Search State ---
  const [search, setSearch] = React.useState('');
  const [suggestions, setSuggestions] = React.useState([]); // {type, id, label, extra}
  const [showDropdown, setShowDropdown] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [highlighted, setHighlighted] = React.useState(-1);
  const inputRef = useRef();
  const dropdownRef = useRef();
  let debounceTimeout = useRef();

  // Listen for custom event to refresh bell
  useEffect(() => {
    const handler = () => setRefreshBell((r) => r + 1);
    window.addEventListener('refresh-bell', handler);
    return () => window.removeEventListener('refresh-bell', handler);
  }, []);

  // Debounced search
  useEffect(() => {
    if (!search) {
      setSuggestions([]);
      setShowDropdown(false);
      return;
    }
    setLoading(true);
    if (debounceTimeout.current) clearTimeout(debounceTimeout.current);
    debounceTimeout.current = setTimeout(async () => {
      try {
        const token = localStorage.getItem('token');
        // Use backend search endpoints for advanced search
        const [boardsRes, issuesRes] = await Promise.all([
          axios.get(`/boards/search?q=${encodeURIComponent(search)}`, { headers: { Authorization: `Bearer ${token}` } }),
          axios.get(`/issues/search?q=${encodeURIComponent(search)}`, { headers: { Authorization: `Bearer ${token}` } })
        ]);
        const boards = boardsRes.data || [];
        const issues = issuesRes.data || [];
        const boardSuggestions = boards.map(b => ({ type: 'board', id: b.id, label: b.name || b.boardName, extra: b.projectKey }));
        const issueSuggestions = issues.map(i => ({ type: 'issue', id: i.id, label: i.issueTitle || i.title, extra: i.issueKey }));
        setSuggestions([
          ...boardSuggestions,
          ...issueSuggestions
        ]);
        setShowDropdown(true);
      } catch (err) {
        setSuggestions([]);
        setShowDropdown(false);
      } finally {
        setLoading(false);
      }
    }, 300);
    // Cleanup
    return () => debounceTimeout.current && clearTimeout(debounceTimeout.current);
  }, [search]);

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClick = (e) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target) &&
        inputRef.current &&
        !inputRef.current.contains(e.target)
      ) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Handle navigation on selection
  const handleSelect = (item) => {
    setShowDropdown(false);
    setSearch('');
    if (item.type === 'board') {
      navigate(`/boards/${item.id}`);
    } else if (item.type === 'issue') {
      navigate(`/issues/${item.id}`);
    }
  };

  // Keyboard navigation
  const handleKeyDown = (e) => {
    if (!showDropdown || suggestions.length === 0) return;
    if (e.key === 'ArrowDown') {
      setHighlighted((prev) => (prev + 1) % suggestions.length);
    } else if (e.key === 'ArrowUp') {
      setHighlighted((prev) => (prev - 1 + suggestions.length) % suggestions.length);
    } else if (e.key === 'Enter') {
      if (highlighted >= 0 && highlighted < suggestions.length) {
        handleSelect(suggestions[highlighted]);
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('username');
    toast.success('Logged out successfully!');
    navigate('/login');
  };

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-md fixed top-0 left-0 right-0 z-40 h-16 transition-colors duration-200">
      <div className="h-full px-4 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center space-x-4">
          <Link to="/dashboard" className="flex items-center space-x-2">
            <span className="text-2xl">📋</span>
            <span className="text-xl font-bold text-gray-800 dark:text-white">TaskManagement</span>
          </Link>
        </div>

        {/* Search Bar */}
        <div className="hidden md:flex flex-1 max-w-md mx-8 relative">
          <div className="relative w-full">
            <input
              ref={inputRef}
              type="text"
              placeholder="Search issues, boards..."
              className="w-full px-4 py-2 pl-10 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-800 dark:text-white placeholder-gray-400 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={search}
              onChange={e => { setSearch(e.target.value); setShowDropdown(true); setHighlighted(-1); }}
              onFocus={() => search && setShowDropdown(true)}
              onKeyDown={handleKeyDown}
              autoComplete="off"
            />
            <svg
              className="absolute left-3 top-2.5 h-5 w-5 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            {/* Dropdown */}
            {showDropdown && (suggestions.length > 0 || loading) && (
              <div ref={dropdownRef} className="absolute left-0 right-0 mt-1 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50 max-h-72 overflow-y-auto">
                {loading ? (
                  <div className="p-4 text-gray-500 text-center">Loading...</div>
                ) : (
                  suggestions.map((item, idx) => (
                    <div
                      key={item.type + '-' + item.id}
                      className={`px-4 py-2 cursor-pointer flex items-center space-x-2 hover:bg-blue-100 dark:hover:bg-blue-900/30 ${highlighted === idx ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                      onMouseDown={() => handleSelect(item)}
                      onMouseEnter={() => setHighlighted(idx)}
                    >
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200">
                        {item.type === 'board' ? 'Board' : 'Issue'}
                      </span>
                      <span className="font-medium">{item.label}</span>
                      {item.extra && (
                        <span className="ml-2 text-xs text-gray-500">{item.extra}</span>
                      )}
                    </div>
                  ))
                )}
                {!loading && suggestions.length === 0 && (
                  <div className="p-4 text-gray-500 text-center">No results found</div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Theme Toggle */}
          <ThemeToggleButton />

          {/* Notification Bell */}
          <NotificationBell refreshTrigger={refreshBell} />

          {/* Profile Dropdown */}
          <div className="relative group">
            <button className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
              <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold">
                {username.charAt(0).toUpperCase()}
              </div>
              <span className="hidden md:block text-gray-700 dark:text-gray-200">{username}</span>
              <svg
                className="w-4 h-4 text-gray-500 dark:text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </button>

            {/* Dropdown Menu */}
            <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
              <Link
                to="/profile"
                className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-t-lg"
              >
                👤 Profile
              </Link>

              {admin && (
                <Link
                  to="/admin/users"
                  className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  🛡️ User Management
                </Link>
              )}

              <Link
                to="/workflows"
                className="block px-4 py-2 text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                ⚙️ Settings
              </Link>
              <hr className="my-1 border-gray-200 dark:border-gray-700" />
              <button
                onClick={handleLogout}
                className="w-full text-left px-4 py-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-b-lg"
              >
                🚪 Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
