import React from 'react';
import axios from '../api/axios';

const DownloadButton = ({ fileId }) => {
    const handleDownload = async () => {
        try {
            const response = await axios.get(`/api/file_upload/${fileId}/download`, {
                responseType: 'blob',
            });
            const contentDisposition = response.headers['content-disposition'];
            let filename = `${fileId}.pdf`;
            if (contentDisposition) {
                const match = contentDisposition.match(/filename="(.+)"/);
                if (match && match[1]) filename = match[1];
            }
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', filename);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            console.error('Error downloading file:', error);
        }
    };

    return (
        <button onClick={handleDownload} className="btn btn-primary">
            Download
        </button>
    );
};

export default DownloadButton;
