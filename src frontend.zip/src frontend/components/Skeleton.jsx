import React from 'react';

// Base skeleton block with pulse animation
const SkeletonBlock = ({ className = '' }) => (
  <div className={`bg-gray-200 animate-pulse rounded ${className}`} />
);

// Skeleton for text lines
const SkeletonText = ({ lines = 1, className = '' }) => (
  <div className={`space-y-2 ${className}`}>
    {Array.from({ length: lines }).map((_, index) => (
      <SkeletonBlock
        key={index}
        className={`h-4 ${index === lines - 1 && lines > 1 ? 'w-3/4' : 'w-full'}`}
      />
    ))}
  </div>
);

// Skeleton for avatar/circle
const SkeletonAvatar = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  return (
    <div
      className={`bg-gray-200 animate-pulse rounded-full ${sizeClasses[size]} ${className}`}
    />
  );
};

// Skeleton for a card
const SkeletonCard = ({ hasImage = false, hasAvatar = false, lines = 3 }) => (
  <div className="bg-white rounded-lg shadow p-4 w-full">
    {hasImage && (
      <SkeletonBlock className="h-40 w-full mb-4 rounded-lg" />
    )}
    <div className="flex items-start space-x-3">
      {hasAvatar && <SkeletonAvatar size="md" />}
      <div className="flex-1">
        <SkeletonBlock className="h-5 w-3/4 mb-3" />
        <SkeletonText lines={lines} />
      </div>
    </div>
  </div>
);

// Skeleton for a list item
const SkeletonListItem = ({ hasAvatar = true, hasAction = false }) => (
  <div className="flex items-center justify-between p-4 bg-white border-b border-gray-100">
    <div className="flex items-center space-x-3 flex-1">
      {hasAvatar && <SkeletonAvatar size="sm" />}
      <div className="flex-1">
        <SkeletonBlock className="h-4 w-1/2 mb-2" />
        <SkeletonBlock className="h-3 w-1/3" />
      </div>
    </div>
    {hasAction && <SkeletonBlock className="h-8 w-20 rounded-md" />}
  </div>
);

// Skeleton for a table row
const SkeletonTableRow = ({ columns = 4 }) => (
  <tr className="border-b border-gray-100">
    {Array.from({ length: columns }).map((_, index) => (
      <td key={index} className="p-4">
        <SkeletonBlock className="h-4 w-full" />
      </td>
    ))}
  </tr>
);

// Skeleton for board column
const SkeletonBoardColumn = ({ cards = 3 }) => (
  <div className="w-72 flex-shrink-0 bg-gray-100 rounded-lg p-3">
    <SkeletonBlock className="h-6 w-2/3 mb-4" />
    <div className="space-y-3">
      {Array.from({ length: cards }).map((_, index) => (
        <div key={index} className="bg-white rounded-lg shadow p-3">
          <SkeletonBlock className="h-4 w-full mb-2" />
          <SkeletonBlock className="h-3 w-2/3" />
        </div>
      ))}
    </div>
  </div>
);

// Skeleton for dashboard stat card
const SkeletonStatCard = () => (
  <div className="bg-white rounded-lg shadow p-6">
    <div className="flex items-center justify-between">
      <div className="flex-1">
        <SkeletonBlock className="h-4 w-1/2 mb-2" />
        <SkeletonBlock className="h-8 w-1/3" />
      </div>
      <SkeletonBlock className="h-12 w-12 rounded-full" />
    </div>
  </div>
);

// Skeleton for profile card
const SkeletonProfileCard = () => (
  <div className="bg-white rounded-lg shadow p-6 text-center">
    <SkeletonAvatar size="xl" className="mx-auto mb-4" />
    <SkeletonBlock className="h-5 w-1/2 mx-auto mb-2" />
    <SkeletonBlock className="h-4 w-2/3 mx-auto mb-4" />
    <SkeletonBlock className="h-3 w-1/3 mx-auto" />
  </div>
);

// Main Skeleton component with variants
const Skeleton = {
  Block: SkeletonBlock,
  Text: SkeletonText,
  Avatar: SkeletonAvatar,
  Card: SkeletonCard,
  ListItem: SkeletonListItem,
  TableRow: SkeletonTableRow,
  BoardColumn: SkeletonBoardColumn,
  StatCard: SkeletonStatCard,
  ProfileCard: SkeletonProfileCard,
};

// Skeleton loader wrapper for cards grid
export const SkeletonCardGrid = ({ count = 4, hasImage = false }) => (
  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
    {Array.from({ length: count }).map((_, index) => (
      <SkeletonCard key={index} hasImage={hasImage} />
    ))}
  </div>
);

// Skeleton loader wrapper for list
export const SkeletonList = ({ count = 5, hasAvatar = true, hasAction = false }) => (
  <div className="bg-white rounded-lg shadow overflow-hidden">
    {Array.from({ length: count }).map((_, index) => (
      <SkeletonListItem key={index} hasAvatar={hasAvatar} hasAction={hasAction} />
    ))}
  </div>
);

// Skeleton loader wrapper for table
export const SkeletonTable = ({ rows = 5, columns = 4 }) => (
  <div className="bg-white rounded-lg shadow overflow-hidden">
    <table className="min-w-full">
      <thead className="bg-gray-50">
        <tr>
          {Array.from({ length: columns }).map((_, index) => (
            <th key={index} className="p-4">
              <SkeletonBlock className="h-4 w-full" />
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {Array.from({ length: rows }).map((_, index) => (
          <SkeletonTableRow key={index} columns={columns} />
        ))}
      </tbody>
    </table>
  </div>
);

// Skeleton loader wrapper for board
export const SkeletonBoard = ({ columns = 3, cardsPerColumn = 3 }) => (
  <div className="flex space-x-4 overflow-x-auto pb-4">
    {Array.from({ length: columns }).map((_, index) => (
      <SkeletonBoardColumn key={index} cards={cardsPerColumn} />
    ))}
  </div>
);

export default Skeleton;

