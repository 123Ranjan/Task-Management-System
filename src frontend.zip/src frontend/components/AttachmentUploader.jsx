import React, { useState, useEffect, useRef } from 'react';
import axios from '../api/axios';
import { toast } from 'react-toastify';

const AttachmentUploader = ({ issueId, onAttachmentChange }) => {
  const [attachments, setAttachments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef(null);

  const allowedTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/svg+xml',
    'text/plain',
    'application/zip',
    'application/x-rar-compressed',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  ];

  const getCurrentUserEmail = () => {
    const profile = localStorage.getItem('profile');
    if (profile) {
      try {
        const parsed = JSON.parse(profile);
        return parsed.email || parsed.userEmail || '';
      } catch {
        return '';
      }
    }
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.sub || payload.email || payload.userEmail || '';
      } catch {
        return '';
      }
    }
    return '';
  };

  const mapAttachmentFields = (attachment) => ({
    id: attachment.id,
    filename: attachment.fileName || attachment.filename || attachment.name,
    size: attachment.fileSize || attachment.size,
    uploadedBy: attachment.uploadedBy || attachment.UploadedBy,
    createdAt: attachment.createdAt || attachment.uploadedAt,
    storagePath: attachment.storagePath,
    contentType: attachment.contentType,
  });

  const fetchAttachments = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/file_upload/issue/${issueId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setAttachments((response.data || []).map(mapAttachmentFields));
    } catch (error) {
      console.error('Failed to fetch attachments:', error);
      setAttachments([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (issueId) {
      fetchAttachments();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [issueId]);

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    const files = e.dataTransfer.files;
    if (!files || files.length === 0) return;
    await handleFileUpload(files);
  };

  const handleFileSelect = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    await handleFileUpload(files);
  };

  const handleFileUpload = async (files) => {
    setUploading(true);
    let validFiles = [];
    for (const file of files) {
      if (!allowedTypes.includes(file.type)) {
        toast.error(`Unsupported file type: ${file.name}`);
      } else if (file.size > 10 * 1024 * 1024) {
        toast.error(`File too large (max 10MB): ${file.name}`);
      } else {
        validFiles.push(file);
      }
    }
    if (validFiles.length === 0) {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    try {
      const token = localStorage.getItem('token');
      const uploadedBy = getCurrentUserEmail();
      for (const file of validFiles) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('issueId', issueId);
        if (uploadedBy) formData.append('uploadedBy', uploadedBy);
        await axios.post('/file_upload/upload', formData, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'multipart/form-data',
          },
        });
      }
      toast.success(
        validFiles.length > 1
          ? `${validFiles.length} files uploaded successfully!`
          : 'File uploaded successfully!'
      );
      fetchAttachments();
      if (onAttachmentChange) onAttachmentChange();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to upload file.';
      toast.error(errorMessage);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleDownload = async (attachment) => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/file_upload/${attachment.id}/download`, {
        responseType: 'blob',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const contentDisposition = response.headers['content-disposition'];
      let filename = attachment.filename || `${attachment.id}.pdf`;
      if (contentDisposition) {
        const match = contentDisposition.match(/filename="(.+)"/);
        if (match && match[1]) filename = match[1];
      }
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      toast.error('Failed to download file.');
    }
  };

  const handleDelete = async (attachmentId) => {
    setDeleting(attachmentId);

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/file_upload/delete/${attachmentId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Attachment removed successfully!');
      fetchAttachments();
      if (onAttachmentChange) onAttachmentChange();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to remove attachment.';
      toast.error(errorMessage);
    } finally {
      setDeleting(null);
    }
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return 'Unknown size';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getFileIcon = (filename) => {
    if (!filename) return '📎';
    const ext = filename.split('.').pop()?.toLowerCase();
    const icons = {
      pdf: '📄',
      doc: '📝',
      docx: '📝',
      xls: '📊',
      xlsx: '📊',
      ppt: '📽️',
      pptx: '📽️',
      jpg: '🖼️',
      jpeg: '🖼️',
      png: '🖼️',
      gif: '🖼️',
      svg: '🖼️',
      zip: '📦',
      rar: '📦',
      txt: '📃',
      csv: '📊',
      mp4: '🎬',
      mp3: '🎵',
      wav: '🎵',
    };
    return icons[ext] || '📎';
  };

  const formatDate = (dateString) => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-semibold text-gray-800 mb-4">Attachments</h3>

      {/* Upload Section */}
      <div className="mb-4">
        <div className="flex items-center justify-center w-full">
          <label
            htmlFor="file-upload"
            className={`flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors ${
              uploading ? 'opacity-50 cursor-not-allowed' : ''
            } ${dragActive ? 'border-blue-500 bg-blue-50' : ''}`}
            onDragOver={handleDragOver}
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              {uploading ? (
                <>
                  <svg
                    className="animate-spin h-8 w-8 text-blue-500 mb-2"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  <p className="text-sm text-gray-500">Uploading...</p>
                </>
              ) : (
                <>
                  <svg
                    className="w-8 h-8 mb-2 text-gray-500"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                    ></path>
                  </svg>
                  <p className="mb-1 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or
                    drag and drop
                  </p>
                  <p className="text-xs text-gray-500">
                    Any file up to 10MB
                  </p>
                </>
              )}
            </div>
            <input
              id="file-upload"
              ref={fileInputRef}
              type="file"
              className="hidden"
              onChange={handleFileSelect}
              disabled={uploading}
              multiple
            />
          </label>
        </div>
      </div>

      {/* Attachments List */}
      <div>
        {loading ? (
          <div className="text-center py-4 text-gray-600">
            Loading attachments...
          </div>
        ) : attachments.length === 0 ? (
          <div className="text-center py-4 text-gray-500 bg-gray-50 rounded-md">
            No attachments yet.
          </div>
        ) : (
          <div className="space-y-2">
            {attachments.map((attachment) => (
              <div
                key={attachment.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-md hover:bg-gray-100 transition-colors"
              >
                <div className="flex items-center space-x-3 flex-1 min-w-0">
                  <span className="text-2xl">
                    {getFileIcon(attachment.filename || attachment.name)}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-gray-800 truncate">
                      {attachment.filename || attachment.name || 'Unnamed file'}
                    </p>
                    <div className="flex items-center space-x-2 text-xs text-gray-500">
                      <span>{formatFileSize(attachment.size || attachment.fileSize)}</span>
                      {(attachment.createdAt || attachment.uploadedAt) && (
                        <>
                          <span>•</span>
                          <span>
                            {formatDate(attachment.createdAt || attachment.uploadedAt)}
                          </span>
                        </>
                      )}
                      {attachment.uploadedBy && (
                        <>
                          <span>•</span>
                          <span>by {attachment.uploadedBy}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 ml-2">
                  <button
                    onClick={() => handleDownload(attachment)}
                    className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded transition-colors"
                    title="Download"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                  <button
                    onClick={() => handleDelete(attachment.id)}
                    disabled={deleting === attachment.id}
                    className="p-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded transition-colors disabled:opacity-50"
                    title="Remove"
                  >
                    {deleting === attachment.id ? (
                      <span className="text-sm">...</span>
                    ) : (
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v6a1 1 0 102 0V8a1 1 0 00-1-1z"
                          clipRule="evenodd"
                        />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AttachmentUploader;

