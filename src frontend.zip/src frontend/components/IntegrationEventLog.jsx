import React, { useEffect, useState } from 'react';
import { getIntegrationEvents } from '../api/integration';

const IntegrationEventLog = ({ issueKey }) => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!issueKey) {
      setEvents([]);
      setLoading(false);
      return;
    }
    const fetchEvents = async () => {
      setLoading(true);
      try {
        const res = await getIntegrationEvents(issueKey);
        let data = res.data;
        setEvents(data);
      } catch (err) {
        setEvents([]);
      } finally {
        setLoading(false);
      }
    };
    fetchEvents();
  }, [issueKey]);

  if (!issueKey) return <div>Enter an issue key to view integration events.</div>;
  if (loading) return <div>Loading integration events...</div>;
  if (!events.length) return <div>No integration events found.</div>;

  return (
    <div className="integration-event-log">
      <h3>Integration Events</h3>
      <ul>
        {events.map(event => (
          <li key={event.id} style={{marginBottom: 8}}>
            <b>[{(event.eventType || event.type || '').toUpperCase()}]</b> {event.message}<br/>
            <small>Issue: {event.issueKey} | By: {event.author} | {event.timestamp ? new Date(event.timestamp).toLocaleString() : ''}</small>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default IntegrationEventLog;
