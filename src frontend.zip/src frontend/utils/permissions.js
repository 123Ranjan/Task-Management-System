// Central helpers for permission/role checks used across the UI.

export const getStoredPermissions = () => {
  try {
    const raw = localStorage.getItem('userPermissions');
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
};

export const hasPermission = (permission) => {
  return getStoredPermissions().includes(permission);
};

export const hasAnyPermission = (permissions = []) => {
  const current = getStoredPermissions();
  return permissions.some((p) => current.includes(p));
};

export const isAdmin = () => {
  return (localStorage.getItem('userRole') || '').toUpperCase() === 'ADMIN';
};
