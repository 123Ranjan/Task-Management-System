import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

// Pages
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';
import BoardsPage from './pages/BoardsPage';
import BoardView from './pages/BoardView';
import BacklogPage from './pages/BacklogPage';
import SprintPage from './pages/SprintPage';
import IssueDetails from './pages/IssueDetails';
import WorkflowSettings from './pages/WorkflowSettings';
import NotificationsPage from './pages/NotificationsPage';
import ProfilePage from './pages/ProfilePage';
import AdminUsersPage from './pages/AdminUsersPage';
import IntegrationDashboard from './pages/IntegrationDashboard';

// Components
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';

// Context
import { ThemeProvider } from './context/ThemeContext';

// Protected Route with Layout wrapper
const ProtectedLayout = ({ children }) => {
  return (
    <ProtectedRoute>
      <Layout>{children}</Layout>
    </ProtectedRoute>
  );
};

function App() {
  return (
    <ThemeProvider>
      <Router>
        <ToastContainer
          position="top-right"
          autoClose={3000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
      />
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Protected Routes with Layout */}
        <Route
          path="/dashboard"
          element={
            <ProtectedLayout>
              <Dashboard />
            </ProtectedLayout>
          }
        />
        <Route
          path="/boards"
          element={
            <ProtectedLayout>
              <BoardsPage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/boards/:id"
          element={
            <ProtectedLayout>
              <BoardView />
            </ProtectedLayout>
          }
        />
        <Route
          path="/backlog"
          element={
            <ProtectedLayout>
              <BacklogPage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/sprints"
          element={
            <ProtectedLayout>
              <SprintPage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/issues/:id"
          element={
            <ProtectedLayout>
              <IssueDetails />
            </ProtectedLayout>
          }
        />
        <Route
          path="/workflows"
          element={
            <ProtectedLayout>
              <WorkflowSettings />
            </ProtectedLayout>
          }
        />
        <Route
          path="/notifications"
          element={
            <ProtectedLayout>
              <NotificationsPage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedLayout>
              <ProfilePage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/admin/users"
          element={
            <ProtectedLayout>
              <AdminUsersPage />
            </ProtectedLayout>
          }
        />
        <Route
          path="/integration"
          element={
            <ProtectedLayout>
              <IntegrationDashboard />
            </ProtectedLayout>
          }
        />

        {/* Default redirect */}
        <Route path="/" element={<Navigate to="/login" replace />} />

        {/* 404 - Redirect to dashboard if logged in */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Router>
    </ThemeProvider>
  );
}

export default App;
