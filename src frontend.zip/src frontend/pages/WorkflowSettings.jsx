import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import {
  HiArrowLeft,
  HiPlus,
  HiTrash,
  HiPencil,
  HiCheckCircle,
  HiClock,
  HiExclamation,
  HiArrowRight,
  HiOutlineLightningBolt,
  HiOutlineChartBar,
  HiOutlineCog,
  HiArrowPath,
  HiChevronRight,
  HiEye,
  HiX,
  HiSwitchHorizontal,  // Changed from HiArrowsRightLeft
  HiAdjustments,       // Changed from HiAdjustmentsHorizontal
  HiExclamationCircle
} from 'react-icons/hi';

const WorkflowSettings = () => {
  const [workflows, setWorkflows] = useState([]);
  const [statuses, setStatuses] = useState([]);
  const [transitions, setTransitions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showStatusModal, setShowStatusModal] = useState(false);
  const [showTransitionModal, setShowTransitionModal] = useState(false);
  const [showWorkflowModal, setShowWorkflowModal] = useState(false);
  const [editingStatus, setEditingStatus] = useState(null);
  const [editingTransition, setEditingTransition] = useState(null);
  const [saving, setSaving] = useState(false);
  const [workflowForm, setWorkflowForm] = useState({
    name: '',
    description: '',
    type: 'DEFAULT'
  });
  const [selectedWorkflowId, setSelectedWorkflowId] = useState('');
  const [activeTab, setActiveTab] = useState('statuses');
  const [showWorkflowVisualization, setShowWorkflowVisualization] = useState(false);
  const [selectedVisualizationWorkflow, setSelectedVisualizationWorkflow] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Status form state
  const [statusForm, setStatusForm] = useState({
    name: '',
    description: '',
    color: '#3B82F6',
    icon: 'check-circle',
    isFinal: false,
    order: 0,
  });

  // Transition form state
  const [transitionForm, setTransitionForm] = useState({
    name: '',
    description: '',
    fromStatusId: '',
    toStatusId: '',
    roleRestrictions: [],
  });

  // Fetch all workflows
  const fetchWorkflows = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/workflows/all', {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = response.data;
      setWorkflows(Array.isArray(data) ? data : []);

      // Extract statuses and transitions
      if (Array.isArray(data)) {
        const allStatuses = data.flatMap((w) => w.statuses || []);
        const allTransitions = data.flatMap((w) => w.transactions || w.transitions || []);

        // Remove duplicates by ID
        const uniqueStatuses = [...new Map(allStatuses.map(item => [item.id, item])).values()];
        setStatuses(uniqueStatuses);
        setTransitions(allTransitions);
      }
    } catch (error) {
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
        return;
      }

      let errorMessage = 'Failed to fetch workflows.';
      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast.error(errorMessage);
    }
  };

  // Fetch statuses separately
  const fetchStatuses = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/workflows/status', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStatuses(response.data);
    } catch (error) {
      toast.error('Failed to fetch statuses.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWorkflows();
    fetchStatuses();
  }, []);

  // Handle drag and drop reordering of statuses
  const handleDragEnd = async (result) => {
    if (!result.destination) return;

    const items = Array.from(statuses);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    const updatedItems = items.map((item, index) => ({
      ...item,
      order: index,
    }));

    setStatuses(updatedItems);

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        '/workflows/reorder',
        { statuses: updatedItems.map((s) => ({ id: s.id, order: s.order })) },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Status order updated!');
    } catch (error) {
      toast.error('Failed to update order.');
      fetchStatuses(); // Revert on error
    }
  };

  // Validate status form
  const validateStatusForm = () => {
    const newErrors = {};
    if (!statusForm.name.trim()) newErrors.name = 'Name is required';
    if (statusForm.name.length > 50) newErrors.name = 'Name must be less than 50 characters';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // Create or update status
  const handleCreateStatus = async (e) => {
    e.preventDefault();

    if (!validateStatusForm()) {
      toast.error('Please fix form errors');
      return;
    }

    setSaving(true);

    try {
      const token = localStorage.getItem('token');
      const payload = {
        ...statusForm,
        order: editingStatus ? statusForm.order : statuses.length,
      };

      if (editingStatus) {
        await axios.put(`/workflows/status/${editingStatus.id}`, payload, {
          headers: { Authorization: `Bearer ${token}` },
        });
        toast.success('Status updated successfully!');
      } else {
        await axios.post('/workflows/status', payload, {
          headers: { Authorization: `Bearer ${token}` },
        });
        toast.success('Status created successfully!');
      }

      resetStatusForm();
      fetchStatuses();
      fetchWorkflows(); // Refresh workflows too
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to save status.';
      toast.error(errorMessage);
    } finally {
      setSaving(false);
    }
  };

  // Open transition modal (missing function)
  const openTransitionModal = () => {
    setEditingTransition(null);
    resetTransitionForm();
    setShowTransitionModal(true);
  };

  // Create or update transition
  const handleCreateTransition = async (e) => {
    e.preventDefault();
    setSaving(true);

    if (!selectedWorkflowId) {
      toast.error('Please select a workflow first.');
      setSaving(false);
      return;
    }

    const validation = validateTransition();
    if (!validation.valid) {
      toast.error(validation.message);
      setSaving(false);
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const fromStatusObj = statuses.find(s => s.id === Number(transitionForm.fromStatusId));
      const toStatusObj = statuses.find(s => s.id === Number(transitionForm.toStatusId));

      const payload = {
        actionName: transitionForm.name,
        description: transitionForm.description,
        role: transitionForm.roleRestrictions.join(',') || null,
      };

      if (editingTransition) {
        await axios.put(
          `/workflows/transition/${editingTransition.id}?fromStatusId=${fromStatusObj.id}&toStatusId=${toStatusObj.id}&workFlowId=${selectedWorkflowId}`,
          payload,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        toast.success('Transition updated successfully!');
      } else {
        await axios.post(
          `/workflows/transition?fromStatusId=${fromStatusObj.id}&toStatusId=${toStatusObj.id}&workFlowId=${selectedWorkflowId}`,
          payload,
          { headers: { Authorization: `Bearer ${token}` } }
        );
        toast.success('Transition created successfully!');
      }

      resetTransitionForm();
      fetchWorkflows();
    } catch (error) {
      let errorMessage = 'Failed to save transition.';
      if (error.response?.data?.message) errorMessage = error.response.data.message;
      toast.error(errorMessage);
    } finally {
      setSaving(false);
    }
  };

  // Validate transition
  const validateTransition = () => {
    if (!transitionForm.name.trim()) {
      return { valid: false, message: 'Transition name is required.' };
    }
    if (!transitionForm.fromStatusId) {
      return { valid: false, message: 'From Status is required.' };
    }
    if (!transitionForm.toStatusId) {
      return { valid: false, message: 'To Status is required.' };
    }
    if (transitionForm.fromStatusId === transitionForm.toStatusId) {
      return { valid: false, message: 'From Status and To Status cannot be the same.' };
    }
    return { valid: true };
  };

  // Create workflow
  const handleCreateWorkflow = async (e) => {
    e.preventDefault();
    if (!workflowForm.name.trim()) {
      toast.error('Workflow name is required.');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post('/workflows/create',
        {
          name: workflowForm.name,
          description: workflowForm.description,
          type: workflowForm.type,
          transactions: []
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Workflow created successfully!');
      setShowWorkflowModal(false);
      setWorkflowForm({ name: '', description: '', type: 'DEFAULT' });
      fetchWorkflows();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to create workflow.';
      toast.error(errorMessage);
    }
  };

  // Delete status
  const handleDeleteStatus = async (statusId) => {
    if (!window.confirm('Are you sure you want to delete this status? This will remove it from all workflows.')) return;

    setDeletingId(statusId);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/workflows/status/${statusId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Status deleted successfully!');
      fetchWorkflows();
      fetchStatuses();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete status.';
      toast.error(errorMessage);
    } finally {
      setDeletingId(null);
    }
  };

  // Delete transition
  const handleDeleteTransition = async (transitionId) => {
    if (!window.confirm('Are you sure you want to delete this transition?')) return;

    setDeletingId(transitionId);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/workflows/transition/${transitionId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Transition deleted successfully!');
      fetchWorkflows();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete transition.';
      toast.error(errorMessage);
    } finally {
      setDeletingId(null);
    }
  };

  // Delete workflow
  const handleDeleteWorkflow = async (workflowId) => {
    if (!window.confirm('Delete this workflow? This action cannot be undone.')) return;

    setDeletingId(workflowId);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/workflows/${workflowId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success('Workflow deleted successfully!');
      fetchWorkflows();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete workflow.';
      toast.error(errorMessage);
    } finally {
      setDeletingId(null);
    }
  };

  // Open edit status modal
  const openEditStatusModal = (status) => {
    setEditingStatus(status);
    setStatusForm({
      name: status.name || '',
      description: status.description || '',
      color: status.color || '#3B82F6',
      icon: status.icon || 'check-circle',
      isFinal: status.isFinal || false,
      order: status.order || 0,
    });
    setShowStatusModal(true);
  };

  // Open edit transition modal
  const openEditTransitionModal = (transition) => {
    setEditingTransition(transition);
    setTransitionForm({
      name: transition.name || transition.actionName || '',
      description: transition.description || '',
      fromStatusId: transition.fromStatusId || transition.fromStatus?.id || '',
      toStatusId: transition.toStatusId || transition.toStatus?.id || '',
      roleRestrictions: transition.role ? transition.role.split(',') : [],
    });

    // Try to find the workflow this transition belongs to
    const workflow = workflows.find(w =>
      w.transactions?.some(t => t.id === transition.id) ||
      w.transitions?.some(t => t.id === transition.id)
    );
    if (workflow) {
      setSelectedWorkflowId(workflow.id);
    }

    setShowTransitionModal(true);
  };

  // Reset status form
  const resetStatusForm = () => {
    setShowStatusModal(false);
    setEditingStatus(null);
    setStatusForm({
      name: '',
      description: '',
      color: '#3B82F6',
      icon: 'check-circle',
      isFinal: false,
      order: 0,
    });
    setErrors({});
  };

  // Reset transition form
  const resetTransitionForm = () => {
    setShowTransitionModal(false);
    setEditingTransition(null);
    setTransitionForm({
      name: '',
      description: '',
      fromStatusId: '',
      toStatusId: '',
      roleRestrictions: [],
    });
    setSelectedWorkflowId('');
  };

  // Get status name with type safety
  const getStatusName = (statusId) => {
    if (!statusId && statusId !== 0) return 'Unknown';
    const id = typeof statusId === 'string' ? parseInt(statusId) : statusId;
    const status = statuses.find((s) => s.id === id);
    return status?.name || 'Unknown';
  };

  // Get status icon
  const getStatusIcon = (iconName) => {
    const icons = {
      'check-circle': <HiCheckCircle className="w-4 h-4" />,
      'clock': <HiClock className="w-4 h-4" />,
      'exclamation': <HiExclamation className="w-4 h-4" />,
      'lightning': <HiOutlineLightningBolt className="w-4 h-4" />,
    };
    return icons[iconName] || <HiCheckCircle className="w-4 h-4" />;
  };

  // Get status color
  const getStatusColor = (color) => {
    return color || '#3B82F6';
  };

  // Get transition count by status
  const getTransitionCountByStatus = (statusId) => {
    return transitions.filter(t =>
      t.fromStatusId === statusId || t.fromStatus?.id === statusId
    ).length;
  };

  // Render workflow visualization
  const renderWorkflowVisualization = (workflow) => {
    if (!workflow) {
      return (
        <div className="text-center py-12">
          <HiExclamationCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Workflow Selected</h3>
          <p className="text-gray-600">Select a workflow to visualize its structure.</p>
        </div>
      );
    }

    const workflowStatuses = workflow.statuses || statuses;
    const workflowTransitions = workflow.transactions || transitions;

    return (
      <div className="relative">
        {/* Status Nodes */}
        <div className="flex flex-wrap items-center justify-center gap-8 py-8">
          {workflowStatuses.map((status, index) => {
            const outgoingTransitions = workflowTransitions.filter(t =>
              t.fromStatusId === status.id || t.fromStatus?.id === status.id
            );

            return (
              <React.Fragment key={status.id}>
                <div className="relative group">
                  <div
                    className="px-6 py-4 rounded-xl text-white font-semibold shadow-lg flex flex-col items-center justify-center min-w-[140px] transition-all hover:scale-105 cursor-pointer"
                    style={{ backgroundColor: getStatusColor(status.color) }}
                  >
                    <div className="flex items-center space-x-2 mb-1">
                      {getStatusIcon(status.icon)}
                      <span>{status.name}</span>
                    </div>
                    {status.description && (
                      <div className="text-xs opacity-90">{status.description}</div>
                    )}
                    <div className="text-xs mt-2 opacity-75">
                      {outgoingTransitions.length} transitions
                    </div>
                  </div>

                  {/* Transition Arrows */}
                  {outgoingTransitions.length > 0 && (
                    <div className="absolute left-full top-1/2 transform -translate-y-1/2 ml-4">
                      <div className="flex flex-col space-y-2">
                        {outgoingTransitions.map((transition, tIndex) => (
                          <div key={tIndex} className="flex items-center">
                            <div className="text-xs text-gray-500 bg-white px-2 py-1 rounded border">
                              {transition.name || transition.actionName}
                            </div>
                            <HiArrowRight className="text-gray-400 ml-1" />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Connection line */}
                {index < workflowStatuses.length - 1 && (
                  <div className="w-12 h-1 bg-gray-300 rounded-full"></div>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Transition Connections */}
        <div className="mt-8">
          <h4 className="text-sm font-semibold text-gray-700 mb-3">All Transitions</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {workflowTransitions.length === 0 ? (
              <div className="col-span-2 text-center py-6 bg-gray-50 rounded-lg">
                <HiSwitchHorizontal className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                <p className="text-gray-600">No transitions defined for this workflow.</p>
              </div>
            ) : (
              workflowTransitions.map((transition) => (
                <div key={transition.id} className="bg-gray-50 border border-gray-200 rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{transition.name || transition.actionName}</div>
                      {transition.description && (
                        <div className="text-sm text-gray-600">{transition.description}</div>
                      )}
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs rounded">
                        {getStatusName(transition.fromStatusId || transition.fromStatus?.id)}
                      </span>
                      <HiArrowRight className="text-gray-400" />
                      <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded">
                        {getStatusName(transition.toStatusId || transition.toStatus?.id)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  };

  // Color options for status
  const colorOptions = [
    { value: '#3B82F6', label: 'Blue', icon: '🔵' },
    { value: '#10B981', label: 'Green', icon: '🟢' },
    { value: '#F59E0B', label: 'Yellow', icon: '🟡' },
    { value: '#EF4444', label: 'Red', icon: '🔴' },
    { value: '#8B5CF6', label: 'Purple', icon: '🟣' },
    { value: '#EC4899', label: 'Pink', icon: '🌸' },
    { value: '#14B8A6', label: 'Teal', icon: '🧊' },
    { value: '#F97316', label: 'Orange', icon: '🟠' },
  ];

  // Icon options for status
  const iconOptions = [
    { value: 'check-circle', label: 'Check', icon: <HiCheckCircle className="w-5 h-5" /> },
    { value: 'clock', label: 'Clock', icon: <HiClock className="w-5 h-5" /> },
    { value: 'exclamation', label: 'Alert', icon: <HiExclamation className="w-5 h-5" /> },
    { value: 'lightning', label: 'Lightning', icon: <HiOutlineLightningBolt className="w-5 h-5" /> },
  ];

  // Role options for transition restrictions
  const roleOptions = ['ADMIN', 'MANAGER', 'DEVELOPER', 'TESTER', 'VIEWER'];

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mb-4"></div>
          <div className="text-xl font-medium text-gray-700">Loading Workflow Settings</div>
          <p className="text-gray-500 mt-2">Fetching configuration...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <HiArrowLeft className="w-5 h-5" />
                <span>Dashboard</span>
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Workflow Settings</h1>
                <p className="text-gray-600 mt-1">Configure statuses, transitions, and workflows</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={() => {
                  if (workflows.length > 0) {
                    setSelectedVisualizationWorkflow(workflows[0]);
                    setShowWorkflowVisualization(true);
                  } else {
                    toast.info('Please create a workflow first');
                  }
                }}
                className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:from-purple-700 hover:to-pink-700 transition-all shadow-lg hover:shadow-xl"
                disabled={workflows.length === 0}
              >
                <HiEye className="w-5 h-5" />
                <span>View Diagram</span>
              </button>
              <button
                onClick={() => setShowWorkflowModal(true)}
                className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg hover:shadow-xl"
              >
                <HiPlus className="w-5 h-5" />
                <span>New Workflow</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {[
                { id: 'statuses', label: 'Statuses', icon: <HiCheckCircle className="w-4 h-4" />, count: statuses.length },
                { id: 'transitions', label: 'Transitions', icon: <HiSwitchHorizontal className="w-4 h-4" />, count: transitions.length },
                { id: 'workflows', label: 'Workflows', icon: <HiOutlineChartBar className="w-4 h-4" />, count: workflows.length },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <span className="mr-2">{tab.icon}</span>
                  {tab.label}
                  <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-600'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {tab.count}
                  </span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Statuses Tab */}
            {activeTab === 'statuses' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Status Management</h3>
                    <p className="text-gray-600 text-sm mt-1">
                      Drag and drop to reorder statuses. Status order affects workflow progression.
                    </p>
                  </div>
                  <button
                    onClick={() => setShowStatusModal(true)}
                    className="flex items-center space-x-2 px-4 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors shadow-sm hover:shadow-md"
                  >
                    <HiPlus className="w-4 h-4" />
                    <span>Add Status</span>
                  </button>
                </div>

                {statuses.length === 0 ? (
                  <div className="bg-gray-50 rounded-xl border border-gray-200 p-12 text-center">
                    <HiOutlineCog className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h4 className="text-lg font-medium text-gray-900 mb-2">No Statuses Yet</h4>
                    <p className="text-gray-600 max-w-md mx-auto mb-6">
                      Start by creating your first status to define workflow stages.
                    </p>
                    <button
                      onClick={() => setShowStatusModal(true)}
                      className="inline-flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
                    >
                      <HiPlus className="w-5 h-5" />
                      <span>Create First Status</span>
                    </button>
                  </div>
                ) : (
                  <DragDropContext onDragEnd={handleDragEnd}>
                    <Droppable droppableId="statuses">
                      {(provided) => (
                        <div
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                          className="space-y-3"
                        >
                          {statuses.map((status, index) => (
                            <Draggable
                              key={status.id}
                              draggableId={status.id.toString()}
                              index={index}
                            >
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={`flex items-center justify-between p-4 rounded-xl border transition-all ${
                                    snapshot.isDragging
                                      ? 'shadow-lg bg-blue-50 border-blue-300'
                                      : 'bg-white border-gray-200 hover:border-blue-300 hover:shadow-sm'
                                  }`}
                                >
                                  <div className="flex items-center space-x-4">
                                    <div className="flex items-center space-x-2 text-gray-400">
                                      <HiAdjustments className="w-5 h-5" />
                                      <span className="text-sm">Drag</span>
                                    </div>
                                    <div
                                      className="w-10 h-10 rounded-lg flex items-center justify-center text-white"
                                      style={{ backgroundColor: getStatusColor(status.color) }}
                                    >
                                      {getStatusIcon(status.icon)}
                                    </div>
                                    <div>
                                      <div className="flex items-center space-x-2">
                                        <p className="font-semibold text-gray-900">{status.name}</p>
                                        {status.isFinal && (
                                          <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full">
                                            Final
                                          </span>
                                        )}
                                      </div>
                                      {status.description && (
                                        <p className="text-sm text-gray-600">{status.description}</p>
                                      )}
                                      <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                                        <span>Order: {status.order}</span>
                                        <span>•</span>
                                        <span>{getTransitionCountByStatus(status.id)} outgoing transitions</span>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <button
                                      onClick={() => openEditStatusModal(status)}
                                      className="p-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
                                      title="Edit"
                                    >
                                      <HiPencil className="w-4 h-4" />
                                    </button>
                                    <button
                                      onClick={() => handleDeleteStatus(status.id)}
                                      disabled={deletingId === status.id}
                                      className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50"
                                      title="Delete"
                                    >
                                      {deletingId === status.id ? (
                                        <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                                      ) : (
                                        <HiTrash className="w-4 h-4" />
                                      )}
                                    </button>
                                  </div>
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </DragDropContext>
                )}
              </div>
            )}

            {/* Transitions Tab */}
            {activeTab === 'transitions' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Transition Management</h3>
                    <p className="text-gray-600 text-sm mt-1">
                      Define allowed status transitions with optional role restrictions.
                    </p>
                  </div>
                  <button
                    onClick={openTransitionModal}
                    className="flex items-center space-x-2 px-4 py-2.5 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors shadow-sm hover:shadow-md"
                  >
                    <HiPlus className="w-4 h-4" />
                    <span>Add Transition</span>
                  </button>
                </div>

                {transitions.length === 0 ? (
                  <div className="bg-gray-50 rounded-xl border border-gray-200 p-12 text-center">
                    <HiSwitchHorizontal className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h4 className="text-lg font-medium text-gray-900 mb-2">No Transitions Yet</h4>
                    <p className="text-gray-600 max-w-md mx-auto mb-6">
                      Create transitions to define how statuses can change in your workflows.
                    </p>
                    <button
                      onClick={openTransitionModal}
                      className="inline-flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
                    >
                      <HiPlus className="w-5 h-5" />
                      <span>Create First Transition</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {transitions.map((transition) => (
                      <div
                        key={transition.id}
                        className="bg-white border border-gray-200 rounded-xl p-4 hover:border-green-300 hover:shadow-sm transition-all"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-gray-900">{transition.name || transition.actionName}</h4>
                            {transition.description && (
                              <p className="text-sm text-gray-600 mt-1">{transition.description}</p>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <button
                              onClick={() => openEditTransitionModal(transition)}
                              className="p-1.5 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg"
                              title="Edit"
                            >
                              <HiPencil className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteTransition(transition.id)}
                              disabled={deletingId === transition.id}
                              className="p-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg disabled:opacity-50"
                              title="Delete"
                            >
                              {deletingId === transition.id ? (
                                <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                              ) : (
                                <HiTrash className="w-4 h-4" />
                              )}
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center space-x-3">
                          <span className="px-3 py-1.5 bg-blue-100 text-blue-800 text-sm rounded-lg font-medium">
                            {getStatusName(transition.fromStatusId || transition.fromStatus?.id)}
                          </span>
                          <HiArrowRight className="text-gray-400" />
                          <span className="px-3 py-1.5 bg-green-100 text-green-800 text-sm rounded-lg font-medium">
                            {getStatusName(transition.toStatusId || transition.toStatus?.id)}
                          </span>
                        </div>

                        {transition.role && (
                          <div className="mt-3 pt-3 border-t border-gray-100">
                            <div className="text-xs text-gray-500 mb-1">Restricted to:</div>
                            <div className="flex flex-wrap gap-1">
                              {transition.role.split(',').map((role, idx) => (
                                <span key={idx} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded">
                                  {role}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Workflows Tab */}
            {activeTab === 'workflows' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Workflow Management</h3>
                    <p className="text-gray-600 text-sm mt-1">
                      Create and manage workflows with custom status and transition configurations.
                    </p>
                  </div>
                </div>

                {workflows.length === 0 ? (
                  <div className="bg-gray-50 rounded-xl border border-gray-200 p-12 text-center">
                    <HiOutlineChartBar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <h4 className="text-lg font-medium text-gray-900 mb-2">No Workflows Yet</h4>
                    <p className="text-gray-600 max-w-md mx-auto mb-6">
                      Create workflows to organize your statuses and transitions into logical processes.
                    </p>
                    <button
                      onClick={() => setShowWorkflowModal(true)}
                      className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-colors"
                    >
                      <HiPlus className="w-5 h-5" />
                      <span>Create First Workflow</span>
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {workflows.map((workflow) => (
                      <div
                        key={workflow.id}
                        className="bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all overflow-hidden"
                      >
                        <div className="p-5">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h4 className="font-semibold text-gray-900">{workflow.name}</h4>
                              <p className="text-sm text-gray-600 mt-1">{workflow.description || 'No description'}</p>
                            </div>
                            <span className="px-2.5 py-1 bg-indigo-100 text-indigo-800 text-xs rounded-full">
                              {workflow.type || 'DEFAULT'}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-3 mb-4">
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-2xl font-bold text-gray-900">
                                {workflow.statuses?.length || statuses.length}
                              </div>
                              <div className="text-xs text-gray-600">Statuses</div>
                            </div>
                            <div className="bg-gray-50 rounded-lg p-3">
                              <div className="text-2xl font-bold text-gray-900">
                                {workflow.transactions?.length || transitions.length}
                              </div>
                              <div className="text-xs text-gray-600">Transitions</div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between">
                            <button
                              onClick={() => {
                                setSelectedVisualizationWorkflow(workflow);
                                setShowWorkflowVisualization(true);
                              }}
                              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center space-x-1"
                            >
                              <HiEye className="w-4 h-4" />
                              <span>View Diagram</span>
                            </button>
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => {
                                  // Navigate to workflow detail or edit
                                  toast.info('Workflow edit coming soon');
                                }}
                                className="text-gray-600 hover:text-gray-800 text-sm font-medium flex items-center space-x-1"
                              >
                                <HiPencil className="w-4 h-4" />
                                <span>Edit</span>
                              </button>
                              <button
                                onClick={() => handleDeleteWorkflow(workflow.id)}
                                disabled={deletingId === workflow.id}
                                className="text-red-600 hover:text-red-700 text-sm font-medium flex items-center space-x-1 disabled:opacity-50"
                              >
                                {deletingId === workflow.id ? (
                                  <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                                ) : (
                                  <HiTrash className="w-4 h-4" />
                                )}
                                <span>Delete</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Create/Edit Status Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                {editingStatus ? (
                  <>
                    <HiPencil className="w-5 h-5 text-blue-600" />
                    <span>Edit Status</span>
                  </>
                ) : (
                  <>
                    <HiPlus className="w-5 h-5 text-blue-600" />
                    <span>Create New Status</span>
                  </>
                )}
              </h2>
              <button
                onClick={resetStatusForm}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
              >
                <HiX className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateStatus} className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Status Name *
                  </label>
                  <input
                    type="text"
                    value={statusForm.name}
                    onChange={(e) => {
                      setStatusForm({ ...statusForm, name: e.target.value });
                      if (errors.name) setErrors({ ...errors, name: '' });
                    }}
                    placeholder="e.g., In Progress, In Review, Done"
                    required
                    className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                      errors.name ? 'border-red-300' : 'border-gray-300'
                    }`}
                  />
                  {errors.name && (
                    <p className="text-red-500 text-sm mt-1">{errors.name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Description
                    <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                  </label>
                  <textarea
                    value={statusForm.description}
                    onChange={(e) => setStatusForm({ ...statusForm, description: e.target.value })}
                    placeholder="Describe what this status represents"
                    rows={2}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Color & Icon
                  </label>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm text-gray-600 mb-2">Select Color</div>
                      <div className="flex flex-wrap gap-2">
                        {colorOptions.map((color) => (
                          <button
                            type="button"
                            key={color.value}
                            onClick={() => setStatusForm({ ...statusForm, color: color.value })}
                            className={`w-10 h-10 rounded-lg border-2 flex items-center justify-center transition-all ${
                              statusForm.color === color.value
                                ? 'border-gray-800 scale-110'
                                : 'border-transparent hover:scale-105'
                            }`}
                            style={{ backgroundColor: color.value }}
                            title={color.label}
                          >
                            <span className="text-white text-sm">{color.icon}</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-600 mb-2">Select Icon</div>
                      <div className="flex flex-wrap gap-2">
                        {iconOptions.map((icon) => (
                          <button
                            type="button"
                            key={icon.value}
                            onClick={() => setStatusForm({ ...statusForm, icon: icon.value })}
                            className={`w-12 h-12 rounded-lg border-2 flex items-center justify-center transition-all ${
                              statusForm.icon === icon.value
                                ? 'border-blue-500 bg-blue-50'
                                : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                            }`}
                          >
                            <span className={`text-xl ${
                              statusForm.icon === icon.value ? 'text-blue-600' : 'text-gray-400'
                            }`}>
                              {icon.icon}
                            </span>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    id="isFinal"
                    checked={statusForm.isFinal}
                    onChange={(e) => setStatusForm({ ...statusForm, isFinal: e.target.checked })}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <label htmlFor="isFinal" className="text-sm text-gray-700">
                    Mark as final status (workflow ends here)
                  </label>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
                <button
                  type="button"
                  onClick={resetStatusForm}
                  className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  {saving ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Saving...</span>
                    </>
                  ) : editingStatus ? (
                    <>
                      <HiPencil className="w-4 h-4" />
                      <span>Update Status</span>
                    </>
                  ) : (
                    <>
                      <HiPlus className="w-4 h-4" />
                      <span>Create Status</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create/Edit Transition Modal */}
      {showTransitionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                {editingTransition ? (
                  <>
                    <HiPencil className="w-5 h-5 text-green-600" />
                    <span>Edit Transition</span>
                  </>
                ) : (
                  <>
                    <HiPlus className="w-5 h-5 text-green-600" />
                    <span>Create New Transition</span>
                  </>
                )}
              </h2>
              <button
                onClick={resetTransitionForm}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
              >
                <HiX className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              <form onSubmit={handleCreateTransition}>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Select Workflow *
                    </label>
                    <select
                      value={selectedWorkflowId}
                      onChange={e => setSelectedWorkflowId(e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">-- Select Workflow --</option>
                      {workflows.map(wf => (
                        <option key={wf.id} value={wf.id}>{wf.name}</option>
                      ))}
                    </select>
                  </div>

                  {selectedWorkflowId && (
                    <>
                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Transition Name *
                        </label>
                        <input
                          type="text"
                          value={transitionForm.name}
                          onChange={(e) => setTransitionForm({ ...transitionForm, name: e.target.value })}
                          placeholder="e.g., Start Work, Submit for Review, Mark Complete"
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Description
                          <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                        </label>
                        <textarea
                          value={transitionForm.description}
                          onChange={(e) => setTransitionForm({ ...transitionForm, description: e.target.value })}
                          placeholder="Describe what this transition does"
                          rows={2}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            From Status *
                          </label>
                          <select
                            value={transitionForm.fromStatusId}
                            onChange={(e) => setTransitionForm({ ...transitionForm, fromStatusId: e.target.value })}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          >
                            <option value="">Select source status...</option>
                            {statuses.map((status) => (
                              <option key={status.id} value={status.id}>
                                <span className="flex items-center">
                                  <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: getStatusColor(status.color) }}></span>
                                  {status.name}
                                </span>
                              </option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">
                            To Status *
                          </label>
                          <select
                            value={transitionForm.toStatusId}
                            onChange={(e) => setTransitionForm({ ...transitionForm, toStatusId: e.target.value })}
                            required
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          >
                            <option value="">Select target status...</option>
                            {statuses.map((status) => (
                              <option key={status.id} value={status.id}>
                                <span className="flex items-center">
                                  <span className="w-3 h-3 rounded-full mr-2" style={{ backgroundColor: getStatusColor(status.color) }}></span>
                                  {status.name}
                                </span>
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-2">
                          Role Restrictions
                          <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                        </label>
                        <div className="flex flex-wrap gap-2">
                          {roleOptions.map((role) => (
                            <button
                              type="button"
                              key={role}
                              onClick={() => {
                                const newRestrictions = transitionForm.roleRestrictions.includes(role)
                                  ? transitionForm.roleRestrictions.filter(r => r !== role)
                                  : [...transitionForm.roleRestrictions, role];
                                setTransitionForm({ ...transitionForm, roleRestrictions: newRestrictions });
                              }}
                              className={`px-3 py-1.5 rounded-lg text-sm transition-colors ${
                                transitionForm.roleRestrictions.includes(role)
                                  ? 'bg-blue-100 text-blue-800 border border-blue-200'
                                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-200'
                              }`}
                            >
                              {role}
                            </button>
                          ))}
                        </div>
                      </div>
                    </>
                  )}
                </div>

                <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
                  <button
                    type="button"
                    onClick={resetTransitionForm}
                    className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving || !selectedWorkflowId}
                    className="px-6 py-2.5 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                  >
                    {saving ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        <span>Saving...</span>
                      </>
                    ) : editingTransition ? (
                      <>
                        <HiPencil className="w-4 h-4" />
                        <span>Update Transition</span>
                      </>
                    ) : (
                      <>
                        <HiPlus className="w-4 h-4" />
                        <span>Create Transition</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Create Workflow Modal */}
      {showWorkflowModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                <HiPlus className="w-5 h-5 text-blue-600" />
                <span>Create New Workflow</span>
              </h2>
              <button
                onClick={() => setShowWorkflowModal(false)}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
              >
                <HiX className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateWorkflow} className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Workflow Name *
                  </label>
                  <input
                    type="text"
                    value={workflowForm.name}
                    onChange={e => setWorkflowForm({ ...workflowForm, name: e.target.value })}
                    placeholder="e.g., Default Workflow, Bug Fixing, Feature Development"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Description
                    <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                  </label>
                  <textarea
                    value={workflowForm.description}
                    onChange={e => setWorkflowForm({ ...workflowForm, description: e.target.value })}
                    placeholder="Describe the purpose of this workflow"
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Workflow Type
                  </label>
                  <select
                    value={workflowForm.type}
                    onChange={e => setWorkflowForm({ ...workflowForm, type: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="DEFAULT">Default</option>
                    <option value="AGILE">Agile</option>
                    <option value="KANBAN">Kanban</option>
                    <option value="SCRUM">Scrum</option>
                    <option value="CUSTOM">Custom</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
                <button
                  type="button"
                  onClick={() => setShowWorkflowModal(false)}
                  className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-colors"
                >
                  Create Workflow
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Workflow Visualization Modal */}
      {showWorkflowVisualization && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
                <HiOutlineChartBar className="w-6 h-6 text-purple-600" />
                <span>Workflow Diagram</span>
              </h2>
              <div className="flex items-center space-x-3">
                {workflows.length > 0 && (
                  <select
                    value={selectedVisualizationWorkflow?.id || ''}
                    onChange={(e) => {
                      const workflow = workflows.find(w => w.id === Number(e.target.value));
                      setSelectedVisualizationWorkflow(workflow || workflows[0]);
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  >
                    {workflows.map(wf => (
                      <option key={wf.id} value={wf.id}>{wf.name}</option>
                    ))}
                  </select>
                )}
                <button
                  onClick={() => setShowWorkflowVisualization(false)}
                  className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
                >
                  <HiX className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto flex-1 bg-gray-50">
              {renderWorkflowVisualization(selectedVisualizationWorkflow)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkflowSettings;