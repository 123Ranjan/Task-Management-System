import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import { isAdmin } from '../utils/permissions';

const BoardView = () => {
  const { id: boardId } = useParams();
  const navigate = useNavigate();
  const [columns, setColumns] = useState([]);
  const [cards, setCards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [boardName, setBoardName] = useState('');
  const [boardDescription, setBoardDescription] = useState('');
  const [showAddColumnModal, setShowAddColumnModal] = useState(false);
  const [newColumnName, setNewColumnName] = useState('');
  const [creating, setCreating] = useState(false);
  const [boardType, setBoardType] = useState('KANBAN');
  const [sprintName, setSprintName] = useState('');
  const [sprintActive, setSprintActive] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [sprintId, setSprintId] = useState(null);
  const [sprintState, setSprintState] = useState('');
  const [stats, setStats] = useState({ total: 0, done: 0, inProgress: 0 });
  const [showQuickFilters, setShowQuickFilters] = useState(false);
  const admin = isAdmin();

  const columnColors = [
    'from-blue-500 to-cyan-500',
    'from-indigo-500 to-purple-500',
    'from-emerald-500 to-green-500',
    'from-amber-500 to-orange-500',
    'from-rose-500 to-pink-500',
    'from-violet-500 to-purple-500',
    'from-sky-500 to-blue-500'
  ];

  const fetchBoardData = async () => {
    try {
      const token = localStorage.getItem('token');
      const headers = { Authorization: `Bearer ${token}` };

      const [boardRes, cardsRes, sprintsRes] = await Promise.all([
        axios.get(`/boards/${boardId}`, { headers }),
        axios.get(`/boardCard/board/${boardId}`, { headers }),
        axios.get(`/sprints/byBoard/${boardId}`, { headers }),
      ]);

      // Extract columns from board response if available
      let boardColumns = boardRes.data.columns || [];
      setBoardType(boardRes.data.boardType || 'KANBAN');
      setBoardName(boardRes.data.name || boardRes.data.boardName || 'Board');
      setBoardDescription(boardRes.data.description || '');

      // Find the current sprint (PLANNED or ACTIVE)
      let currentSprint = null;
      if (Array.isArray(sprintsRes.data)) {
        currentSprint = sprintsRes.data.find(s => s.state === 'PLANNED' || s.state === 'ACTIVE');
      }
      if (currentSprint) {
        setSprintId(currentSprint.id);
        setSprintName(currentSprint.sprintName || currentSprint.name);
        setSprintActive(currentSprint.state === 'ACTIVE');
        setSprintState(currentSprint.state);
      } else {
        setSprintId(null);
        setSprintName('');
        setSprintActive(false);
        setSprintState('');
      }

      // If columns are empty, try fetching from the dedicated endpoint
      if (boardColumns.length === 0) {
        try {
          const columnsRes = await axios.get(`/boards/${boardId}/columns`, { headers });
          boardColumns = columnsRes.data || [];
        } catch (colError) {
          console.error('Failed to fetch columns from dedicated endpoint:', colError);
          if (colError.response?.status !== 404) {
            toast.info('No columns found for this board. Add columns to get started.');
          }
        }
      }

      setColumns(boardColumns);
      const cardsData = cardsRes.data || [];
      setCards(cardsData);

      // Calculate stats
      const doneCards = cardsData.filter(card => 
        card.issueStatus === 'DONE' || card.status === 'DONE'
      ).length;
      const inProgressCards = cardsData.filter(card => 
        card.issueStatus === 'IN_PROGRESS' || card.status === 'IN_PROGRESS'
      ).length;
      
      setStats({
        total: cardsData.length,
        done: doneCards,
        inProgress: inProgressCards
      });
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to fetch board data.';
      toast.error(errorMessage);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBoardData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [boardId]);

  const getCardsByColumn = (columnId) => {
    return cards.filter((card) => card.columnId === columnId);
  };

  const handleCreateColumn = async (e) => {
    e.preventDefault();
    if (!newColumnName.trim()) {
      toast.error('Column name is required');
      return;
    }

    setCreating(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        `/boards/${boardId}/columns`,
        {
          columnName: newColumnName,
          boardName: newColumnName,
          position: columns.length,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      toast.success('Column created successfully!');
      setColumns([...columns, response.data]);
      setNewColumnName('');
      setShowAddColumnModal(false);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to create column.';
      toast.error(errorMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleDragEnd = async (result) => {
    const { destination, source, draggableId } = result;

    if (!destination) return;
    if (destination.droppableId === source.droppableId &&
        destination.index === source.index) {
      return;
    }

    const cardId = draggableId;
    const newColumnId = destination.droppableId;

    // Optimistically update UI
    const updatedCards = cards.map((card) =>
      card.id.toString() === cardId
        ? { ...card, columnId: parseInt(newColumnId) || newColumnId }
        : card
    );
    setCards(updatedCards);

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `/boardCard/${cardId}/move/${newColumnId}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Card moved successfully!');
      fetchBoardData(); // Refresh to get updated stats
    } catch (error) {
      setCards(cards);
      const errorMessage =
        error.response?.data?.message || 'Failed to move card.';
      toast.error(errorMessage);
    }
  };

  const handleStartSprint = async () => {
    if (!sprintId) {
      toast.error('No planned sprint found for this board.');
      return;
    }
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `/sprints/${sprintId}/start`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Sprint started!');
      setSprintActive(true);
      setSprintState('ACTIVE');
      fetchBoardData();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to start sprint.';
      toast.error(errorMessage);
    }
  };

  const handleCompleteSprint = async () => {
    if (!sprintId) {
      toast.error('No active sprint found for this board.');
      return;
    }
    setCompleting(true);
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `/sprints/${sprintId}/close`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Sprint marked as complete!');
      setSprintActive(false);
      setSprintState('COMPLETED');
      fetchBoardData();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to complete sprint.';
      toast.error(errorMessage);
    } finally {
      setCompleting(false);
    }
  };

  const getPriorityBadge = (priority) => {
    const styles = {
      HIGH: 'bg-gradient-to-r from-red-500 to-pink-600 text-white',
      MEDIUM: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
      LOW: 'bg-gradient-to-r from-emerald-500 to-green-600 text-white',
    };
    return styles[priority] || 'bg-gray-100 text-gray-700';
  };

  const getTypeIcon = (type) => {
    const icons = {
      TASK: '📝',
      STORY: '📖',
      BUG: '🐛',
      EPIC: '🎯',
      SUBTASK: '📌',
    };
    return icons[type] || '📋';
  };

  const getTypeColor = (type) => {
    const colors = {
      TASK: 'bg-blue-100 text-blue-700',
      STORY: 'bg-purple-100 text-purple-700',
      BUG: 'bg-red-100 text-red-700',
      EPIC: 'bg-indigo-100 text-indigo-700',
      SUBTASK: 'bg-gray-100 text-gray-700',
    };
    return colors[type] || 'bg-gray-100 text-gray-700';
  };

  const getColumnColor = (index) => {
    return columnColors[index % columnColors.length];
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
          <div className="text-lg font-medium text-gray-700">Loading board...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex flex-col">
      {/* Enhanced Header */}
      <header className="bg-gradient-to-r from-indigo-700 to-purple-800 shadow-lg flex-shrink-0">
        <div className="max-w-full mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/boards')}
                className="flex items-center text-white hover:text-indigo-200 transition-colors group"
              >
                <svg className="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Boards
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <span className="text-2xl text-white">{boardType === 'SCRUM' ? '🏃' : '📊'}</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">{boardName}</h1>
                  {boardDescription && (
                    <p className="text-indigo-200 text-sm">{boardDescription}</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex flex-wrap items-center gap-3">
              {boardType === 'SCRUM' && sprintName && (
                <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${sprintState === 'ACTIVE' ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></div>
                    <span className="text-sm text-white font-medium">
                      Sprint: {sprintName}
                    </span>
                    <span className="text-xs text-indigo-200">
                      {sprintState === 'ACTIVE' ? 'Active' : sprintState === 'PLANNED' ? 'Planned' : 'Completed'}
                    </span>
                  </div>
                </div>
              )}
              
              <div className="flex items-center space-x-2">
                {admin && (
                  <button
                    onClick={() => setShowAddColumnModal(true)}
                    className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-medium rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center space-x-2"
                  >
                    <span className="text-xl">+</span>
                    <span>Add Column</span>
                  </button>
                )}
                <button
                  onClick={() => fetchBoardData()}
                  className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl transition-colors flex items-center space-x-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <span>Refresh</span>
                </button>
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="mt-4 flex flex-wrap items-center gap-4">
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
              <div className="text-xs text-indigo-200">Total Cards</div>
              <div className="text-lg font-bold text-white">{stats.total}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
              <div className="text-xs text-indigo-200">In Progress</div>
              <div className="text-lg font-bold text-white">{stats.inProgress}</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
              <div className="text-xs text-indigo-200">Completed</div>
              <div className="text-lg font-bold text-white">{stats.done}</div>
            </div>
            
            {boardType === 'SCRUM' && (
              <div className="ml-auto flex items-center space-x-2">
                <button
                  className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  onClick={handleStartSprint}
                  disabled={sprintActive || !sprintId || sprintState !== 'PLANNED'}
                >
                  Start Sprint
                </button>
                <button
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  onClick={handleCompleteSprint}
                  disabled={!sprintActive || !sprintId || sprintState !== 'ACTIVE' || completing}
                >
                  {completing ? 'Completing...' : 'Complete Sprint'}
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Board Content */}
      <main className="flex-1 overflow-x-auto p-4 md:p-6 bg-gradient-to-b from-gray-50 to-gray-100">
        {boardType === 'KANBAN' && stats.total > 0 && (
          <div className="mb-6 bg-white rounded-2xl shadow-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="text-sm text-gray-600">Workflow Analytics</div>
                <div className="h-2 flex-1 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-emerald-500 to-green-600 transition-all duration-500"
                    style={{ width: `${stats.total > 0 ? (stats.done / stats.total * 100) : 0}%` }}
                  ></div>
                </div>
                <div className="text-sm font-medium text-gray-700">
                  {stats.total > 0 ? Math.round((stats.done / stats.total) * 100) : 0}% Complete
                </div>
              </div>
              <button
                onClick={() => setShowQuickFilters(!showQuickFilters)}
                className="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl transition-colors flex items-center space-x-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                </svg>
                <span>Filter Cards</span>
              </button>
            </div>
          </div>
        )}

        <DragDropContext onDragEnd={handleDragEnd}>
          <div className="flex space-x-4 md:space-x-6 min-w-max pb-4">
            {columns.length === 0 ? (
              <div className="flex items-center justify-center w-full py-12">
                <div className="text-center max-w-md">
                  <div className="text-6xl mb-6">📊</div>
                  <h2 className="text-2xl font-semibold text-gray-800 mb-2">
                    Welcome to your board!
                  </h2>
                  <p className="text-gray-600 mb-6">
                    Start by adding columns to organize your work items. Each column represents a stage in your workflow.
                  </p>
                  {admin && (
                    <button
                      onClick={() => setShowAddColumnModal(true)}
                      className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                    >
                      + Add Your First Column
                    </button>
                  )}
                </div>
              </div>
            ) : (
              columns.map((column, columnIndex) => {
                const columnCards = getCardsByColumn(column.id);
                const columnProgress = columnCards.length > 0 
                  ? columnCards.filter(card => card.issueStatus === 'DONE' || card.status === 'DONE').length / columnCards.length * 100
                  : 0;
                
                return (
                  <Droppable key={column.id} droppableId={column.id.toString()}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`w-80 flex-shrink-0 rounded-2xl shadow-lg transition-all duration-300 ${
                          snapshot.isDraggingOver 
                            ? 'ring-2 ring-indigo-500/50 shadow-2xl transform scale-[1.02]' 
                            : 'bg-white border border-gray-100'
                        }`}
                      >
                        {/* Column Header with Gradient */}
                        <div className={`bg-gradient-to-r ${getColumnColor(columnIndex)} p-6 rounded-t-2xl relative overflow-hidden`}>
                          <div className="absolute inset-0 bg-black/10"></div>
                          <div className="relative z-10">
                            <div className="flex justify-between items-center mb-2">
                              <h3 className="text-xl font-bold text-white truncate">
                                {column.name || column.columnName || column.boardName}
                              </h3>
                              <div className="bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full text-white font-bold text-sm">
                                {columnCards.length}
                              </div>
                            </div>
                            {columnCards.length > 0 && (
                              <div className="h-2 bg-white/30 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-white transition-all duration-500"
                                  style={{ width: `${columnProgress}%` }}
                                ></div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Cards Container */}
                        <div className="p-4 min-h-[500px] max-h-[calc(100vh-280px)] overflow-y-auto bg-gray-50/50">
                          {columnCards.length === 0 ? (
                            <div className="flex flex-col items-center justify-center py-16 text-center">
                              <div className="text-5xl mb-4 opacity-20">📝</div>
                              <p className="text-sm text-gray-400 mb-4">No cards yet</p>
                              <button
                                className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center space-x-1"
                                onClick={() => {
                                  toast.info('Add issues from the Backlog to populate this column');
                                }}
                              >
                                <span>+</span>
                                <span>Add cards from Backlog</span>
                              </button>
                            </div>
                          ) : (
                            columnCards.map((card, index) => (
                              <Draggable
                                key={card.id}
                                draggableId={card.id.toString()}
                                index={index}
                              >
                                {(provided, snapshot) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    {...provided.dragHandleProps}
                                    className={`bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-3 cursor-grab transition-all duration-300 ${
                                      snapshot.isDragging
                                        ? 'shadow-2xl ring-2 ring-indigo-500 rotate-1 scale-105 z-50'
                                        : 'hover:shadow-md hover:border-indigo-300 hover:-translate-y-1'
                                    }`}
                                  >
                                    {/* Card Header */}
                                    <div className="flex justify-between items-start mb-2">
                                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getTypeColor(card.issueType || 'TASK')}`}>
                                        <span className="text-lg">{getTypeIcon(card.issueType || 'TASK')}</span>
                                      </div>
                                      {card.issueKey && (
                                        <div className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded">
                                          {card.issueKey}
                                        </div>
                                      )}
                                    </div>

                                    {/* Issue Title */}
                                    <h4 className="font-semibold text-gray-900 mb-2 text-base line-clamp-2">
                                      {card.issueTitle || card.title || 'Untitled Issue'}
                                    </h4>

                                    {/* Issue Description */}
                                    {(card.issueDescription || card.description) && (
                                      <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                                        {card.issueDescription || card.description}
                                      </p>
                                    )}

                                    {/* Card Footer */}
                                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
                                      <div className="flex items-center space-x-2">
                                        {(card.issuePriority || card.priority) && (
                                          <span
                                            className={`px-2 py-1 text-xs font-semibold rounded ${getPriorityBadge(card.issuePriority || card.priority)}`}
                                          >
                                            {card.issuePriority || card.priority}
                                          </span>
                                        )}
                                        {(card.issueType || card.type) && (
                                          <span className={`px-2 py-1 text-xs rounded ${getTypeColor(card.issueType || card.type)}`}>
                                            {card.issueType || card.type}
                                          </span>
                                        )}
                                      </div>

                                      {card.assignedEmail && (
                                        <div className="flex items-center space-x-2">
                                          <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
                                            {card.assignedEmail.charAt(0).toUpperCase()}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </Draggable>
                            ))
                          )}
                          {provided.placeholder}
                        </div>

                        {/* Add Card Button */}
                        <div className="p-4 border-t border-gray-100">
                          <button
                            onClick={() => {
                              toast.info('Add issues from the Backlog page');
                              navigate('/backlog');
                            }}
                            className="w-full py-2.5 bg-gray-50 hover:bg-gray-100 text-gray-700 rounded-lg transition-colors flex items-center justify-center space-x-2"
                          >
                            <span className="text-lg">+</span>
                            <span>Add Card</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </Droppable>
                );
              })
            )}

            {/* Add Column Card */}
            {admin && columns.length > 0 && (
              <div className="w-80 flex-shrink-0">
                <button
                  onClick={() => setShowAddColumnModal(true)}
                  className="w-full h-full min-h-[500px] bg-gradient-to-br from-gray-50 to-gray-100 hover:from-gray-100 hover:to-gray-200 border-2 border-dashed border-gray-300 hover:border-indigo-400 rounded-2xl transition-all duration-300 flex flex-col items-center justify-center space-y-4 group"
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                    <div className="text-4xl text-indigo-600 group-hover:text-indigo-700 transition-colors">
                      +
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold text-gray-800 group-hover:text-indigo-700 transition-colors">
                      Add New Column
                    </div>
                    <div className="text-sm text-gray-500 mt-1 max-w-xs">
                      Create a new workflow stage for your board
                    </div>
                  </div>
                </button>
              </div>
            )}
          </div>
        </DragDropContext>
      </main>

      {/* Add Column Modal - Enhanced */}
      {admin && showAddColumnModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-white">Add New Column</h2>
                  <p className="text-indigo-200 text-sm mt-1">Create a new workflow stage</p>
                </div>
                <button
                  onClick={() => {
                    setShowAddColumnModal(false);
                    setNewColumnName('');
                  }}
                  className="text-white/80 hover:text-white text-2xl transition-colors"
                >
                  ×
                </button>
              </div>
            </div>
            
            <form onSubmit={handleCreateColumn} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Column Name *
                </label>
                <input
                  type="text"
                  value={newColumnName}
                  onChange={(e) => setNewColumnName(e.target.value)}
                  placeholder="e.g., TODO, IN PROGRESS, DONE"
                  required
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  autoFocus
                />
                <p className="text-xs text-gray-500 mt-2">
                  Choose a name that represents a stage in your workflow
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quick Presets
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['TODO', 'IN PROGRESS', 'IN REVIEW', 'TESTING', 'DONE', 'BLOCKED'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setNewColumnName(preset)}
                      className={`px-3 py-2 text-sm rounded-lg transition-all ${newColumnName === preset ? 'bg-indigo-100 text-indigo-700 ring-2 ring-indigo-500/20' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddColumnModal(false);
                    setNewColumnName('');
                  }}
                  className="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {creating ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Creating...
                    </div>
                  ) : 'Create Column'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BoardView;