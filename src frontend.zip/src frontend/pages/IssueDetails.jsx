import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import IssueLinkModal from '../components/IssueLinkModal';
import AttachmentUploader from '../components/AttachmentUploader';
import IntegrationEventLog from '../components/IntegrationEventLog';
import { isAdmin } from '../utils/permissions';
import {
  HiArrowLeft,
  HiPencil,
  HiTrash,
  HiLink,
  HiPaperClip,
  HiChatAlt,
  HiCalendar,
  HiUser,
  HiStatusOnline,
  HiExclamation,
  HiClock,
  HiCheckCircle,
  HiXCircle,
  HiDownload,
  HiEye,
  HiShare
} from 'react-icons/hi';

const IssueDetails = () => {
  const { id: issueId } = useParams();
  const navigate = useNavigate();
  const [issue, setIssue] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadingComments, setLoadingComments] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [addingComment, setAddingComment] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [activeTab, setActiveTab] = useState('details');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [linkedIssues, setLinkedIssues] = useState([]);

  const admin = isAdmin();
  // Check if current user is the assignee
  const currentUserEmail = localStorage.getItem('userEmail');
  const isCurrentUserAssignee = issue && issue.assignedEmail === currentUserEmail;
  const canEdit = admin || isCurrentUserAssignee;

  // Edit form state
  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    status: '',
    assignee: '',
    labels: '',
    priority: '',
    dueDate: '',
    storyPoints: '',
  });

  const fetchIssue = async () => {
    try {
      const token = localStorage.getItem('token');
      const [issueRes, linksRes] = await Promise.all([
        axios.get(`/issues/${issueId}`, {
          headers: { Authorization: `Bearer ${token}` },
        }).catch(() => ({ data: null })),
        axios.get(`/issues/${issueId}/links`, {
          headers: { Authorization: `Bearer ${token}` },
        }).catch(() => ({ data: [] }))
      ]);

      if (!issueRes.data) {
        toast.error('Issue not found');
        navigate('/backlog');
        return;
      }

      const issueData = issueRes.data;
      setIssue(issueData);
      setLinkedIssues(linksRes.data || []);

      setEditForm({
        title: issueData.issueTitle || issueData.title || '',
        description: issueData.issueDescription || issueData.description || '',
        status: issueData.issueStatus || issueData.status || '',
        assignee: issueData.assignedEmail || issueData.assignee || '',
        labels: Array.isArray(issueData.labels)
          ? issueData.labels.filter(Boolean).join(', ')
          : (issueData.labels || ''),
        priority: issueData.issuePriority || issueData.priority || '',
        dueDate: issueData.dueDate || issueData.due_date || '',
        storyPoints: issueData.storyPoints || issueData.points || '',
      });
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch issue details.';
      toast.error(errorMessage);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      } else if (error.response?.status === 404) {
        navigate('/backlog');
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async () => {
    setLoadingComments(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/issues/${issueId}/comments`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setComments(response.data);
    } catch (error) {
      toast.error('Failed to fetch comments.');
    } finally {
      setLoadingComments(false);
    }
  };

  useEffect(() => {
    fetchIssue();
    fetchComments();
  }, [issueId]);

  const handleSaveEdit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const payload = {
        ...editForm,
        issueTitle: editForm.title,
        issueDescription: editForm.description,
        issueStatus: editForm.status,
        assignedEmail: editForm.assignee,
        issuePriority: editForm.priority,
        dueDate: editForm.dueDate,
        storyPoints: editForm.storyPoints,
        labels: editForm.labels
          ? [...new Set(editForm.labels.split(',').map(label => label.trim()).filter(Boolean))]
          : [],
      };

      await axios.put(`/issues/${issueId}`, payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success('Issue updated successfully!');
      setIsEditing(false);
      fetchIssue();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to update issue.';
      toast.error(errorMessage);
    } finally {
      setSaving(false);
    }
  };

  const handleAddComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) {
      toast.error('Comment cannot be empty');
      return;
    }

    setAddingComment(true);
    try {
      const token = localStorage.getItem('token');
      const userEmail = localStorage.getItem('userEmail');

      await axios.post(
        `/issues/${issueId}/comments`,
        {
          body: newComment,
          authorEmail: userEmail,
          authorName: localStorage.getItem('username') || 'Anonymous'
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            ...(userEmail ? { 'X-User_Email': userEmail } : {}),
          },
        }
      );

      toast.success('Comment added successfully!');
      setNewComment('');
      fetchComments();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to add comment.';
      toast.error(errorMessage);
    } finally {
      setAddingComment(false);
    }
  };

  const handleDeleteComment = async (commentId) => {
    if (!admin) return;

    const confirm = window.confirm('Are you sure you want to delete this comment?');
    if (!confirm) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/issues/${issueId}/comments/${commentId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success('Comment deleted');
      fetchComments();
    } catch (error) {
      toast.error('Failed to delete comment.');
    }
  };

  const handleDeleteIssue = async () => {
    if (!admin) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/issues/${issueId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      toast.success('Issue deleted successfully');
      navigate('/backlog');
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete issue.';
      toast.error(errorMessage);
    } finally {
      setShowDeleteConfirm(false);
    }
  };

  const getStatusConfig = (status) => {
    const configs = {
      OPEN: { color: 'bg-blue-500', icon: <HiStatusOnline />, label: 'Open' },
      IN_PROGRESS: { color: 'bg-yellow-500', icon: <HiClock />, label: 'In Progress' },
      IN_REVIEW: { color: 'bg-purple-500', icon: <HiEye />, label: 'In Review' },
      DONE: { color: 'bg-green-500', icon: <HiCheckCircle />, label: 'Done' },
      CLOSED: { color: 'bg-gray-500', icon: <HiXCircle />, label: 'Closed' },
    };
    return configs[status] || { color: 'bg-gray-500', icon: null, label: status || 'Unknown' };
  };

  const getPriorityConfig = (priority) => {
    const configs = {
      HIGH: { color: 'bg-red-500', icon: <HiExclamation />, label: 'High' },
      MEDIUM: { color: 'bg-yellow-500', icon: <HiExclamation />, label: 'Medium' },
      LOW: { color: 'bg-green-500', icon: null, label: 'Low' },
    };
    return configs[priority] || { color: 'bg-gray-500', icon: null, label: priority || 'Not set' };
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getTimeAgo = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 30) return `${diffDays}d ago`;
    return formatDate(dateString);
  };

  const copyIssueLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url)
      .then(() => toast.success('Issue link copied to clipboard!'))
      .catch(() => toast.error('Failed to copy link'));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mb-4"></div>
          <div className="text-xl font-medium text-gray-700">Loading Issue Details</div>
          <p className="text-gray-500 mt-2">Fetching issue information...</p>
        </div>
      </div>
    );
  }

  if (!issue) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-4">🔍</div>
          <div className="text-xl font-medium text-gray-700">Issue Not Found</div>
          <p className="text-gray-500 mt-2">The issue you're looking for doesn't exist or was deleted.</p>
          <button
            onClick={() => navigate('/backlog')}
            className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Backlog
          </button>
        </div>
      </div>
    );
  }

  const statusConfig = getStatusConfig(issue.issueStatus);
  const priorityConfig = getPriorityConfig(issue.issuePriority);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 p-2 rounded-lg hover:bg-gray-100"
              >
                <HiArrowLeft className="w-5 h-5" />
                <span>Back</span>
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  {isEditing ? 'Edit Issue' : issue.issueTitle || issue.title}
                </h1>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="text-sm text-gray-500">ID: {issueId}</span>
                  <span className="text-gray-300">•</span>
                  <span className="text-sm text-gray-500">
                    Created {getTimeAgo(issue.createdAt)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              {!isEditing && (
                <>
                  <button
                    onClick={copyIssueLink}
                    className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <HiShare className="w-4 h-4" />
                    <span>Share</span>
                  </button>
                  <button
                    onClick={() => setShowLinkModal(true)}
                    className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                  >
                    <HiLink className="w-4 h-4" />
                    <span>Link Issue</span>
                  </button>
                  {canEdit && (
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <HiPencil className="w-4 h-4" />
                      <span>Edit</span>
                    </button>
                  )}
                  {admin && (
                    <button
                      onClick={() => setShowDeleteConfirm(true)}
                      className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                    >
                      <HiTrash className="w-4 h-4" />
                      <span>Delete</span>
                    </button>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Issue Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Edit Form or Issue Display */}
            {isEditing ? (
              <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                <form onSubmit={handleSaveEdit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Title *
                    </label>
                    <input
                      type="text"
                      value={editForm.title}
                      onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Enter issue title"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Description
                    </label>
                    <textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Describe the issue in detail..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Status
                      </label>
                      <select
                        value={editForm.status}
                        onChange={(e) => setEditForm({ ...editForm, status: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select Status</option>
                        <option value="OPEN">Open</option>
                        <option value="IN_PROGRESS">In Progress</option>
                        <option value="IN_REVIEW">In Review</option>
                        <option value="DONE">Done</option>
                        <option value="CLOSED">Closed</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Priority
                      </label>
                      <select
                        value={editForm.priority}
                        onChange={(e) => setEditForm({ ...editForm, priority: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      >
                        <option value="">Select Priority</option>
                        <option value="LOW">Low</option>
                        <option value="MEDIUM">Medium</option>
                        <option value="HIGH">High</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Assignee
                      </label>
                      <input
                        type="text"
                        value={editForm.assignee}
                        onChange={(e) => setEditForm({ ...editForm, assignee: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="user@example.com"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        Due Date
                      </label>
                      <input
                        type="datetime-local"
                        value={editForm.dueDate}
                        onChange={(e) => setEditForm({ ...editForm, dueDate: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Labels <span className="text-gray-500 text-sm">(comma-separated)</span>
                    </label>
                    <input
                      type="text"
                      value={editForm.labels}
                      onChange={(e) => setEditForm({ ...editForm, labels: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="bug, feature, enhancement"
                    />
                  </div>

                  <div className="flex justify-end space-x-4 pt-4 border-t border-gray-200">
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditing(false);
                        fetchIssue();
                      }}
                      className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={saving}
                      className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                    >
                      {saving && (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      )}
                      <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                    </button>
                  </div>
                </form>
              </div>
            ) : (
              <>
                {/* Issue Details Card */}
                <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                  <div className="flex items-start justify-between mb-6">
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold text-gray-900 mb-2">
                        {issue.issueTitle || issue.title}
                      </h2>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${statusConfig.color}`}></div>
                          <span className="font-medium text-gray-700">
                            {statusConfig.label}
                          </span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className={`w-3 h-3 rounded-full ${priorityConfig.color}`}></div>
                          <span className="font-medium text-gray-700">
                            {priorityConfig.label}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="prose max-w-none">
                    <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                      Description
                    </h3>
                    <div className="text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-lg border border-gray-200">
                      {issue.issueDescription || issue.description || 'No description provided.'}
                    </div>
                  </div>

                  {/* Labels */}
                  {issue.labels && issue.labels.length > 0 && (
                    <div className="mt-6">
                      <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-3">
                        Labels
                      </h3>
                      <div className="flex flex-wrap gap-2">
                        {(Array.isArray(issue.labels) ? issue.labels : [issue.labels])
                          .filter(Boolean)
                          .map((label, index) => (
                            <span
                              key={index}
                              className="px-3 py-1.5 bg-blue-50 text-blue-700 text-sm font-medium rounded-lg border border-blue-100"
                            >
                              {label}
                            </span>
                          ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Tabs Navigation */}
                <div className="border-b border-gray-200">
                  <nav className="flex space-x-8">
                    {['comments', 'attachments', 'activity', 'links'].map((tab) => (
                      <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`py-3 px-1 font-medium text-sm border-b-2 transition-colors ${
                          activeTab === tab
                            ? 'border-blue-600 text-blue-600'
                            : 'border-transparent text-gray-500 hover:text-gray-700'
                        }`}
                      >
                        {tab.charAt(0).toUpperCase() + tab.slice(1)}
                        {tab === 'comments' && comments.length > 0 && (
                          <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs">
                            {comments.length}
                          </span>
                        )}
                        {tab === 'links' && linkedIssues.length > 0 && (
                          <span className="ml-2 bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs">
                            {linkedIssues.length}
                          </span>
                        )}
                      </button>
                    ))}
                  </nav>
                </div>

                {/* Tab Content */}
                <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                  {activeTab === 'comments' && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Comments ({comments.length})
                        </h3>
                      </div>

                      {/* Add Comment Form */}
                      <form onSubmit={handleAddComment} className="mb-8">
                        <textarea
                          value={newComment}
                          onChange={(e) => setNewComment(e.target.value)}
                          placeholder="Add a comment..."
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                        />
                        <div className="flex justify-end mt-3">
                          <button
                            type="submit"
                            disabled={addingComment || !newComment.trim()}
                            className="px-6 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                          >
                            {addingComment && (
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                            )}
                            <span>{addingComment ? 'Adding...' : 'Add Comment'}</span>
                          </button>
                        </div>
                      </form>

                      {/* Comments List */}
                      {loadingComments ? (
                        <div className="text-center py-8">
                          <div className="inline-block animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
                          <p className="text-gray-500 mt-2">Loading comments...</p>
                        </div>
                      ) : comments.length === 0 ? (
                        <div className="text-center py-8">
                          <HiChatAlt className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                          <p className="text-gray-500">No comments yet. Be the first to comment!</p>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          {comments.map((comment) => (
                            <div key={comment.id} className="border border-gray-200 rounded-lg p-4 hover:border-gray-300 transition-colors">
                              <div className="flex items-start justify-between mb-3">
                                <div className="flex items-center space-x-3">
                                  <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-lg flex items-center justify-center text-white font-semibold">
                                    {comment.authorEmail?.[0]?.toUpperCase() || 'A'}
                                  </div>
                                  <div>
                                    <p className="font-medium text-gray-900">
                                      {comment.authorEmail || comment.authorName || 'Anonymous'}
                                    </p>
                                    <p className="text-xs text-gray-500">
                                      {getTimeAgo(comment.createdAt)}
                                    </p>
                                  </div>
                                </div>
                                {admin && (
                                  <button
                                    onClick={() => handleDeleteComment(comment.id)}
                                    className="text-red-600 hover:text-red-700 p-1 rounded hover:bg-red-50"
                                    title="Delete comment"
                                  >
                                    <HiTrash className="w-4 h-4" />
                                  </button>
                                )}
                              </div>
                              <p className="text-gray-700 whitespace-pre-wrap ml-13">
                                {comment.body || comment.Body || ''}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {activeTab === 'attachments' && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Attachments
                        </h3>
                      </div>
                      <AttachmentUploader
                        issueId={issueId}
                        onAttachmentChange={fetchIssue}
                      />
                    </div>
                  )}

                  {activeTab === 'activity' && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Integration Events
                        </h3>
                      </div>
                      <IntegrationEventLog issueKey={issueId} />
                    </div>
                  )}

                  {activeTab === 'links' && (
                    <div>
                      <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-semibold text-gray-900">
                          Linked Issues ({linkedIssues.length})
                        </h3>
                        <button
                          onClick={() => setShowLinkModal(true)}
                          className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                        >
                          <HiLink className="w-4 h-4" />
                          <span>Link Issue</span>
                        </button>
                      </div>
                      {linkedIssues.length === 0 ? (
                        <div className="text-center py-8">
                          <HiLink className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                          <p className="text-gray-500">No linked issues yet.</p>
                          <button
                            onClick={() => setShowLinkModal(true)}
                            className="mt-3 text-purple-600 hover:text-purple-700 font-medium"
                          >
                            Link an issue
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {linkedIssues.map((linkedIssue) => (
                            <div
                              key={linkedIssue.id}
                              className="border border-gray-200 rounded-lg p-4 hover:border-purple-300 hover:bg-purple-50 transition-colors"
                            >
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="font-medium text-gray-900">
                                    {linkedIssue.title}
                                  </p>
                                  <div className="flex items-center space-x-3 mt-1">
                                    <span className="text-sm text-gray-500">
                                      ID: {linkedIssue.id}
                                    </span>
                                    <span className="text-sm px-2 py-0.5 bg-gray-100 text-gray-600 rounded">
                                      {linkedIssue.status}
                                    </span>
                                  </div>
                                </div>
                                <button
                                  onClick={() => navigate(`/issues/${linkedIssue.id}`)}
                                  className="text-blue-600 hover:text-blue-700 font-medium"
                                >
                                  View
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-6">
            {/* Status Summary */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">
                Issue Summary
              </h3>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm text-gray-600">Status</span>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${statusConfig.color}`}></div>
                      <span className="font-medium text-gray-900">
                        {statusConfig.label}
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        issue.issueStatus === 'DONE' ? 'bg-green-500 w-full' :
                        issue.issueStatus === 'IN_PROGRESS' ? 'bg-yellow-500 w-2/3' :
                        issue.issueStatus === 'IN_REVIEW' ? 'bg-purple-500 w-3/4' :
                        'bg-blue-500 w-1/4'
                      }`}
                    ></div>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-gray-600">Priority</span>
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${priorityConfig.color}`}></div>
                      <span className="font-medium text-gray-900">
                        {priorityConfig.label}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-gray-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <HiUser className="w-4 h-4" />
                      <span className="text-sm">Assignee</span>
                    </div>
                    <span className="font-medium text-gray-900">
                      {issue.assignedEmail || 'Unassigned'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <HiCalendar className="w-4 h-4" />
                      <span className="text-sm">Created</span>
                    </div>
                    <span className="font-medium text-gray-900">
                      {formatDate(issue.createdAt)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <HiClock className="w-4 h-4" />
                      <span className="text-sm">Updated</span>
                    </div>
                    <span className="font-medium text-gray-900">
                      {formatDate(issue.updatedAt)}
                    </span>
                  </div>

                  {issue.dueDate && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <HiCalendar className="w-4 h-4" />
                        <span className="text-sm">Due Date</span>
                      </div>
                      <span className={`font-medium ${
                        new Date(issue.dueDate) < new Date()
                          ? 'text-red-600'
                          : 'text-gray-900'
                      }`}>
                        {formatDate(issue.dueDate)}
                      </span>
                    </div>
                  )}

                  {issue.storyPoints && (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <span className="text-sm">Story Points</span>
                      </div>
                      <span className="font-medium text-gray-900">
                        {issue.storyPoints}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-4">
                Quick Actions
              </h3>
              <div className="space-y-3">
                <button
                  onClick={() => setIsEditing(true)}
                  className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg transition-colors flex items-center space-x-3"
                >
                  <HiPencil className="w-5 h-5" />
                  <span>Edit Issue</span>
                </button>
                <button
                  onClick={() => setShowLinkModal(true)}
                  className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg transition-colors flex items-center space-x-3"
                >
                  <HiLink className="w-5 h-5" />
                  <span>Link Issue</span>
                </button>
                <button
                  onClick={copyIssueLink}
                  className="w-full bg-white/10 hover:bg-white/20 text-white p-3 rounded-lg transition-colors flex items-center space-x-3"
                >
                  <HiShare className="w-5 h-5" />
                  <span>Share Issue</span>
                </button>
                {admin && (
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full bg-red-500/20 hover:bg-red-500/30 text-white p-3 rounded-lg transition-colors flex items-center space-x-3"
                  >
                    <HiTrash className="w-5 h-5" />
                    <span>Delete Issue</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Delete Issue?
            </h3>
            <p className="text-gray-600 mb-6">
              Are you sure you want to delete this issue? This action cannot be undone.
              All comments, attachments, and links will be permanently removed.
            </p>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteIssue}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center space-x-2"
              >
                <HiTrash className="w-4 h-4" />
                <span>Delete Issue</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Issue Link Modal */}
      <IssueLinkModal
        isOpen={showLinkModal}
        onClose={() => setShowLinkModal(false)}
        issueId={issueId}
        onLinkAdded={() => {
          fetchIssue();
          toast.success('Issue linked successfully!');
        }}
      />
    </div>
  );
};

export default IssueDetails;