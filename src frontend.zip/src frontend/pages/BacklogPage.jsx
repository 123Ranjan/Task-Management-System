import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';

const BacklogPage = () => {
  const [backlogItems, setBacklogItems] = useState([]);
  const [boards, setBoards] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showMoveModal, setShowMoveModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedBoardId, setSelectedBoardId] = useState('');
  const [creating, setCreating] = useState(false);
  const [moving, setMoving] = useState(false);
  const [projectKeyToName, setProjectKeyToName] = useState({});
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'grid'
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const navigate = useNavigate();

  // Create issue form state
  const [issueForm, setIssueForm] = useState({
    title: '',
    description: '',
    priority: 'MEDIUM',
    type: 'TASK',
    assignedEmail: '',
  });

  const [profileEmail, setProfileEmail] = useState('');

  const fetchBacklog = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Session expired. Please login again.');
        navigate('/login');
        return;
      }

      const projectId = 1;
      const response = await axios.get(`/backLogs/${projectId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setBacklogItems(response.data);
    } catch (error) {
      if (error.response?.status === 401 || error.response?.status === 403) {
        // Let interceptor handle logout
      } else {
        const errorMessage =
          error.response?.data?.message || 'Failed to fetch backlog.';
        toast.error(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  const fetchBoards = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/boards', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setBoards(Array.isArray(response.data) ? response.data : []);
      const mapping = {};
      (Array.isArray(response.data) ? response.data : []).forEach((board) => {
        if (board.projectKey) {
          mapping[board.projectKey] = board.name || board.boardName;
        }
      });
      setProjectKeyToName(mapping);
    } catch (error) {
      console.error('Failed to fetch boards:', error);
      setBoards([]);
      setProjectKeyToName({});
    }
  };

  const fetchUsers = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/user/all', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const allUsers = Array.isArray(response.data) ? response.data : [];
      const filtered = allUsers.filter((u) => u.email !== profileEmail);
      setUsers(filtered);
    } catch (error) {
      console.error('Failed to fetch users:', error);
      setUsers([]);
    }
  };

  const fetchProfile = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('/user/profile', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setProfileEmail(res.data.email || '');
    } catch (err) {
      console.error('Failed to fetch profile', err);
    }
  };

  useEffect(() => {
    fetchProfile();
    fetchBacklog();
    fetchBoards();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profileEmail]);

  const handleCreateIssue = async (e) => {
    e.preventDefault();
    setCreating(true);

    if (issueForm.assignedEmail && issueForm.assignedEmail === profileEmail) {
      toast.error('You cannot assign an issue to yourself');
      setCreating(false);
      return;
    }

    try {
      const token = localStorage.getItem('token');
      const payload = {
        issueTitle: issueForm.title,
        issueDescription: issueForm.description,
        issuePriority: issueForm.priority,
        issueType: issueForm.type,
        issueStatus: 'TODO',
        projectId: 1,
        assignedEmail: issueForm.assignedEmail || null,
        reporterEmail: profileEmail || null
      };

      await axios.post('/issues/create', payload, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Issue created successfully!');
      setIssueForm({ title: '', description: '', priority: 'MEDIUM', type: 'TASK', assignedEmail: '' });
      setShowCreateModal(false);
      fetchBacklog();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to create issue.';
      toast.error(errorMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleMoveToBoard = async () => {
    if (!selectedBoardId) {
      toast.error('Please select a board.');
      return;
    }

    setMoving(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        `/backlog/${selectedItem.id}/moveToBoard`,
        { boardId: selectedBoardId },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Item moved to board successfully!');
      setShowMoveModal(false);
      setSelectedItem(null);
      setSelectedBoardId('');
      fetchBacklog();
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to move item to board.';
      toast.error(errorMessage);
    } finally {
      setMoving(false);
    }
  };

  const openMoveModal = (item) => {
    setSelectedItem(item);
    setShowMoveModal(true);
  };

  const getPriorityBadge = (priority) => {
    const styles = {
      HIGH: 'bg-gradient-to-r from-red-500 to-pink-600 text-white',
      MEDIUM: 'bg-gradient-to-r from-amber-500 to-orange-500 text-white',
      LOW: 'bg-gradient-to-r from-emerald-500 to-green-600 text-white',
    };
    return styles[priority] || 'bg-gray-100 text-gray-700';
  };

  const getTypeIcon = (type) => {
    const icons = {
      TASK: '📝',
      STORY: '📖',
      BUG: '🐛',
      EPIC: '🎯',
      SUBTASK: '📌',
    };
    return icons[type] || '📋';
  };

  const getTypeColor = (type) => {
    const colors = {
      TASK: 'bg-blue-100 text-blue-700',
      STORY: 'bg-purple-100 text-purple-700',
      BUG: 'bg-red-100 text-red-700',
      EPIC: 'bg-indigo-100 text-indigo-700',
      SUBTASK: 'bg-gray-100 text-gray-700',
    };
    return colors[type] || 'bg-gray-100 text-gray-700';
  };

  // Filter backlog items
  const filteredItems = backlogItems.filter(item => {
    const matchesSearch = item.issueTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.issueDescription?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.issueKey?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = filterStatus === 'all' ||
                         (filterStatus === 'assigned' && item.assignedEmail) ||
                         (filterStatus === 'unassigned' && !item.assignedEmail);

    return matchesSearch && matchesStatus;
  });

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
          <div className="text-lg font-medium text-gray-700">Loading backlog...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Enhanced Header */}
      <header className="bg-gradient-to-r from-indigo-700 to-purple-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center text-white hover:text-indigo-200 transition-colors group"
              >
                <svg className="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <span className="text-2xl text-white">📋</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">Backlog</h1>
                  <p className="text-indigo-200 text-sm">Manage and prioritize your work items</p>
                </div>
              </div>
            </div>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center space-x-2 group"
            >
              <span className="text-xl">+</span>
              <span>Create Issue</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Controls Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div className="flex-1 w-full">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search issues by title, description, or key..."
                  className="w-full px-4 py-3 pl-12 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
                <svg className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                  </svg>
                </button>
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                </button>
              </div>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              >
                <option value="all">All Issues</option>
                <option value="assigned">Assigned</option>
                <option value="unassigned">Unassigned</option>
              </select>

              <div className="text-sm text-gray-600 bg-gray-100 px-3 py-1.5 rounded-lg">
                <span className="font-semibold text-gray-800">{filteredItems.length}</span> items
              </div>
            </div>
          </div>
        </div>

        {/* Empty State */}
        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-6xl mb-6">📝</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              {backlogItems.length === 0 ? 'Backlog is empty' : 'No matching items found'}
            </h3>
            <p className="text-gray-600 mb-6">
              {backlogItems.length === 0
                ? 'Create your first issue to get started'
                : 'Try adjusting your search or filters'}
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl"
            >
              Create New Issue
            </button>
          </div>
        ) : viewMode === 'list' ? (
          /* List View */
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-100">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Issue</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Assignee</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Priority</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Created</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {filteredItems.map((item) => {
                    let projectKey = '';
                    if (item.issueKey && item.issueKey.includes('-')) {
                      projectKey = item.issueKey.split('-')[0];
                    }
                    const projectName = projectKeyToName[projectKey] || projectKey || '-';

                    return (
                      <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-start space-x-3">
                            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getTypeColor(item.issueType || 'TASK')}`}>
                              <span className="text-lg">{getTypeIcon(item.issueType || 'TASK')}</span>
                            </div>
                            <div className="min-w-0 flex-1">
                              <button
                                onClick={() => navigate(`/issues/${item.id}`)}
                                className="text-left group"
                              >
                                <div className="text-sm font-medium text-gray-900 group-hover:text-indigo-600 transition-colors truncate">
                                  {item.issueTitle || item.title || item.name || 'Untitled'}
                                </div>
                                <div className="text-xs text-gray-500 mt-1 truncate">
                                  {item.issueDescription || item.description || 'No description'}
                                </div>
                              </button>
                              {item.issueKey && (
                                <div className="text-xs font-mono text-gray-400 mt-1">
                                  {item.issueKey} • {projectName}
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 text-xs font-medium rounded-full ${getTypeColor(item.issueType || 'TASK')}`}>
                            {item.issueType || 'TASK'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          {item.assignedEmail ? (
                            <div className="flex items-center space-x-2">
                              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center text-white text-sm font-medium">
                                {item.assignedEmail.charAt(0).toUpperCase()}
                              </div>
                              <div className="text-sm text-gray-900">
                                {item.assignedEmail.split('@')[0]}
                              </div>
                            </div>
                          ) : (
                            <span className="text-sm text-gray-400 italic">Unassigned</span>
                          )}
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getPriorityBadge(item.issuePriority || item.priority)}`}>
                            {item.issuePriority || item.priority || 'N/A'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {item.createdAt || item.createdDate
                            ? new Date(item.createdAt || item.createdDate).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric'
                              })
                            : '-'}
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => openMoveModal(item)}
                            className="px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-sm font-medium rounded-lg transition-all shadow hover:shadow-md"
                          >
                            Move to Board
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          /* Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredItems.map((item) => {
              let projectKey = '';
              if (item.issueKey && item.issueKey.includes('-')) {
                projectKey = item.issueKey.split('-')[0];
              }
              const projectName = projectKeyToName[projectKey] || projectKey || '-';

              return (
                <div key={item.id} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow">
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${getTypeColor(item.issueType || 'TASK')}`}>
                        <span className="text-2xl">{getTypeIcon(item.issueType || 'TASK')}</span>
                      </div>
                      <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getPriorityBadge(item.issuePriority || item.priority)}`}>
                        {item.issuePriority || item.priority || 'N/A'}
                      </span>
                    </div>

                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      <button
                        onClick={() => navigate(`/issues/${item.id}`)}
                        className="text-left hover:text-indigo-600 transition-colors"
                      >
                        {item.issueTitle || item.title || item.name || 'Untitled Issue'}
                      </button>
                    </h3>

                    <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                      {item.issueDescription || item.description || 'No description provided'}
                    </p>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2">
                          {item.assignedEmail ? (
                            <>
                              <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center text-white text-xs font-medium">
                                {item.assignedEmail.charAt(0).toUpperCase()}
                              </div>
                              <span className="text-gray-700">{item.assignedEmail.split('@')[0]}</span>
                            </>
                          ) : (
                            <span className="text-gray-400 italic">Unassigned</span>
                          )}
                        </div>
                        <span className={`px-2 py-1 text-xs rounded ${getTypeColor(item.issueType || 'TASK')}`}>
                          {item.issueType || 'TASK'}
                        </span>
                      </div>

                      {item.issueKey && (
                        <div className="text-xs font-mono text-gray-500 bg-gray-50 px-3 py-1.5 rounded-lg">
                          {item.issueKey} • {projectName}
                        </div>
                      )}

                      <div className="text-xs text-gray-500">
                        Created: {item.createdAt || item.createdDate
                          ? new Date(item.createdAt || item.createdDate).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric'
                            })
                          : 'Unknown'}
                      </div>
                    </div>

                    <button
                      onClick={() => openMoveModal(item)}
                      className="w-full py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-medium rounded-lg transition-all shadow hover:shadow-md"
                    >
                      Move to Board
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      {/* Create Issue Modal - Enhanced */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-white">Create New Issue</h2>
                  <p className="text-indigo-200 text-sm mt-1">Add a new task to your backlog</p>
                </div>
                <button
                  onClick={() => {
                    setShowCreateModal(false);
                    setIssueForm({ title: '', description: '', priority: 'MEDIUM', type: 'TASK', assignedEmail: '' });
                  }}
                  className="text-white/80 hover:text-white text-2xl transition-colors"
                >
                  ×
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateIssue} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Title *
                </label>
                <input
                  type="text"
                  value={issueForm.title}
                  onChange={(e) => setIssueForm({ ...issueForm, title: e.target.value })}
                  placeholder="What needs to be done?"
                  required
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description
                </label>
                <textarea
                  value={issueForm.description}
                  onChange={(e) => setIssueForm({ ...issueForm, description: e.target.value })}
                  placeholder="Add details, acceptance criteria, or context..."
                  rows={3}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Type
                  </label>
                  <select
                    value={issueForm.type}
                    onChange={(e) => setIssueForm({ ...issueForm, type: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="TASK">Task</option>
                    <option value="STORY">Story</option>
                    <option value="BUG">Bug</option>
                    <option value="EPIC">Epic</option>
                    <option value="SUBTASK">Subtask</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Priority
                  </label>
                  <select
                    value={issueForm.priority}
                    onChange={(e) => setIssueForm({ ...issueForm, priority: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="LOW">Low</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HIGH">High</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Assign To
                </label>
                <select
                  value={issueForm.assignedEmail}
                  onChange={(e) => setIssueForm({ ...issueForm, assignedEmail: e.target.value })}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="">Unassigned</option>
                  {users.map((user) => (
                    <option key={user.email} value={user.email}>
                      {user.email} {user.role ? `(${user.role})` : ''}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateModal(false);
                    setIssueForm({ title: '', description: '', priority: 'MEDIUM', type: 'TASK', assignedEmail: '' });
                  }}
                  className="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {creating ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Creating...
                    </div>
                  ) : 'Create Issue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Move to Board Modal - Enhanced */}
      {showMoveModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md overflow-hidden">
            <div className="bg-gradient-to-r from-emerald-600 to-green-600 p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-white">Move to Board</h2>
                  <p className="text-emerald-200 text-sm mt-1">Select a destination board</p>
                </div>
                <button
                  onClick={() => {
                    setShowMoveModal(false);
                    setSelectedItem(null);
                    setSelectedBoardId('');
                  }}
                  className="text-white/80 hover:text-white text-2xl transition-colors"
                >
                  ×
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <p className="text-gray-600">
                  Moving: <span className="font-semibold text-gray-900">{selectedItem?.issueTitle || selectedItem?.title || selectedItem?.name}</span>
                </p>
                {selectedItem?.issueDescription && (
                  <p className="text-sm text-gray-500 mt-1 truncate">{selectedItem.issueDescription}</p>
                )}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Board
                </label>
                <select
                  value={selectedBoardId}
                  onChange={(e) => setSelectedBoardId(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                >
                  <option value="">Choose a board...</option>
                  {boards.map((board) => (
                    <option key={board.id} value={board.id}>
                      {board.name || board.boardName} {board.projectKey ? `(${board.projectKey})` : ''}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-2">
                  This issue will be added to the selected board's first column
                </p>
              </div>

              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowMoveModal(false);
                    setSelectedItem(null);
                    setSelectedBoardId('');
                  }}
                  className="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleMoveToBoard}
                  disabled={moving || !selectedBoardId}
                  className="px-6 py-3 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {moving ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Moving...
                    </div>
                  ) : 'Move Issue'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BacklogPage;