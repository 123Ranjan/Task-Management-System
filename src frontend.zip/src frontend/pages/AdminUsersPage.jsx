import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import { isAdmin } from '../utils/permissions';

const AdminUsersPage = () => {
  const navigate = useNavigate();
  const admin = isAdmin();

  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [updatingId, setUpdatingId] = useState(null);
  const [viewMode, setViewMode] = useState('table'); // 'table' or 'card'

  const roles = ['ADMIN', 'MANAGER', 'DEVELOPER', 'TESTER', 'PRODUCTION', 'SUPPORT', 'NON_TECH', 'DEVOPS'];

  const filteredUsers = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) => {
      return (
        String(u.username || '').toLowerCase().includes(q) ||
        String(u.email || '').toLowerCase().includes(q) ||
        String(u.role || '').toLowerCase().includes(q)
      );
    });
  }, [users, filter]);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/user/all', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      const msg = error.response?.data?.message || 'Failed to load users.';
      toast.error(msg);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  };

  const updateUserRole = async (id, role) => {
    setUpdatingId(id);
    try {
      const token = localStorage.getItem('token');
      const res = await axios.put(`/user/${id}/role`, null, {
        params: { role },
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...res.data } : u)));
      toast.success('Role updated successfully');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update role.');
    } finally {
      setUpdatingId(null);
    }
  };

  const setUserActive = async (id, active) => {
    setUpdatingId(id);
    try {
      const token = localStorage.getItem('token');
      const res = await axios.put(`/user/${id}/active`, null, {
        params: { active },
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...res.data } : u)));
      toast.success(`User ${active ? 'activated' : 'deactivated'}`);
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update user.');
    } finally {
      setUpdatingId(null);
    }
  };

  const deleteUser = async (id, email) => {
    const ok = window.confirm(`Delete user "${email || id}"? This action cannot be undone.`);
    if (!ok) return;

    setUpdatingId(id);
    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/user/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers((prev) => prev.filter((u) => u.id !== id));
      toast.success('User deleted successfully');
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to delete user.');
    } finally {
      setUpdatingId(null);
    }
  };

  useEffect(() => {
    if (!admin) {
      toast.error('Access denied');
      navigate('/dashboard');
      return;
    }
    fetchUsers();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!admin) return null;

  const getRoleColor = (role) => {
    const colors = {
      ADMIN: 'bg-red-100 text-red-800 border-red-200',
      MANAGER: 'bg-purple-100 text-purple-800 border-purple-200',
      DEVELOPER: 'bg-blue-100 text-blue-800 border-blue-200',
      TESTER: 'bg-amber-100 text-amber-800 border-amber-200',
      PRODUCTION: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      SUPPORT: 'bg-cyan-100 text-cyan-800 border-cyan-200',
      NON_TECH: 'bg-gray-100 text-gray-800 border-gray-200',
      DEVOPS: 'bg-indigo-100 text-indigo-800 border-indigo-200',
    };
    return colors[role] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getUserInitials = (username) => {
    if (!username) return '??';
    return username.substring(0, 2).toUpperCase();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Enhanced Header */}
      <header className="bg-gradient-to-r from-indigo-700 to-purple-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center text-white hover:text-indigo-200 transition-colors group"
              >
                <svg className="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <span className="text-2xl text-white">👥</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">User Management</h1>
                  <p className="text-indigo-200 text-sm">Manage team members and permissions</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={fetchUsers}
                className="px-4 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors flex items-center space-x-2"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                <span>Refresh</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Controls Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div className="flex-1 w-full">
              <div className="relative">
                <input
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                  placeholder="Search users by name, email, or role..."
                  className="w-full px-4 py-3 pl-12 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
                <svg className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('table')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'table' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </button>
                <button
                  onClick={() => setViewMode('card')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'card' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                  </svg>
                </button>
              </div>
              
              <div className="text-sm text-gray-600 bg-gray-100 px-3 py-1.5 rounded-lg">
                <span className="font-semibold text-gray-800">{filteredUsers.length}</span> users found
              </div>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {loading ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
            <div className="text-lg font-medium text-gray-700">Loading user data...</div>
            <p className="text-gray-500 mt-2">Please wait while we fetch the latest information</p>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-5xl mb-4">👥</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">No users found</h3>
            <p className="text-gray-600 mb-6">
              {filter ? 'Try adjusting your search terms' : 'No users have been registered yet'}
            </p>
            <button
              onClick={() => setFilter('')}
              className="px-6 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              {filter ? 'Clear Search' : 'Refresh List'}
            </button>
          </div>
        ) : viewMode === 'table' ? (
          /* Table View */
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">User</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Contact</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Role</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {filteredUsers.map((u) => (
                    <tr key={u.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-semibold">
                            {getUserInitials(u.username)}
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{u.username || 'No username'}</div>
                            <div className="text-xs text-gray-500">ID: {u.id}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">{u.email || 'No email'}</div>
                        <div className="text-xs text-gray-500">Joined: {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Unknown'}</div>
                      </td>
                      <td className="px-6 py-4">
                        <select
                          value={u.role || ''}
                          onChange={(e) => updateUserRole(u.id, e.target.value)}
                          disabled={updatingId === u.id}
                          className={`px-3 py-1.5 border rounded-lg text-sm font-medium transition-all ${getRoleColor(u.role)} focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                        >
                          <option value="" disabled>Select role</option>
                          {roles.map((r) => (
                            <option key={r} value={r}>{r}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          type="button"
                          onClick={() => setUserActive(u.id, !u.active)}
                          disabled={updatingId === u.id}
                          className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${u.active ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'} disabled:opacity-50`}
                        >
                          {u.active ? (
                            <span className="flex items-center">
                              <span className="w-2 h-2 bg-emerald-500 rounded-full mr-2"></span>
                              Active
                            </span>
                          ) : (
                            <span className="flex items-center">
                              <span className="w-2 h-2 bg-gray-500 rounded-full mr-2"></span>
                              Inactive
                            </span>
                          )}
                        </button>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <button
                            type="button"
                            onClick={() => deleteUser(u.id, u.email)}
                            disabled={updatingId === u.id}
                            className="px-3 py-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center"
                          >
                            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="px-6 py-4 bg-gray-50 border-t border-gray-100 text-sm text-gray-600">
              <div className="flex justify-between items-center">
                <span>Showing {filteredUsers.length} of {users.length} users</span>
                <span className="text-xs bg-gray-200 px-2 py-1 rounded">Admin actions require appropriate permissions</span>
              </div>
            </div>
          </div>
        ) : (
          /* Card View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredUsers.map((u) => (
              <div key={u.id} className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow">
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white font-bold text-lg">
                        {getUserInitials(u.username)}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{u.username || 'No username'}</h3>
                        <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getRoleColor(u.role)}`}>
                          {u.role || 'No role'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => setUserActive(u.id, !u.active)}
                      disabled={updatingId === u.id}
                      className={`w-10 h-10 rounded-lg flex items-center justify-center ${u.active ? 'bg-emerald-100 text-emerald-600' : 'bg-gray-100 text-gray-600'} hover:opacity-80 transition-opacity`}
                    >
                      {u.active ? '✓' : '○'}
                    </button>
                  </div>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center text-sm text-gray-600">
                      <svg className="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      {u.email || 'No email provided'}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <svg className="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                      Joined: {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Unknown'}
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <select
                      value={u.role || ''}
                      onChange={(e) => updateUserRole(u.id, e.target.value)}
                      disabled={updatingId === u.id}
                      className={`w-full px-3 py-2 border rounded-lg text-sm font-medium ${getRoleColor(u.role)} focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all`}
                    >
                      <option value="" disabled>Change role</option>
                      {roles.map((r) => (
                        <option key={r} value={r}>{r}</option>
                      ))}
                    </select>
                    
                    <div className="flex space-x-2">
                      <button
                        onClick={() => deleteUser(u.id, u.email)}
                        disabled={updatingId === u.id}
                        className="flex-1 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 flex items-center justify-center"
                      >
                        <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default AdminUsersPage;
