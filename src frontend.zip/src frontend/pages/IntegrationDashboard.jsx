import React, { useState, useEffect } from 'react';
import IntegrationEventLog from '../components/IntegrationEventLog';
import {
  sendGithubEvent,
  sendJenkinsEvent,
  sendDockerEvent,
  sendCommitEvent,
  sendPullRequestEvent
} from '../api/integration';
import { toast } from 'react-toastify';

const eventTypeOptions = [
  { value: 'commit', label: 'Commit', icon: '📝', color: '#4CAF50' },
  { value: 'pullRequest', label: 'Pull Request', icon: '🔀', color: '#2196F3' },
  { value: 'github', label: 'GitHub', icon: '🐙', color: '#24292e' },
  { value: 'jenkins', label: 'Jenkins', icon: '⚙️', color: '#D33833' },
  { value: 'docker', label: 'Docker', icon: '🐳', color: '#2496ED' },
];

const IntegrationDashboard = () => {
  const [issueKey, setIssueKey] = useState('');
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState('');
  const [author, setAuthor] = useState('');
  const [eventType, setEventType] = useState('commit');
  const [result, setResult] = useState('');
  const [recentEvents, setRecentEvents] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    byType: {},
    successRate: 0
  });

  // Mock recent events for demonstration
  useEffect(() => {
    const mockEvents = [
      { id: 1, type: 'commit', message: 'PROJ-101: Fix login bug', author:'Ranjan', timestamp: '2 minutes ago', status: 'success' },
      { id: 2, type: 'pullRequest', message: 'PROJ-102: Add user profile', author: 'alice', timestamp: '15 minutes ago', status: 'success' },
      { id: 3, type: 'jenkins', message: 'Build #1234', author: 'system', timestamp: '1 hour ago', status: 'failed' },
      { id: 4, type: 'docker', message: 'Container deployed', author: 'devops', timestamp: '2 hours ago', status: 'success' },
      { id: 5, type: 'github', message: 'Issue #45 opened', author: 'bob', timestamp: '3 hours ago', status: 'success' },
    ];
    setRecentEvents(mockEvents);

    // Calculate stats
    const total = mockEvents.length;
    const byType = mockEvents.reduce((acc, event) => {
      acc[event.type] = (acc[event.type] || 0) + 1;
      return acc;
    }, {});
    const successCount = mockEvents.filter(e => e.status === 'success').length;
    const successRate = Math.round((successCount / total) * 100);

    setStats({ total, byType, successRate });
  }, []);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!message.trim() || !author.trim()) {
      toast.error('Please fill in all required fields');
      return;
    }

    setSending(true);
    setResult('');

    try {
      let response;
      switch (eventType) {
        case 'commit':
          response = await sendCommitEvent(message, author);
          break;
        case 'pullRequest':
          response = await sendPullRequestEvent(message, author);
          break;
        case 'github':
          response = await sendGithubEvent('pull_request', {
            title: message,
            author,
            action: 'opened',
            number: Math.floor(Math.random() * 1000) + 1
          });
          break;
        case 'jenkins':
          response = await sendJenkinsEvent({
            name: message,
            result: 'SUCCESS',
            log: 'Build completed successfully',
            buildNumber: Math.floor(Math.random() * 1000) + 1,
            duration: 120000
          });
          break;
        case 'docker':
          response = await sendDockerEvent({
            status: 'create',
            from: 'nginx:latest',
            Actor: {
              Attributes: {
                name: message,
                image: 'nginx:latest',
                tag: 'v1.2.3'
              }
            },
            Type: 'container'
          });
          break;
        default:
          throw new Error('Invalid event type');
      }

      const successMessage = `${eventTypeOptions.find(opt => opt.value === eventType)?.label} event sent successfully!`;
      setResult(successMessage);
      toast.success(successMessage);

      // Add to recent events
      const newEvent = {
        id: Date.now(),
        type: eventType,
        message,
        author,
        timestamp: 'Just now',
        status: 'success'
      };
      setRecentEvents(prev => [newEvent, ...prev.slice(0, 4)]);

      // Clear form
      setMessage('');
      setAuthor('');

    } catch (err) {
      const errorMessage = err.response?.data?.message || 'Failed to send event';
      setResult(`Error: ${errorMessage}`);
      toast.error(errorMessage);

      // Add failed event to recent events
      const failedEvent = {
        id: Date.now(),
        type: eventType,
        message,
        author,
        timestamp: 'Just now',
        status: 'failed'
      };
      setRecentEvents(prev => [failedEvent, ...prev.slice(0, 4)]);
    } finally {
      setSending(false);
    }
  };

  const getEventTypeColor = (type) => {
    return eventTypeOptions.find(opt => opt.value === type)?.color || '#666';
  };

  const getEventIcon = (type) => {
    return eventTypeOptions.find(opt => opt.value === type)?.icon || '📄';
  };

  return (
    <div className="integration-dashboard-container" style={{
      maxWidth: 1200,
      margin: '40px auto',
      background: '#fff',
      borderRadius: 20,
      boxShadow: '0 8px 32px rgba(0,0,0,0.08)',
      padding: 40,
      fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
    }}>
      {/* Header */}
      <div style={{ marginBottom: 40 }}>
        <h2 style={{
          fontSize: 36,
          fontWeight: 800,
          marginBottom: 8,
          letterSpacing: '-0.025em',
          color: '#1a237e',
          display: 'flex',
          alignItems: 'center',
          gap: 16
        }}>
          <span style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            width: 48,
            height: 48,
            borderRadius: 12,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: 28
          }}>🔄</span>
          Integration Dashboard
        </h2>
        <p style={{
          color: '#666',
          fontSize: 18,
          lineHeight: 1.6,
          maxWidth: 800
        }}>
          Send integration events and monitor event logs across all connected services.
        </p>
      </div>

      {/* Stats Overview */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: 20,
        marginBottom: 40
      }}>
        <div style={{
          background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
          color: 'white',
          padding: 24,
          borderRadius: 16,
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: 14, opacity: 0.9 }}>Total Events</div>
          <div style={{ fontSize: 48, fontWeight: 700 }}>{stats.total}</div>
        </div>

        <div style={{
          background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
          color: 'white',
          padding: 24,
          borderRadius: 16,
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: 14, opacity: 0.9 }}>Success Rate</div>
          <div style={{ fontSize: 48, fontWeight: 700 }}>{stats.successRate}%</div>
        </div>

        <div style={{
          background: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
          color: 'white',
          padding: 24,
          borderRadius: 16,
          boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
        }}>
          <div style={{ fontSize: 14, opacity: 0.9 }}>Active Services</div>
          <div style={{ fontSize: 48, fontWeight: 700 }}>{Object.keys(stats.byType).length}</div>
        </div>
      </div>

      {/* Send Event Form */}
      <div style={{
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        borderRadius: 20,
        padding: 32,
        marginBottom: 40,
        boxShadow: '0 8px 32px rgba(102, 126, 234, 0.2)'
      }}>
        <h3 style={{
          color: 'white',
          fontSize: 24,
          fontWeight: 600,
          marginBottom: 24,
          display: 'flex',
          alignItems: 'center',
          gap: 12
        }}>
          <span style={{ fontSize: 28 }}>🚀</span>
          Send Test Event
        </h3>

        <form onSubmit={handleSend} style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: 20,
          alignItems: 'end'
        }}>
          {/* Event Type */}
          <div>
            <label style={{
              fontWeight: 600,
              color: 'rgba(255,255,255,0.9)',
              marginBottom: 8,
              display: 'block',
              fontSize: 14
            }}>
              Event Type
            </label>
            <select
              value={eventType}
              onChange={e => setEventType(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 16px',
                borderRadius: 12,
                border: '2px solid rgba(255,255,255,0.2)',
                background: 'rgba(255,255,255,0.1)',
                color: 'white',
                fontSize: 16,
                cursor: 'pointer',
                backdropFilter: 'blur(10px)',
                transition: 'all 0.2s'
              }}
              onFocus={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.5)'}
              onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.2)'}
            >
              {eventTypeOptions.map(opt => (
                <option
                  key={opt.value}
                  value={opt.value}
                  style={{ background: '#1a237e', color: 'white' }}
                >
                  {opt.icon} {opt.label}
                </option>
              ))}
            </select>
          </div>

          {/* Message Input */}
          <div>
            <label style={{
              fontWeight: 600,
              color: 'rgba(255,255,255,0.9)',
              marginBottom: 8,
              display: 'block',
              fontSize: 14
            }}>
              Message / Title
            </label>
            <input
              value={message}
              onChange={e => setMessage(e.target.value)}
              required
              placeholder="e.g. PROJ-101: Implement login feature"
              style={{
                width: '100%',
                padding: '12px 16px',
                borderRadius: 12,
                border: '2px solid rgba(255,255,255,0.2)',
                background: 'rgba(255,255,255,0.1)',
                color: 'white',
                fontSize: 16,
                transition: 'all 0.2s'
              }}
              onFocus={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.5)'}
              onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.2)'}
            />
          </div>

          {/* Author Input */}
          <div>
            <label style={{
              fontWeight: 600,
              color: 'rgba(255,255,255,0.9)',
              marginBottom: 8,
              display: 'block',
              fontSize: 14
            }}>
              Author
            </label>
            <input
              value={author}
              onChange={e => setAuthor(e.target.value)}
              required
              placeholder="e.g. Ranjan"
              style={{
                width: '100%',
                padding: '12px 16px',
                borderRadius: 12,
                border: '2px solid rgba(255,255,255,0.2)',
                background: 'rgba(255,255,255,0.1)',
                color: 'white',
                fontSize: 16,
                transition: 'all 0.2s'
              }}
              onFocus={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.5)'}
              onBlur={(e) => e.target.style.borderColor = 'rgba(255,255,255,0.2)'}
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={sending}
            style={{
              background: sending ? '#94a3b8' : 'white',
              color: sending ? '#64748b' : '#1a237e',
              fontWeight: 700,
              border: 'none',
              borderRadius: 12,
              padding: '16px 32px',
              fontSize: 16,
              cursor: sending ? 'not-allowed' : 'pointer',
              transition: 'all 0.2s',
              boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
              height: 'fit-content',
              minHeight: 52
            }}
            onMouseOver={(e) => !sending && (e.target.style.transform = 'translateY(-2px)')}
            onMouseOut={(e) => !sending && (e.target.style.transform = 'translateY(0)')}
          >
            {sending ? (
              <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                <span className="spinner" style={{
                  width: 20,
                  height: 20,
                  border: '3px solid rgba(26,35,126,0.2)',
                  borderTopColor: '#1a237e',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite'
                }}></span>
                Sending...
              </span>
            ) : (
              'Send Event'
            )}
          </button>
        </form>

        {result && (
          <div style={{
            marginTop: 20,
            padding: 16,
            background: result.includes('Error') ? 'rgba(220, 38, 38, 0.1)' : 'rgba(34, 197, 94, 0.1)',
            border: `1px solid ${result.includes('Error') ? '#dc2626' : '#22c55e'}`,
            borderRadius: 12,
            color: result.includes('Error') ? '#dc2626' : '#22c55e',
            fontWeight: 600,
            display: 'flex',
            alignItems: 'center',
            gap: 12
          }}>
            {result.includes('Error') ? '❌' : '✅'}
            {result}
          </div>
        )}
      </div>

      {/* Recent Events */}
      <div style={{ marginBottom: 40 }}>
        <h3 style={{
          fontSize: 24,
          fontWeight: 600,
          marginBottom: 24,
          color: '#1a237e',
          display: 'flex',
          alignItems: 'center',
          gap: 12
        }}>
          <span style={{ fontSize: 28 }}>📊</span>
          Recent Events
        </h3>
        <div style={{
          background: '#f8fafc',
          borderRadius: 16,
          overflow: 'hidden',
          boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
        }}>
          {recentEvents.map(event => (
            <div key={event.id} style={{
              padding: 20,
              borderBottom: '1px solid #e2e8f0',
              display: 'flex',
              alignItems: 'center',
              gap: 16,
              transition: 'background 0.2s'
            }}>
              <div style={{
                width: 40,
                height: 40,
                borderRadius: 10,
                background: getEventTypeColor(event.type),
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: 20
              }}>
                {getEventIcon(event.type)}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontWeight: 600,
                  color: '#1e293b',
                  marginBottom: 4
                }}>
                  {event.message}
                </div>
                <div style={{
                  fontSize: 14,
                  color: '#64748b',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 16
                }}>
                  <span>By: {event.author}</span>
                  <span>•</span>
                  <span>{event.timestamp}</span>
                </div>
              </div>
              <span style={{
                padding: '6px 12px',
                borderRadius: 20,
                fontSize: 12,
                fontWeight: 600,
                background: event.status === 'success' ? '#dcfce7' : '#fee2e2',
                color: event.status === 'success' ? '#166534' : '#991b1b'
              }}>
                {event.status === 'success' ? '✅ Success' : '❌ Failed'}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Event Log Section */}
      <div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: 24,
          flexWrap: 'wrap',
          gap: 16
        }}>
          <h3 style={{
            fontSize: 24,
            fontWeight: 600,
            color: '#1a237e',
            display: 'flex',
            alignItems: 'center',
            gap: 12
          }}>
            <span style={{ fontSize: 28 }}>📋</span>
            Event Log
          </h3>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 12,
            background: '#f1f5f9',
            padding: '8px 16px',
            borderRadius: 12
          }}>
            <label style={{
              fontWeight: 600,
              color: '#475569',
              fontSize: 14
            }}>
              Filter by Issue:
            </label>
            <input
              value={issueKey}
              onChange={e => setIssueKey(e.target.value)}
              placeholder="e.g. PROJ-101"
              style={{
                padding: '8px 12px',
                borderRadius: 8,
                border: '1px solid #cbd5e1',
                background: 'white',
                fontSize: 14,
                minWidth: 200
              }}
            />
          </div>
        </div>
        <div style={{
          background: '#f8fafc',
          borderRadius: 16,
          padding: 24,
          boxShadow: '0 4px 20px rgba(0,0,0,0.05)',
          minHeight: 400
        }}>
          <IntegrationEventLog issueKey={issueKey || undefined} />
        </div>
      </div>

      {/* Add some styles for spinner animation */}
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
        ::placeholder {
          color: rgba(255,255,255,0.6);
        }
        select option {
          background: #1a237e;
          color: white;
        }
      `}</style>
    </div>
  );
};

export default IntegrationDashboard;