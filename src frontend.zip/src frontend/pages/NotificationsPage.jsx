import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api/axios';
import { toast } from 'react-toastify';
import {
  HiBell,
  HiCheckCircle,
  HiTrash,
  HiEye,
  HiClock,
  HiUser,
  HiChatAlt,
  HiDocumentText,
  HiExclamation,
  HiArrowRight,
  HiFilter,
  HiRefresh,
  HiArchive,
  HiInboxIn
} from 'react-icons/hi';

const NotificationsPage = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, unread, read
  const [selectedNotifications, setSelectedNotifications] = useState(new Set());
  const [isSelecting, setIsSelecting] = useState(false);
  const [isMarkingAsRead, setIsMarkingAsRead] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();

  const fetchNotifications = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await api.get('/notifications', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Sort by date (newest first) and ensure proper structure
      const sortedNotifications = response.data
        .map(notification => ({
          ...notification,
          id: notification.id || notification._id || Math.random().toString(),
          read: notification.read || notification.isRead || false,
          type: notification.type || 'DEFAULT',
          createdAt: notification.createdAt || notification.timestamp || new Date().toISOString()
        }))
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      setNotifications(sortedNotifications);
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch notifications.';
      toast.error(errorMessage);
      if (error.response?.status === 401) {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const markAsRead = async (notificationId) => {
    try {
      // Optimistically update UI
      setNotifications(prev => prev.map(n =>
        n.id === notificationId ? { ...n, read: true } : n
      ));

      // Trigger global notification refresh
      window.dispatchEvent(new CustomEvent('notifications-updated'));

      await api.put(`/notifications/${notificationId}/read`);

      // Remove from selected if it was selected
      setSelectedNotifications(prev => {
        const next = new Set(prev);
        next.delete(notificationId);
        return next;
      });

    } catch (error) {
      // Revert on error
      setNotifications(prev => prev.map(n =>
        n.id === notificationId ? { ...n, read: false } : n
      ));
      toast.error('Failed to mark notification as read.');
    }
  };

  const markMultipleAsRead = async () => {
    if (selectedNotifications.size === 0) return;

    setIsMarkingAsRead(true);
    try {
      const token = localStorage.getItem('token');
      const notificationIds = Array.from(selectedNotifications);

      // Optimistically update UI
      setNotifications(prev => prev.map(n =>
        selectedNotifications.has(n.id) ? { ...n, read: true } : n
      ));

      window.dispatchEvent(new CustomEvent('notifications-updated'));

      // Mark all selected as read
      await Promise.all(
        notificationIds.map(id =>
          api.put(`/notifications/${id}/read`, {}, {
            headers: { Authorization: `Bearer ${token}` }
          })
        )
      );

      setSelectedNotifications(new Set());
      toast.success(`${notificationIds.length} notification(s) marked as read!`);
    } catch (error) {
      toast.error('Failed to mark notifications as read.');
      // Revert on error - refetch to ensure consistency
      fetchNotifications();
    } finally {
      setIsMarkingAsRead(false);
    }
  };

  const markAllAsRead = async () => {
    try {
      const token = localStorage.getItem('token');

      // Optimistically update UI
      setNotifications(prev => prev.map(n => ({ ...n, read: true })));

      window.dispatchEvent(new CustomEvent('notifications-updated'));

      await api.put(
        '/notifications/read-all',
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setSelectedNotifications(new Set());
      toast.success('All notifications marked as read!');
    } catch (error) {
      toast.error('Failed to mark all as read.');
      fetchNotifications();
    }
  };

  const deleteNotification = async (notificationId) => {
    try {
      const token = localStorage.getItem('token');

      // Optimistically remove from UI
      setNotifications(prev => prev.filter(n => n.id !== notificationId));

      window.dispatchEvent(new CustomEvent('notifications-updated'));

      await api.delete(`/notifications/${notificationId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      // Remove from selected if it was selected
      setSelectedNotifications(prev => {
        const next = new Set(prev);
        next.delete(notificationId);
        return next;
      });

      toast.success('Notification deleted!');
    } catch (error) {
      toast.error('Failed to delete notification.');
      fetchNotifications();
    }
  };

  const deleteSelected = async () => {
    if (selectedNotifications.size === 0) return;

    setIsDeleting(true);
    try {
      const token = localStorage.getItem('token');
      const notificationIds = Array.from(selectedNotifications);

      // Optimistically remove from UI
      setNotifications(prev => prev.filter(n => !selectedNotifications.has(n.id)));

      window.dispatchEvent(new CustomEvent('notifications-updated'));

      // Delete all selected
      await Promise.all(
        notificationIds.map(id =>
          api.delete(`/notifications/${id}`, {
            headers: { Authorization: `Bearer ${token}` }
          })
        )
      );

      setSelectedNotifications(new Set());
      toast.success(`${notificationIds.length} notification(s) deleted!`);
    } catch (error) {
      toast.error('Failed to delete notifications.');
      fetchNotifications();
    } finally {
      setIsDeleting(false);
    }
  };

  const handleNotificationClick = (notification) => {
    // If notification has a link, navigate to it
    if (notification.link) {
      navigate(notification.link);
    }

    // If it's unread, mark it as read
    if (!notification.read) {
      markAsRead(notification.id);
    }
  };

  const toggleSelectNotification = (notificationId) => {
    setSelectedNotifications(prev => {
      const next = new Set(prev);
      if (next.has(notificationId)) {
        next.delete(notificationId);
      } else {
        next.add(notificationId);
      }
      return next;
    });
  };

  const selectAllCurrentPage = () => {
    const currentPageIds = filteredNotifications.map(n => n.id);
    setSelectedNotifications(prev => {
      const next = new Set(prev);
      currentPageIds.forEach(id => next.add(id));
      return next;
    });
  };

  const clearSelection = () => {
    setSelectedNotifications(new Set());
  };

  const getNotificationIcon = (type) => {
    const iconMap = {
      ISSUE: <HiDocumentText className="w-5 h-5" />,
      COMMENT: <HiChatAlt className="w-5 h-5" />,
      MENTION: <HiUser className="w-5 h-5" />,
      ASSIGNMENT: <HiUser className="w-5 h-5" />,
      SPRINT: <HiClock className="w-5 h-5" />,
      BOARD: <HiDocumentText className="w-5 h-5" />,
      WARNING: <HiExclamation className="w-5 h-5" />,
      SUCCESS: <HiCheckCircle className="w-5 h-5" />,
      DEFAULT: <HiBell className="w-5 h-5" />
    };
    return iconMap[type] || iconMap.DEFAULT;
  };

  const getNotificationColor = (type) => {
    const colorMap = {
      ISSUE: 'bg-blue-100 text-blue-600',
      COMMENT: 'bg-green-100 text-green-600',
      MENTION: 'bg-purple-100 text-purple-600',
      ASSIGNMENT: 'bg-amber-100 text-amber-600',
      SPRINT: 'bg-indigo-100 text-indigo-600',
      BOARD: 'bg-cyan-100 text-cyan-600',
      WARNING: 'bg-red-100 text-red-600',
      SUCCESS: 'bg-emerald-100 text-emerald-600',
      DEFAULT: 'bg-gray-100 text-gray-600'
    };
    return colorMap[type] || colorMap.DEFAULT;
  };

  const formatTime = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const filteredNotifications = notifications.filter((notification) => {
    if (filter === 'unread') return !notification.read;
    if (filter === 'read') return notification.read;
    return true;
  });

  const unreadCount = notifications.filter(n => !n.read).length;
  const readCount = notifications.filter(n => n.read).length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-3 border-blue-600 border-t-transparent mb-4"></div>
          <div className="text-xl font-medium text-gray-700">Loading Notifications</div>
          <p className="text-gray-500 mt-2">Fetching your alerts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl">
                <HiBell className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
                <p className="text-gray-600">
                  {unreadCount > 0 ? (
                    <span className="font-medium text-blue-600">{unreadCount} unread</span>
                  ) : (
                    'All caught up!'
                  )}
                  <span className="mx-2">•</span>
                  {notifications.length} total
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => fetchNotifications()}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                title="Refresh"
              >
                <HiRefresh className="w-5 h-5" />
              </button>
              <button
                onClick={markAllAsRead}
                disabled={unreadCount === 0}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <HiCheckCircle className="w-4 h-4" />
                <span>Mark All Read</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Bulk Actions Bar */}
        {(isSelecting || selectedNotifications.size > 0) && (
          <div className="bg-white border border-gray-200 rounded-xl p-4 mb-6 shadow-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={selectedNotifications.size === filteredNotifications.length}
                    onChange={() => {
                      if (selectedNotifications.size === filteredNotifications.length) {
                        clearSelection();
                      } else {
                        selectAllCurrentPage();
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="text-gray-700">
                    {selectedNotifications.size} selected
                  </span>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={markMultipleAsRead}
                  disabled={isMarkingAsRead || selectedNotifications.size === 0}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  {isMarkingAsRead ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Marking...</span>
                    </>
                  ) : (
                    <>
                      <HiCheckCircle className="w-4 h-4" />
                      <span>Mark Read</span>
                    </>
                  )}
                </button>
                <button
                  onClick={deleteSelected}
                  disabled={isDeleting || selectedNotifications.size === 0}
                  className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  {isDeleting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <HiTrash className="w-4 h-4" />
                      <span>Delete</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => {
                    setIsSelecting(false);
                    clearSelection();
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Filters & Stats */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-3">
                <HiFilter className="w-5 h-5 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Filter by:</span>
              </div>
              <div className="flex space-x-2">
                {[
                  { key: 'all', label: 'All', count: notifications.length },
                  { key: 'unread', label: 'Unread', count: unreadCount },
                  { key: 'read', label: 'Read', count: readCount }
                ].map(({ key, label, count }) => (
                  <button
                    key={key}
                    onClick={() => {
                      setFilter(key);
                      clearSelection();
                    }}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors flex items-center space-x-2 ${
                      filter === key
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <span>{label}</span>
                    <span className={`px-1.5 py-0.5 text-xs rounded-full ${
                      filter === key ? 'bg-blue-200' : 'bg-gray-200'
                    }`}>
                      {count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center space-x-3">
              {!isSelecting && (
                <button
                  onClick={() => setIsSelecting(true)}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center space-x-2"
                >
                  <HiEye className="w-4 h-4" />
                  <span>Select Multiple</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-4">
          {filteredNotifications.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-12 text-center">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <HiBell className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">No notifications</h3>
              <p className="text-gray-600 max-w-md mx-auto mb-6">
                {filter === 'unread'
                  ? "You're all caught up! No unread notifications."
                  : filter === 'read'
                  ? "You haven't read any notifications yet."
                  : "You don't have any notifications yet."}
              </p>
              {filter !== 'all' && (
                <button
                  onClick={() => setFilter('all')}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  View all notifications
                </button>
              )}
            </div>
          ) : (
            filteredNotifications.map((notification) => {
              const message = notification.message || notification.title || notification.content || '';
              const isSelected = selectedNotifications.has(notification.id);

              return (
                <div
                  key={notification.id}
                  className={`bg-white rounded-xl border transition-all duration-200 hover:border-blue-300 hover:shadow-md ${
                    isSelected ? 'border-blue-500 bg-blue-50' :
                    !notification.read ? 'border-blue-200' : 'border-gray-200'
                  }`}
                >
                  <div className="p-5">
                    <div className="flex items-start gap-4">
                      {/* Selection Checkbox */}
                      {isSelecting && (
                        <div className="pt-1">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => toggleSelectNotification(notification.id)}
                            className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          />
                        </div>
                      )}

                      {/* Icon */}
                      <div className={`p-3 rounded-lg ${getNotificationColor(notification.type)}`}>
                        {getNotificationIcon(notification.type)}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0" onClick={() => handleNotificationClick(notification)}>
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex-1 min-w-0">
                            <p className={`font-medium truncate ${
                              !notification.read ? 'text-gray-900' : 'text-gray-700'
                            }`}>
                              {message}
                            </p>
                            {notification.description && (
                              <p className="text-gray-600 text-sm mt-1 line-clamp-2">
                                {notification.description}
                              </p>
                            )}
                          </div>
                          {!notification.read && (
                            <span className="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                              New
                            </span>
                          )}
                        </div>

                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span className="flex items-center">
                              <HiClock className="w-4 h-4 mr-1" />
                              {formatTime(notification.createdAt)}
                            </span>
                            {notification.type && (
                              <span className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-xs">
                                {notification.type.replace('_', ' ').toLowerCase()}
                              </span>
                            )}
                          </div>

                          {notification.link && (
                            <Link
                              to={notification.link}
                              className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center space-x-1"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <span>View</span>
                              <HiArrowRight className="w-4 h-4" />
                            </Link>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col space-y-2 ml-4">
                        {!notification.read && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              markAsRead(notification.id);
                            }}
                            className="p-2 text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors flex items-center justify-center"
                            title="Mark as read"
                          >
                            <HiCheckCircle className="w-5 h-5" />
                          </button>
                        )}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                          className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center"
                          title="Delete notification"
                        >
                          <HiTrash className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Empty state for no notifications at all */}
        {notifications.length === 0 && !loading && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <HiInboxIn className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">No notifications yet</h3>
            <p className="text-gray-600 max-w-md mx-auto mb-6">
              You'll see notifications here when someone mentions you, assigns you tasks, or comments on your issues.
            </p>
            <button
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <span>Go to Dashboard</span>
              <HiArrowRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {/* Refresh listener */}
      <style jsx>{`
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
};

export default NotificationsPage;