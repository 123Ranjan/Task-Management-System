import React, { useState, useEffect } from 'react';
import { HiOutlinePlus } from "react-icons/hi";
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import { isAdmin } from '../utils/permissions';

const BoardsPage = () => {
  const [boards, setBoards] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [boardName, setBoardName] = useState('');
  const [projectKey, setProjectKey] = useState('');
  const [boardType, setBoardType] = useState('KANBAN');
  const [creating, setCreating] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState('grid'); // 'grid' or 'list'
  const navigate = useNavigate();

  const admin = isAdmin();

  const fetchBoards = async () => {
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('Session expired. Please login again.');
        navigate('/login');
        return;
      }

      const response = await axios.get('/boards', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setBoards(Array.isArray(response.data) ? response.data : []);
    } catch (error) {
      if (error.response?.status === 404 || error.response?.status === 405) {
        setBoards([]);
        toast.info('No boards available yet. Create your first board!');
      } else if (error.response?.status === 403) {
        toast.error('You do not have permission to view boards.');
        setBoards([]);
      } else if (error.response?.status !== 401) {
        const errorMessage =
          error.response?.data?.message || 'Failed to fetch boards.';
        toast.error(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBoards();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCreateBoard = async (e) => {
    e.preventDefault();
    setCreating(true);

    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        '/boards/create_board',
        {
          boardName,
          projectKey,
          boardType
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Board created successfully!');
      await fetchBoards();
      setBoardName('');
      setProjectKey('');
      setBoardType('KANBAN');
      setShowModal(false);
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || 'Failed to create board.';
      toast.error(errorMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleBoardClick = (boardId) => {
    navigate(`/boards/${boardId}`);
  };

  const handleDeleteBoard = async (boardId, boardNameForMsg) => {
    if (!admin) return;
    const ok = window.confirm(`Delete board "${boardNameForMsg || boardId}"? This action cannot be undone.`);
    if (!ok) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/boards/${boardId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Board deleted successfully');
      await fetchBoards();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to delete board.';
      toast.error(errorMessage);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getBoardTypeColor = (type) => {
    return type === 'SCRUM' 
      ? 'from-emerald-500 to-green-600' 
      : 'from-indigo-500 to-purple-600';
  };

  const getBoardTypeIcon = (type) => {
    return type === 'SCRUM' ? '🏃' : '📊';
  };

  const getBoardTypeBadge = (type) => {
    return type === 'SCRUM' 
      ? 'bg-emerald-100 text-emerald-700 border-emerald-200' 
      : 'bg-indigo-100 text-indigo-700 border-indigo-200';
  };

  // Filter boards based on search term
  const filteredBoards = boards.filter(board => 
    (board.name || board.boardName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (board.projectKey || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (board.boardType || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
          <div className="text-lg font-medium text-gray-700">Loading boards...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Enhanced Header */}
      <header className="bg-gradient-to-r from-indigo-700 to-purple-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center text-white hover:text-indigo-200 transition-colors group"
              >
                <svg className="w-5 h-5 mr-2 transform group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                Back to Dashboard
              </button>
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-white/10 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <span className="text-2xl text-white">📋</span>
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-white">Boards</h1>
                  <p className="text-indigo-200 text-sm">Organize and track your work visually</p>
                </div>
              </div>
            </div>
            {admin && (
              <button
                onClick={() => setShowModal(true)}
                className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center space-x-2 group"
              >
                <span className="text-xl">+</span>
                <span>Create Board</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Controls Bar */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
            <div className="flex-1 w-full">
              <div className="relative">
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search boards by name, project key, or type..."
                  className="w-full px-4 py-3 pl-12 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
                <svg className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center bg-gray-100 rounded-lg p-1">
                <button
                  onClick={() => setViewMode('grid')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-3 py-1.5 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
                  </svg>
                </button>
              </div>
              
              <div className="text-sm text-gray-600 bg-gray-100 px-3 py-1.5 rounded-lg">
                <span className="font-semibold text-gray-800">{filteredBoards.length}</span> boards
              </div>
            </div>
          </div>
        </div>

        {/* Empty State */}
        {filteredBoards.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-6xl mb-6">📋</div>
            <h3 className="text-xl font-semibold text-gray-800 mb-2">
              {boards.length === 0 ? 'No boards yet' : 'No matching boards found'}
            </h3>
            <p className="text-gray-600 mb-6">
              {boards.length === 0 
                ? 'Create your first board to organize your work' 
                : 'Try adjusting your search terms'}
            </p>
            {admin && (
              <button
                onClick={() => setShowModal(true)}
                className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl"
              >
                Create Your First Board
              </button>
            )}
          </div>
        ) : viewMode === 'grid' ? (
          /* Grid View */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBoards.map((board) => (
              <div
                key={board.id}
                className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow group cursor-pointer relative"
                onClick={() => handleBoardClick(board.id)}
              >
                {admin && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteBoard(board.id, board.name || board.boardName);
                    }}
                    className="absolute top-4 right-4 z-10 w-8 h-8 bg-white/90 hover:bg-white text-red-600 rounded-lg flex items-center justify-center shadow-md hover:shadow-lg transition-all opacity-0 group-hover:opacity-100"
                    title="Delete board"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                )}

                {/* Board Header */}
                <div className={`bg-gradient-to-r ${getBoardTypeColor(board.boardType)} h-32 relative overflow-hidden`}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-5xl opacity-20">{getBoardTypeIcon(board.boardType)}</span>
                  </div>
                  <div className="relative h-full flex flex-col justify-between p-6">
                    <div className="flex justify-between items-start">
                      <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                        <span className="text-2xl text-white">{getBoardTypeIcon(board.boardType)}</span>
                      </div>
                      <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getBoardTypeBadge(board.boardType)}`}>
                        {board.boardType || 'KANBAN'}
                      </span>
                    </div>
                    <div className="mt-auto">
                      <h3 className="text-xl font-bold text-white truncate">
                        {board.name || board.boardName}
                      </h3>
                    </div>
                  </div>
                </div>

                {/* Board Details */}
                <div className="p-6">
                  <div className="space-y-4">
                    {board.projectKey && (
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">Project Key</span>
                        <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm font-mono rounded-lg">
                          {board.projectKey}
                        </span>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Created</span>
                      <span className="text-sm text-gray-600">
                        {formatDate(board.createdDate || board.createdAt)}
                      </span>
                    </div>
                    
                    <div className="pt-4 border-t border-gray-100">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">Click to open</span>
                        <svg className="w-5 h-5 text-gray-400 group-hover:text-indigo-500 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* List View */
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-100">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Board</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Project</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Created</th>
                    <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-100">
                  {filteredBoards.map((board) => (
                    <tr key={board.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${board.boardType === 'SCRUM' ? 'bg-emerald-100 text-emerald-600' : 'bg-indigo-100 text-indigo-600'}`}>
                            <span className="text-xl">{getBoardTypeIcon(board.boardType)}</span>
                          </div>
                          <button
                            onClick={() => handleBoardClick(board.id)}
                            className="text-left group"
                          >
                            <div className="text-sm font-medium text-gray-900 group-hover:text-indigo-600 transition-colors">
                              {board.name || board.boardName}
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {board.boardType === 'SCRUM' ? 'Sprint-based workflow' : 'Continuous workflow'}
                            </div>
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 text-xs font-semibold rounded-full ${getBoardTypeBadge(board.boardType)}`}>
                          {board.boardType || 'KANBAN'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {board.projectKey ? (
                          <span className="px-3 py-1 bg-gray-100 text-gray-700 text-sm font-mono rounded-lg">
                            {board.projectKey}
                          </span>
                        ) : (
                          <span className="text-sm text-gray-400 italic">No project</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                        {formatDate(board.createdDate || board.createdAt)}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleBoardClick(board.id)}
                            className="px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white text-sm font-medium rounded-lg transition-all shadow hover:shadow-md"
                          >
                            Open Board
                          </button>
                          {admin && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteBoard(board.id, board.name || board.boardName);
                              }}
                              className="px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg text-sm font-medium transition-colors"
                            >
                              Delete
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>

      {/* Create Board Modal - Enhanced */}
      {admin && showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-white">Create New Board</h2>
                  <p className="text-indigo-200 text-sm mt-1">Start organizing your workflow visually</p>
                </div>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setBoardName('');
                    setProjectKey('');
                    setBoardType('KANBAN');
                  }}
                  className="text-white/80 hover:text-white text-2xl transition-colors"
                >
                  ×
                </button>
              </div>
            </div>
            
            <form onSubmit={handleCreateBoard} className="p-6 space-y-5">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Board Name *
                </label>
                <input
                  type="text"
                  value={boardName}
                  onChange={(e) => setBoardName(e.target.value)}
                  placeholder="e.g., Product Development, Marketing Tasks"
                  required
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                  autoFocus
                />
                <p className="text-xs text-gray-500 mt-2">
                  Choose a descriptive name for your board
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Project Key *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={projectKey}
                    onChange={(e) => setProjectKey(e.target.value.toUpperCase())}
                    placeholder="PROJ, TM, APP"
                    required
                    maxLength={10}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent uppercase font-mono"
                  />
                  <div className="absolute right-3 top-3 text-sm text-gray-400 font-mono">
                    {10 - projectKey.length}
                  </div>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Short identifier for your project (2-10 uppercase characters)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Board Type *
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setBoardType('KANBAN')}
                    className={`p-4 border rounded-xl flex flex-col items-center justify-center transition-all ${boardType === 'KANBAN' ? 'bg-indigo-50 border-indigo-500 ring-2 ring-indigo-500/20' : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'}`}
                  >
                    <div className="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center mb-2">
                      <span className="text-xl">📊</span>
                    </div>
                    <span className="font-medium text-gray-900">Kanban</span>
                    <span className="text-xs text-gray-500 mt-1">Continuous flow</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setBoardType('SCRUM')}
                    className={`p-4 border rounded-xl flex flex-col items-center justify-center transition-all ${boardType === 'SCRUM' ? 'bg-emerald-50 border-emerald-500 ring-2 ring-emerald-500/20' : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'}`}
                  >
                    <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center mb-2">
                      <span className="text-xl">🏃</span>
                    </div>
                    <span className="font-medium text-gray-900">Scrum</span>
                    <span className="text-xs text-gray-500 mt-1">Sprint-based</span>
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  {boardType === 'KANBAN' 
                    ? 'Kanban: Focus on continuous delivery with WIP limits' 
                    : 'Scrum: Plan work in time-boxed sprints with goals'}
                </p>
              </div>

              <div className="flex justify-end space-x-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setShowModal(false);
                    setBoardName('');
                    setProjectKey('');
                    setBoardType('KANBAN');
                  }}
                  className="px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {creating ? (
                    <div className="flex items-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Creating...
                    </div>
                  ) : 'Create Board'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default BoardsPage;
