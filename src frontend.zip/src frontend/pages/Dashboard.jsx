
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';

const Dashboard = () => {
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    boards: 0,
    issues: 0,
    completed: 0,
    inProgress: 0
  });
  const [recentActivity, setRecentActivity] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const token = localStorage.getItem('token');
        const [profileRes, boardsRes, issuesRes] = await Promise.all([
          axios.get('/user/profile', {
            headers: { Authorization: `Bearer ${token}` },
          }),
          axios.get('/boards', {
            headers: { Authorization: `Bearer ${token}` },
          }),
          axios.get('/backLogs/1', { // Assuming default project ID 1
            headers: { Authorization: `Bearer ${token}` },
          }),
        ]);

        setProfile(profileRes.data);
        localStorage.setItem('username', profileRes.data.username || 'User');

        // Calculate stats
        const boards = Array.isArray(boardsRes.data) ? boardsRes.data.length : 0;
        const issues = Array.isArray(issuesRes.data) ? issuesRes.data.length : 0;
        const completed = Array.isArray(issuesRes.data) 
          ? issuesRes.data.filter(issue => issue.issueStatus === 'DONE').length 
          : 0;
        const inProgress = Array.isArray(issuesRes.data)
          ? issuesRes.data.filter(issue => issue.issueStatus === 'IN_PROGRESS').length
          : 0;

        setStats({ boards, issues, completed, inProgress });

        // Mock recent activity (you can replace with actual API call)
        setRecentActivity([
          { id: 1, action: 'created', type: 'issue', title: 'Implement login feature', user: profileRes.data.username, time: '2 hours ago' },
          { id: 2, action: 'moved', type: 'issue', title: 'Fix header alignment', user: 'John Doe', time: '4 hours ago' },
          { id: 3, action: 'commented', type: 'issue', title: 'API documentation', user: 'Jane Smith', time: '1 day ago' },
          { id: 4, action: 'assigned', type: 'issue', title: 'Mobile responsiveness', user: profileRes.data.username, time: '2 days ago' },
        ]);

      } catch (error) {
        const errorMessage =
          error.response?.data?.message || 'Failed to fetch dashboard data.';
        toast.error(errorMessage);
        if (error.response?.status === 401) {
          localStorage.removeItem('token');
          navigate('/login');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mb-4"></div>
          <div className="text-lg font-medium text-gray-700">Loading dashboard...</div>
        </div>
      </div>
    );
  }

  const cards = [
    {
      title: 'Boards',
      description: 'View and manage your project boards',
      icon: (
        <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
          <span className="text-2xl text-white">📋</span>
        </div>
      ),
      link: '/boards',
      value: stats.boards,
      color: 'from-indigo-500 to-purple-600',
      hoverColor: 'hover:from-indigo-600 hover:to-purple-700',
    },
    {
      title: 'Backlog Items',
      description: 'Manage your backlog and prioritize tasks',
      icon: (
        <div className="w-12 h-12 bg-gradient-to-r from-emerald-500 to-green-600 rounded-xl flex items-center justify-center">
          <span className="text-2xl text-white">📝</span>
        </div>
      ),
      link: '/backlog',
      value: stats.issues,
      color: 'from-emerald-500 to-green-600',
      hoverColor: 'hover:from-emerald-600 hover:to-green-700',
    },
    {
      title: 'In Progress',
      description: 'Tasks currently being worked on',
      icon: (
        <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center">
          <span className="text-2xl text-white">🏃</span>
        </div>
      ),
      link: '/boards',
      value: stats.inProgress,
      color: 'from-amber-500 to-orange-600',
      hoverColor: 'hover:from-amber-600 hover:to-orange-700',
    },
    {
      title: 'Completed',
      description: 'Tasks that are finished',
      icon: (
        <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-xl flex items-center justify-center">
          <span className="text-2xl text-white">✅</span>
        </div>
      ),
      link: '/boards',
      value: stats.completed,
      color: 'from-blue-500 to-cyan-600',
      hoverColor: 'hover:from-blue-600 hover:to-cyan-700',
    },
  ];

  const quickActions = [
    {
      title: 'Create New Board',
      description: 'Start organizing your work visually',
      icon: '📋',
      link: '/boards',
      color: 'bg-gradient-to-r from-indigo-600 to-purple-600',
      hoverColor: 'hover:from-indigo-700 hover:to-purple-700',
    },
    {
      title: 'Create New Issue',
      description: 'Add tasks to your backlog',
      icon: '📝',
      link: '/backlog',
      color: 'bg-gradient-to-r from-emerald-600 to-green-600',
      hoverColor: 'hover:from-emerald-700 hover:to-green-700',
    },
    {
      title: 'View Notifications',
      description: 'Check your latest updates',
      icon: '🔔',
      link: '/notifications',
      color: 'bg-gradient-to-r from-amber-600 to-orange-600',
      hoverColor: 'hover:from-amber-700 hover:to-orange-700',
    },
  ];

  const getActionIcon = (action) => {
    const icons = {
      created: '➕',
      moved: '➡️',
      commented: '💬',
      assigned: '👤',
      completed: '✅',
    };
    return icons[action] || '⚡';
  };

  const getActionColor = (action) => {
    const colors = {
      created: 'bg-blue-100 text-blue-700',
      moved: 'bg-indigo-100 text-indigo-700',
      commented: 'bg-purple-100 text-purple-700',
      assigned: 'bg-emerald-100 text-emerald-700',
      completed: 'bg-green-100 text-green-700',
    };
    return colors[action] || 'bg-gray-100 text-gray-700';
  };

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-indigo-700 to-purple-800 rounded-2xl shadow-xl p-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-white mb-2">
              Welcome back, {profile?.username || 'User'}! 👋
            </h1>
            <p className="text-indigo-200 text-lg">
              Here's what's happening with your projects today
            </p>
            <div className="flex flex-wrap gap-4 mt-6">
              <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
                <div className="text-xs text-indigo-200">Member since</div>
                <div className="text-sm font-medium text-white">
                  {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : 'Today'}
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm px-4 py-2 rounded-xl">
                <div className="text-xs text-indigo-200">Role</div>
                <div className="text-sm font-medium text-white">
                  {profile?.role || 'Team Member'}
                </div>
              </div>
            </div>
          </div>
          <div className="w-24 h-24 bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg">
            <span className="text-4xl text-white font-bold">
              {profile?.username?.charAt(0).toUpperCase() || 'U'}
            </span>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((card, index) => (
          <div
            key={index}
            onClick={() => navigate(card.link)}
            className="bg-white rounded-2xl shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 cursor-pointer group"
          >
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                {card.icon}
                <div className="text-3xl font-bold text-gray-800 group-hover:scale-110 transition-transform">
                  {card.value}
                </div>
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-1">
                {card.title}
              </h3>
              <p className="text-sm text-gray-600">{card.description}</p>
              <div className="mt-4 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className={`h-full bg-gradient-to-r ${card.color} transition-all duration-500`}
                  style={{ 
                    width: `${card.value > 0 ? Math.min((card.value / (stats.issues || 1)) * 100, 100) : 0}%` 
                  }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold text-gray-800">Quick Actions</h2>
              <span className="text-sm text-gray-500">Jump right in</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {quickActions.map((action, index) => (
                <button
                  key={index}
                  onClick={() => navigate(action.link)}
                  className={`${action.color} ${action.hoverColor} text-white rounded-xl p-5 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-left group`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-3xl">{action.icon}</span>
                    <svg className="w-5 h-5 text-white/70 group-hover:text-white transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold mb-1">{action.title}</h3>
                  <p className="text-sm text-white/80">{action.description}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Profile Summary */}
          <div className="bg-white rounded-2xl shadow-lg p-6 mt-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-6">Profile Summary</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                    <span className="text-xl text-indigo-600">👤</span>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-700">Username</div>
                    <div className="text-lg font-semibold text-gray-900">{profile?.username || 'N/A'}</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                    <span className="text-xl text-emerald-600">📧</span>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-700">Email</div>
                    <div className="text-lg font-semibold text-gray-900 truncate">{profile?.email || 'N/A'}</div>
                  </div>
                </div>
              </div>
              
              <div className="md:col-span-2">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="text-sm font-medium text-gray-700 mb-1">Assigned Issues</div>
                    <div className="text-2xl font-bold text-gray-900">{profile?.assignedIssuesCount || 0}</div>
                    <div className="text-xs text-gray-500 mt-1">Tasks assigned to you</div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="text-sm font-medium text-gray-700 mb-1">Created Issues</div>
                    <div className="text-2xl font-bold text-gray-900">{profile?.createdIssuesCount || 0}</div>
                    <div className="text-xs text-gray-500 mt-1">Tasks you created</div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="text-sm font-medium text-gray-700 mb-1">Notifications</div>
                    <div className="text-2xl font-bold text-gray-900">{profile?.notificationsCount || 0}</div>
                    <div className="text-xs text-gray-500 mt-1">Unread notifications</div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-4">
                    <div className="text-sm font-medium text-gray-700 mb-1">Active Boards</div>
                    <div className="text-2xl font-bold text-gray-900">{stats.boards}</div>
                    <div className="text-xs text-gray-500 mt-1">Boards you can access</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Recent Activity</h2>
            <span className="text-sm text-gray-500">Last 7 days</span>
          </div>
          
          <div className="space-y-4">
            {recentActivity.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-3">📊</div>
                <p className="text-gray-500">No recent activity</p>
              </div>
            ) : (
              recentActivity.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-xl transition-colors">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getActionColor(activity.action)}`}>
                    <span className="text-sm">{getActionIcon(activity.action)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-900">{activity.user}</span>
                      <span className="text-xs text-gray-500">{activity.time}</span>
                    </div>
                    <p className="text-sm text-gray-600">
                      <span className="font-medium">{activity.action}</span> {activity.type} "{activity.title}"
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="mt-6 pt-6 border-t border-gray-100">
            <div className="text-center">
              <button
                onClick={() => navigate('/notifications')}
                className="text-indigo-600 hover:text-indigo-700 font-medium text-sm flex items-center justify-center space-x-1 w-full"
              >
                <span>View all activity</span>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Productivity Tips */}
      <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6">
        <div className="flex items-start space-x-4">
          <div className="w-12 h-12 bg-gradient-to-r from-amber-500 to-orange-600 rounded-xl flex items-center justify-center flex-shrink-0">
            <span className="text-2xl text-white">💡</span>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">Productivity Tip</h3>
            <p className="text-gray-600 mb-3">
              Try grouping similar tasks together on your board. This helps maintain focus and improves workflow efficiency.
            </p>
            <button
              onClick={() => navigate('/boards')}
              className="text-amber-700 hover:text-amber-800 font-medium text-sm flex items-center space-x-1"
            >
              <span>Try it now</span>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
