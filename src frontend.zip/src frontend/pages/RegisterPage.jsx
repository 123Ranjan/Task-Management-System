import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import {
  HiUser,
  HiMail,
  HiKey,
  HiEye,
  HiEyeOff,
  HiArrowRight,
  HiCheckCircle,
  HiXCircle,
  HiShieldCheck,
  HiUserGroup,
  HiSparkles
} from 'react-icons/hi';

const RegisterPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: ''
  });

  const [showPassword, setShowPassword] = useState({
    password: false,
    confirmPassword: false
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState(0);
  const [touched, setTouched] = useState({});
  const [availableRoles, setAvailableRoles] = useState([
    { value: 'ADMIN', label: 'Admin', description: 'Full system access' },
    { value: 'DEVELOPER', label: 'Developer', description: 'Create and manage issues' },
    { value: 'MANAGER', label: 'Manager', description: 'Team and project management' },
    { value: 'TESTER', label: 'Tester', description: 'Testing and quality assurance' },
    { value: 'DEVOPS', label: 'DevOps', description: 'Infrastructure and deployment' },
    { value: 'SUPPORT', label: 'Support', description: 'Customer support and assistance' },
    { value: 'VIEWER', label: 'Viewer', description: 'Read-only access' }
  ]);

  const navigate = useNavigate();

  // Password strength calculator
  useEffect(() => {
    if (!formData.password) {
      setPasswordStrength(0);
      return;
    }

    let strength = 0;

    // Length check
    if (formData.password.length >= 8) strength += 25;
    if (formData.password.length >= 12) strength += 10;

    // Complexity checks
    if (/[a-z]/.test(formData.password)) strength += 15;
    if (/[A-Z]/.test(formData.password)) strength += 15;
    if (/[0-9]/.test(formData.password)) strength += 15;
    if (/[^A-Za-z0-9]/.test(formData.password)) strength += 20;

    setPasswordStrength(Math.min(strength, 100));
  }, [formData.password]);

  const validateField = (name, value) => {
    const newErrors = { ...errors };

    switch (name) {
      case 'name':
        if (!value.trim()) {
          newErrors[name] = 'Name is required';
        } else if (value.length < 2) {
          newErrors[name] = 'Name must be at least 2 characters';
        } else {
          delete newErrors[name];
        }
        break;

      case 'email':
        if (!value.trim()) {
          newErrors[name] = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          newErrors[name] = 'Please enter a valid email address';
        } else {
          delete newErrors[name];
        }
        break;

      case 'password':
        if (!value) {
          newErrors[name] = 'Password is required';
        } else if (value.length < 8) {
          newErrors[name] = 'Password must be at least 8 characters';
        } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(value)) {
          newErrors[name] = 'Password must include uppercase, lowercase, and numbers';
        } else {
          delete newErrors[name];
        }
        break;

      case 'confirmPassword':
        if (!value) {
          newErrors[name] = 'Please confirm your password';
        } else if (value !== formData.password) {
          newErrors[name] = 'Passwords do not match';
        } else {
          delete newErrors[name];
        }
        break;

      case 'role':
        if (!value) {
          newErrors[name] = 'Please select a role';
        } else {
          delete newErrors[name];
        }
        break;

      default:
        break;
    }

    setErrors(newErrors);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));

    if (touched[name]) {
      validateField(name, value);
    }
  };

  const handleBlur = (e) => {
    const { name } = e.target;
    setTouched(prev => ({ ...prev, [name]: true }));
    validateField(name, formData[name]);
  };

  const togglePasswordVisibility = (field) => {
    setShowPassword(prev => ({
      ...prev,
      [field]: !prev[field]
    }));
  };

  const getPasswordStrengthColor = () => {
    if (passwordStrength < 40) return 'bg-red-500';
    if (passwordStrength < 70) return 'bg-yellow-500';
    if (passwordStrength < 90) return 'bg-blue-500';
    return 'bg-green-500';
  };

  const getPasswordStrengthText = () => {
    if (passwordStrength < 40) return 'Weak';
    if (passwordStrength < 70) return 'Fair';
    if (passwordStrength < 90) return 'Good';
    return 'Strong';
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Mark all fields as touched
    const allTouched = Object.keys(formData).reduce((acc, key) => {
      acc[key] = true;
      return acc;
    }, {});
    setTouched(allTouched);

    // Validate all fields
    Object.keys(formData).forEach(key => {
      validateField(key, formData[key]);
    });

    // Check if there are any errors
    if (Object.keys(errors).length > 0) {
      toast.error('Please fix the errors in the form');
      return;
    }

    setLoading(true);

    try {
      const payload = {
        userName: formData.name,
        userEmail: formData.email,
        password: formData.password,
        role: formData.role,
      };

      const response = await axios.post('/userAuthentication/register', payload);

      // Store user info if auto-login is enabled
      if (response.data.token) {
        const { token, userId, userName, role: userRole, permissions } = response.data;
        localStorage.setItem('token', token);
        if (userId) localStorage.setItem('userId', userId);
        if (userName) localStorage.setItem('username', userName);
        if (userRole) localStorage.setItem('userRole', userRole);
        if (permissions) localStorage.setItem('userPermissions', JSON.stringify(permissions));

        toast.success(
          <div className="flex items-center space-x-2">
            <HiSparkles className="w-5 h-5" />
            <span>Registration successful! Welcome aboard!</span>
          </div>
        );
        navigate('/dashboard');
      } else {
        toast.success(
          <div className="flex items-center space-x-2">
            <HiCheckCircle className="w-5 h-5" />
            <span>Registration successful! Please login to continue.</span>
          </div>
        );
        navigate('/login', { state: { registered: true } });
      }
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Registration failed. Please try again.';
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getRoleIcon = (roleValue) => {
    const icons = {
      ADMIN: <HiShieldCheck className="w-5 h-5" />,
      DEVELOPER: <HiUser className="w-5 h-5" />,
      MANAGER: <HiUserGroup className="w-5 h-5" />,
      TESTER: <HiCheckCircle className="w-5 h-5" />,
      DEVOPS: <HiSparkles className="w-5 h-5" />,
      SUPPORT: <HiUser className="w-5 h-5" />,
      VIEWER: <HiEye className="w-5 h-5" />
    };
    return icons[roleValue] || <HiUser className="w-5 h-5" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 flex items-center justify-center p-4">
      {/* Background Animation */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
      </div>

      {/* Main Card */}
      <div className="relative w-full max-w-4xl">
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            {/* Left Side - Welcome/Info */}
            <div className="p-12 bg-gradient-to-br from-blue-600/20 to-purple-600/20 lg:flex lg:flex-col lg:justify-between">
              <div>
                <div className="flex items-center space-x-3 mb-8">
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                    <HiSparkles className="w-6 h-6 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold text-white">IssueTracker Pro</h1>
                </div>

                <h2 className="text-4xl font-bold text-white mb-6">
                  Join Our Team
                </h2>

                <div className="space-y-6 mb-8">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <HiCheckCircle className="w-5 h-5 text-green-300" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">Track & Manage Issues</h3>
                      <p className="text-white/80">Efficiently manage projects and tasks</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <HiUserGroup className="w-5 h-5 text-blue-300" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">Team Collaboration</h3>
                      <p className="text-white/80">Work together seamlessly</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <HiShieldCheck className="w-5 h-5 text-purple-300" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-white">Secure & Reliable</h3>
                      <p className="text-white/80">Enterprise-grade security</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="hidden lg:block">
                <p className="text-white/70 text-sm">
                  Already have an account?{' '}
                  <Link to="/login" className="text-white font-semibold hover:underline">
                    Sign in here →
                  </Link>
                </p>
              </div>
            </div>

            {/* Right Side - Registration Form */}
            <div className="p-12">
              <div className="mb-8">
                <h2 className="text-3xl font-bold text-white mb-2">Create Account</h2>
                <p className="text-white/70">Join thousands of teams already using IssueTracker Pro</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name Field */}
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <HiUser className="inline w-4 h-4 mr-2" />
                    Full Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                      errors.name ? 'border-red-500' : 'border-white/10'
                    }`}
                    placeholder="Enter your full name"
                  />
                  {errors.name && (
                    <p className="mt-2 text-sm text-red-300 flex items-center">
                      <HiXCircle className="w-4 h-4 mr-1" />
                      {errors.name}
                    </p>
                  )}
                </div>

                {/* Email Field */}
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <HiMail className="inline w-4 h-4 mr-2" />
                    Email Address
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all ${
                      errors.email ? 'border-red-500' : 'border-white/10'
                    }`}
                    placeholder="you@example.com"
                  />
                  {errors.email && (
                    <p className="mt-2 text-sm text-red-300 flex items-center">
                      <HiXCircle className="w-4 h-4 mr-1" />
                      {errors.email}
                    </p>
                  )}
                </div>

                {/* Password Field */}
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <HiKey className="inline w-4 h-4 mr-2" />
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword.password ? 'text' : 'password'}
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all pr-12 ${
                        errors.password ? 'border-red-500' : 'border-white/10'
                      }`}
                      placeholder="Create a strong password"
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('password')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/50 hover:text-white transition-colors"
                    >
                      {showPassword.password ? (
                        <HiEyeOff className="w-5 h-5" />
                      ) : (
                        <HiEye className="w-5 h-5" />
                      )}
                    </button>
                  </div>

                  {/* Password Strength Meter */}
                  {formData.password && (
                    <div className="mt-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-white/70">Password strength</span>
                        <span className={`font-medium ${
                          passwordStrength < 40 ? 'text-red-400' :
                          passwordStrength < 70 ? 'text-yellow-400' :
                          passwordStrength < 90 ? 'text-blue-400' : 'text-green-400'
                        }`}>
                          {getPasswordStrengthText()}
                        </span>
                      </div>
                      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${getPasswordStrengthColor()}`}
                          style={{ width: `${passwordStrength}%` }}
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2 mt-3">
                        <div className={`flex items-center text-xs ${
                          formData.password.length >= 8 ? 'text-green-400' : 'text-white/40'
                        }`}>
                          <HiCheckCircle className="w-4 h-4 mr-1" />
                          At least 8 characters
                        </div>
                        <div className={`flex items-center text-xs ${
                          /[A-Z]/.test(formData.password) ? 'text-green-400' : 'text-white/40'
                        }`}>
                          <HiCheckCircle className="w-4 h-4 mr-1" />
                          Uppercase letter
                        </div>
                        <div className={`flex items-center text-xs ${
                          /[a-z]/.test(formData.password) ? 'text-green-400' : 'text-white/40'
                        }`}>
                          <HiCheckCircle className="w-4 h-4 mr-1" />
                          Lowercase letter
                        </div>
                        <div className={`flex items-center text-xs ${
                          /[0-9]/.test(formData.password) ? 'text-green-400' : 'text-white/40'
                        }`}>
                          <HiCheckCircle className="w-4 h-4 mr-1" />
                          Number
                        </div>
                      </div>
                    </div>
                  )}

                  {errors.password && (
                    <p className="mt-2 text-sm text-red-300 flex items-center">
                      <HiXCircle className="w-4 h-4 mr-1" />
                      {errors.password}
                    </p>
                  )}
                </div>

                {/* Confirm Password Field */}
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword.confirmPassword ? 'text' : 'password'}
                      name="confirmPassword"
                      value={formData.confirmPassword}
                      onChange={handleChange}
                      onBlur={handleBlur}
                      className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all pr-12 ${
                        errors.confirmPassword ? 'border-red-500' : 'border-white/10'
                      }`}
                      placeholder="Confirm your password"
                    />
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility('confirmPassword')}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/50 hover:text-white transition-colors"
                    >
                      {showPassword.confirmPassword ? (
                        <HiEyeOff className="w-5 h-5" />
                      ) : (
                        <HiEye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="mt-2 text-sm text-red-300 flex items-center">
                      <HiXCircle className="w-4 h-4 mr-1" />
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>

                {/* Role Field */}
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <HiUserGroup className="inline w-4 h-4 mr-2" />
                    Select Your Role
                  </label>
                  <select
                    name="role"
                    value={formData.role}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    className={`w-full px-4 py-3 bg-white/5 border rounded-xl text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all appearance-none ${
                      errors.role ? 'border-red-500' : 'border-white/10'
                    }`}
                  >
                    <option value="" className="bg-gray-900">Select a role</option>
                    {availableRoles.map((roleOption) => (
                      <option
                        key={roleOption.value}
                        value={roleOption.value}
                        className="bg-gray-900"
                      >
                        {roleOption.label}
                      </option>
                    ))}
                  </select>
                  {formData.role && (
                    <p className="mt-2 text-sm text-white/60">
                      {availableRoles.find(r => r.value === formData.role)?.description}
                    </p>
                  )}
                  {errors.role && (
                    <p className="mt-2 text-sm text-red-300 flex items-center">
                      <HiXCircle className="w-4 h-4 mr-1" />
                      {errors.role}
                    </p>
                  )}
                </div>

                {/* Terms and Conditions */}
                <div className="flex items-start space-x-3">
                  <input
                    type="checkbox"
                    id="terms"
                    required
                    className="mt-1 w-4 h-4 bg-white/5 border border-white/10 rounded focus:ring-blue-500 focus:ring-offset-gray-900"
                  />
                  <label htmlFor="terms" className="text-sm text-white/70">
                    I agree to the{' '}
                    <a href="/terms" className="text-blue-300 hover:text-blue-200">
                      Terms of Service
                    </a>{' '}
                    and{' '}
                    <a href="/privacy" className="text-blue-300 hover:text-blue-200">
                      Privacy Policy
                    </a>
                  </label>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Creating Account...</span>
                    </>
                  ) : (
                    <>
                      <span>Create Account</span>
                      <HiArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>

                {/* Mobile Login Link */}
                <div className="lg:hidden pt-6 border-t border-white/10">
                  <p className="text-center text-white/70 text-sm">
                    Already have an account?{' '}
                    <Link to="/login" className="text-white font-semibold hover:underline">
                      Sign in
                    </Link>
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Animations */}
      <style jsx>{`
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
          animation: blob 7s infinite;
        }
        .animation-delay-2000 {
          animation-delay: 2s;
        }
        .animation-delay-4000 {
          animation-delay: 4s;
        }
      `}</style>
    </div>
  );
};

export default RegisterPage;