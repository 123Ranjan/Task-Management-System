import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from '../api/axios';
import { toast } from 'react-toastify';
import { isAdmin } from '../utils/permissions';
import {
  HiArrowLeft,
  HiPlus,
  HiCalendar,
  HiFlag,
  HiUserGroup,
  HiCheckCircle,
  HiClock,
  HiChartBar,
  HiEye,
  HiX,
  HiPlay,
  HiStop,
  HiArchive,
  HiRefresh,
  HiChevronRight,
  HiFire,
  HiTrendingUp,
  HiOutlineLightningBolt
} from 'react-icons/hi';

const SprintPage = () => {
  const [sprints, setSprints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('ACTIVE');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showSprintDetail, setShowSprintDetail] = useState(false);
  const [selectedSprint, setSelectedSprint] = useState(null);
  const [sprintIssues, setSprintIssues] = useState([]);
  const [loadingIssues, setLoadingIssues] = useState(false);
  const [creating, setCreating] = useState(false);
  const [completing, setCompleting] = useState(false);
  const [boards, setBoards] = useState([]);
  const [selectedBoardId, setSelectedBoardId] = useState('');
  const [stats, setStats] = useState({
    active: 0,
    upcoming: 0,
    completed: 0,
    velocity: 0
  });
  const navigate = useNavigate();
  const admin = isAdmin();

  // Create sprint form state
  const [sprintForm, setSprintForm] = useState({
    name: '',
    startDate: '',
    endDate: '',
    goal: '',
    velocity: '',
  });

  // Fetch boards for dropdown
  const fetchBoards = useCallback(async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('/boards', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBoards(response.data || []);
    } catch (error) {
      setBoards([]);
    }
  }, []);

  useEffect(() => {
    fetchBoards();
  }, [fetchBoards]);

  const fetchSprints = async () => {
    try {
      const token = localStorage.getItem('token');
      let url = '/sprints';
      if (selectedBoardId && selectedBoardId !== 'none') {
        url = `/sprints/byBoard/${selectedBoardId}`;
      }
      const response = await axios.get(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const sprintsData = response.data || [];
      setSprints(sprintsData);

      // Calculate stats
      const activeSprints = sprintsData.filter(
        sprint => sprint.status === 'ACTIVE' || sprint.state === 'ACTIVE'
      ).length;

      const upcomingSprints = sprintsData.filter(
        sprint => sprint.status === 'PLANNED' || sprint.status === 'UPCOMING' ||
                 sprint.state === 'PLANNED' || sprint.state === 'UPCOMING'
      ).length;

      const completedSprints = sprintsData.filter(
        sprint => sprint.status === 'COMPLETED' || sprint.state === 'COMPLETED'
      ).length;

      setStats({
        active: activeSprints,
        upcoming: upcomingSprints,
        completed: completedSprints,
        velocity: calculateVelocity(sprintsData)
      });

    } catch (error) {
      if (error.response?.status === 404 || error.response?.status === 405) {
        setSprints([]);
      } else {
        const errorMessage = error.response?.data?.message || 'Failed to fetch sprints.';
        toast.error(errorMessage);
        if (error.response?.status === 401) {
          localStorage.removeItem('token');
          navigate('/login');
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const calculateVelocity = (sprintsData) => {
    const completedSprints = sprintsData.filter(
      sprint => sprint.status === 'COMPLETED' || sprint.state === 'COMPLETED'
    );

    if (completedSprints.length === 0) return 0;

    // Sum up story points from completed sprints
    const totalPoints = completedSprints.reduce((sum, sprint) => {
      return sum + (sprint.completedPoints || sprint.velocity || 0);
    }, 0);

    return Math.round(totalPoints / completedSprints.length);
  };

  const fetchSprintIssues = async (sprintId) => {
    setLoadingIssues(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`/sprints/${sprintId}/issues`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setSprintIssues(response.data);
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to fetch sprint issues.';
      toast.error(errorMessage);
    } finally {
      setLoadingIssues(false);
    }
  };

  useEffect(() => {
    fetchSprints();
  }, [selectedBoardId]);

  const handleCreateSprint = async (e) => {
    e.preventDefault();
    setCreating(true);
    try {
      const token = localStorage.getItem('token');
      let boardIdToAssign = null;
      if (selectedBoardId && selectedBoardId !== 'none') {
        const selectedBoard = boards.find(
          (b) => String(b.id) === String(selectedBoardId)
        );
        if (selectedBoard) {
          const matchedBoard = boards.find(
            (b) => (b.name || b.boardName) === (selectedBoard.name || selectedBoard.boardName)
          );
          if (matchedBoard) {
            boardIdToAssign = matchedBoard.id;
          }
        }
      }
      const payload = {
        sprintName: sprintForm.name,
        startDate: sprintForm.startDate ? `${sprintForm.startDate}T00:00:00` : null,
        endDate: sprintForm.endDate ? `${sprintForm.endDate}T23:59:59` : null,
        goal: sprintForm.goal,
        velocity: sprintForm.velocity || 0,
        projectId: 1,
        boardId: boardIdToAssign,
      };
      await axios.post('/sprints/create', payload, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      toast.success('Sprint created successfully!');
      setSprintForm({ name: '', startDate: '', endDate: '', goal: '', velocity: '' });
      setShowCreateModal(false);
      fetchSprints();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to create sprint.';
      toast.error(errorMessage);
    } finally {
      setCreating(false);
    }
  };

  const handleCompleteSprint = async (sprintId) => {
    setCompleting(true);
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `/sprints/${sprintId}/close`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Sprint marked as complete!');
      setSprints((prevSprints) =>
        prevSprints.map((s) =>
          s.id === sprintId ? { ...s, state: 'COMPLETED', status: 'COMPLETED' } : s
        )
      );
      setShowSprintDetail(false);
      setSelectedSprint(null);
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to complete sprint.';
      toast.error(errorMessage);
    } finally {
      setCompleting(false);
    }
  };

  const handleStartSprint = async (sprintId) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `/sprints/${sprintId}/start`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      toast.success('Sprint started!');
      setShowSprintDetail(false);
      setSelectedSprint(null);
      fetchSprints();
    } catch (error) {
      const errorMessage = error.response?.data?.message || 'Failed to start sprint.';
      toast.error(errorMessage);
    }
  };

  const openSprintDetail = (sprint) => {
    setSelectedSprint(sprint);
    setShowSprintDetail(true);
    fetchSprintIssues(sprint.id);
  };

  const getSprintsByStatus = (status) => {
    const statusMap = {
      ACTIVE: 'ACTIVE',
      UPCOMING: 'PLANNED',
      COMPLETED: 'COMPLETED',
    };

    const backendStatus = statusMap[status] || status;

    return sprints.filter(
      (sprint) => sprint.status === backendStatus || sprint.state === backendStatus
    );
  };

  const getStatusConfig = (status) => {
    const configs = {
      ACTIVE: { color: 'bg-emerald-500', icon: <HiPlay className="w-4 h-4" />, label: 'Active' },
      UPCOMING: { color: 'bg-blue-500', icon: <HiClock className="w-4 h-4" />, label: 'Upcoming' },
      PLANNED: { color: 'bg-blue-500', icon: <HiClock className="w-4 h-4" />, label: 'Planned' },
      COMPLETED: { color: 'bg-gray-500', icon: <HiCheckCircle className="w-4 h-4" />, label: 'Completed' },
    };

    const config = configs[status] || configs.UPCOMING;
    return {
      ...config,
      label: status === 'UPCOMING' ? 'Upcoming' : (config.label || status)
    };
  };

  const getPriorityBadge = (priority) => {
    const styles = {
      HIGH: 'bg-red-100 text-red-800 border-red-200',
      MEDIUM: 'bg-amber-100 text-amber-800 border-amber-200',
      LOW: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    };
    return styles[priority] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const getStatusBadge = (status) => {
    const styles = {
      TODO: 'bg-gray-100 text-gray-800 border-gray-200',
      IN_PROGRESS: 'bg-blue-100 text-blue-800 border-blue-200',
      IN_REVIEW: 'bg-purple-100 text-purple-800 border-purple-200',
      DONE: 'bg-emerald-100 text-emerald-800 border-emerald-200',
    };
    return styles[status] || styles.TODO;
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getRemainingDays = (endDate) => {
    if (!endDate) return 0;
    const today = new Date();
    const end = new Date(endDate);
    const diffTime = end - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getProgressPercentage = (sprint) => {
    const totalIssues = sprint.issueCount || 0;
    const completedIssues = sprint.completedIssues || 0;
    return totalIssues > 0 ? Math.round((completedIssues / totalIssues) * 100) : 0;
  };

  const tabs = [
    {
      id: 'ACTIVE',
      label: 'Active',
      count: stats.active,
      icon: <HiPlay className="w-4 h-4" />,
      color: 'text-emerald-600 bg-emerald-100'
    },
    {
      id: 'UPCOMING',
      label: 'Upcoming',
      count: stats.upcoming,
      icon: <HiClock className="w-4 h-4" />,
      color: 'text-blue-600 bg-blue-100'
    },
    {
      id: 'COMPLETED',
      label: 'Completed',
      count: stats.completed,
      icon: <HiCheckCircle className="w-4 h-4" />,
      color: 'text-gray-600 bg-gray-100'
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-16 w-16 border-4 border-blue-600 border-t-transparent mb-4"></div>
          <div className="text-xl font-medium text-gray-700">Loading Sprints</div>
          <p className="text-gray-500 mt-2">Fetching sprint data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 p-2 rounded-lg hover:bg-gray-100 transition-colors"
              >
                <HiArrowLeft className="w-5 h-5" />
                <span>Dashboard</span>
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Sprint Management</h1>
                <p className="text-gray-600 mt-1">Plan, track, and complete your sprints</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <button
                onClick={() => fetchSprints()}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                title="Refresh"
              >
                <HiRefresh className="w-5 h-5" />
              </button>
              {admin && (
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg hover:shadow-xl"
                >
                  <HiPlus className="w-5 h-5" />
                  <span>New Sprint</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Sprints</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.active}</p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                <HiPlay className="w-6 h-6 text-emerald-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Upcoming Sprints</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.upcoming}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <HiClock className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Completed Sprints</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.completed}</p>
              </div>
              <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center">
                <HiCheckCircle className="w-6 h-6 text-gray-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg. Velocity</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stats.velocity}</p>
                <p className="text-xs text-gray-500 mt-1">Story points per sprint</p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <HiTrendingUp className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Board Filter */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Filter by Board</h3>
              <p className="text-gray-600 text-sm">Select a board to view its sprints</p>
            </div>
            <select
              value={selectedBoardId}
              onChange={(e) => setSelectedBoardId(e.target.value)}
              className="w-full md:w-64 px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">All Boards</option>
              {boards
                .filter((b) => b.boardType === 'SCRUM')
                .map((board) => (
                  <option key={board.id} value={board.id}>
                    {board.name || board.boardName}
                  </option>
                ))}
            </select>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
                <span
                  className={`ml-2 px-2 py-1 rounded-full text-xs ${tab.color}`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </nav>
        </div>

        {/* Sprint List */}
        {getSprintsByStatus(activeTab).length === 0 ? (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-12 text-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <HiOutlineLightningBolt className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-xl font-medium text-gray-900 mb-2">
              No {activeTab.toLowerCase()} sprints
            </h3>
            <p className="text-gray-600 max-w-md mx-auto mb-6">
              {activeTab === 'ACTIVE'
                ? 'Start a new sprint to begin tracking your work and monitoring progress.'
                : activeTab === 'UPCOMING'
                ? 'Plan upcoming sprints to organize your future work and set goals.'
                : 'Completed sprints will appear here for review and analysis.'}
            </p>
            {admin && activeTab !== 'COMPLETED' && (
              <button
                onClick={() => setShowCreateModal(true)}
                className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-xl hover:from-blue-700 hover:to-cyan-700 transition-all shadow-lg hover:shadow-xl"
              >
                <HiPlus className="w-5 h-5" />
                <span>Create Sprint</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {getSprintsByStatus(activeTab).map((sprint) => {
              const statusConfig = getStatusConfig(sprint.status || sprint.state);
              const progress = getProgressPercentage(sprint);
              const remainingDays = getRemainingDays(sprint.endDate);

              return (
                <div
                  key={sprint.id}
                  className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer overflow-hidden group"
                  onClick={() => openSprintDetail(sprint)}
                >
                  {/* Sprint Header */}
                  <div className="p-5 border-b border-gray-100">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-lg font-semibold text-gray-900 truncate">
                        {sprint.name || sprint.sprintName}
                      </h3>
                      <div className={`px-2.5 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${statusConfig.color.replace('bg-', 'bg-').replace('500', '100')} ${statusConfig.color.replace('bg-', 'text-').replace('500', '800')}`}>
                        {statusConfig.icon}
                        <span>{statusConfig.label}</span>
                      </div>
                    </div>

                    {/* Goal */}
                    {sprint.goal && (
                      <p className="text-sm text-gray-600 mb-4 line-clamp-2">
                        {sprint.goal}
                      </p>
                    )}

                    {/* Progress Bar */}
                    <div className="mb-4">
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Progress</span>
                        <span>{progress}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-blue-500 to-cyan-600 transition-all duration-300"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Dates */}
                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <span className="flex items-center">
                        <HiCalendar className="w-4 h-4 mr-1" />
                        {formatDate(sprint.startDate)}
                      </span>
                      <span className="text-gray-400">→</span>
                      <span className="flex items-center">
                        <HiFlag className="w-4 h-4 mr-1" />
                        {formatDate(sprint.endDate)}
                        {remainingDays > 0 && activeTab === 'ACTIVE' && (
                          <span className="ml-2 px-2 py-0.5 bg-amber-100 text-amber-800 text-xs rounded-full">
                            {remainingDays}d left
                          </span>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Sprint Footer */}
                  <div className="px-5 py-3 bg-gray-50 flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="text-sm text-gray-600">
                        <span className="font-medium text-gray-900">{sprint.issueCount || 0}</span> issues
                      </div>
                      {sprint.velocity && (
                        <div className="text-sm text-gray-600">
                          <span className="font-medium text-gray-900">{sprint.velocity}</span> velocity
                        </div>
                      )}
                    </div>
                    <div className="text-blue-600 group-hover:text-blue-700 flex items-center space-x-1">
                      <span className="text-sm font-medium">View Details</span>
                      <HiChevronRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Create Sprint Modal */}
      {admin && showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-lg">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900 flex items-center space-x-2">
                <HiPlus className="w-5 h-5 text-blue-600" />
                <span>Create New Sprint</span>
              </h2>
              <button
                onClick={() => {
                  setShowCreateModal(false);
                  setSprintForm({ name: '', startDate: '', endDate: '', goal: '', velocity: '' });
                }}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
              >
                <HiX className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleCreateSprint} className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Board
                  </label>
                  <select
                    value={selectedBoardId}
                    onChange={(e) => setSelectedBoardId(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="none">None (Kanban)</option>
                    {boards
                      .filter((b) => b.boardType === 'SCRUM')
                      .map((board) => (
                        <option key={board.id} value={board.id}>
                          {board.name || board.boardName}
                        </option>
                      ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Sprint Name *
                  </label>
                  <input
                    type="text"
                    value={sprintForm.name}
                    onChange={(e) => setSprintForm({ ...sprintForm, name: e.target.value })}
                    placeholder="e.g., Sprint 24, MVP Phase 2"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Start Date *
                    </label>
                    <input
                      type="date"
                      value={sprintForm.startDate}
                      onChange={(e) => setSprintForm({ ...sprintForm, startDate: e.target.value })}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      End Date *
                    </label>
                    <input
                      type="date"
                      value={sprintForm.endDate}
                      onChange={(e) => setSprintForm({ ...sprintForm, endDate: e.target.value })}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Sprint Goal
                    <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                  </label>
                  <textarea
                    value={sprintForm.goal}
                    onChange={(e) => setSprintForm({ ...sprintForm, goal: e.target.value })}
                    placeholder="What do you want to achieve in this sprint?"
                    rows={3}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    Velocity Target
                    <span className="text-gray-500 text-sm font-normal ml-2">(optional)</span>
                  </label>
                  <input
                    type="number"
                    value={sprintForm.velocity}
                    onChange={(e) => setSprintForm({ ...sprintForm, velocity: e.target.value })}
                    placeholder="e.g., 40 story points"
                    min="0"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200 mt-6">
                <button
                  type="button"
                  onClick={() => {
                    setShowCreateModal(false);
                    setSprintForm({ name: '', startDate: '', endDate: '', goal: '', velocity: '' });
                  }}
                  className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creating}
                  className="px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                >
                  {creating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      <span>Creating...</span>
                    </>
                  ) : (
                    <>
                      <HiPlus className="w-4 h-4" />
                      <span>Create Sprint</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sprint Detail Modal */}
      {showSprintDetail && selectedSprint && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${getStatusConfig(selectedSprint.status || selectedSprint.state).color} text-white`}>
                  {getStatusConfig(selectedSprint.status || selectedSprint.state).icon}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {selectedSprint.name || selectedSprint.sprintName}
                  </h2>
                  <div className="flex items-center space-x-3 mt-1">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getStatusConfig(selectedSprint.status || selectedSprint.state).color.replace('bg-', 'bg-').replace('500', '100')} ${getStatusConfig(selectedSprint.status || selectedSprint.state).color.replace('bg-', 'text-').replace('500', '800')}`}>
                      {getStatusConfig(selectedSprint.status || selectedSprint.state).label}
                    </span>
                    <span className="text-sm text-gray-500">
                      {formatDate(selectedSprint.startDate)} - {formatDate(selectedSprint.endDate)}
                    </span>
                  </div>
                </div>
              </div>
              <button
                onClick={() => {
                  setShowSprintDetail(false);
                  setSelectedSprint(null);
                  setSprintIssues([]);
                }}
                className="text-gray-500 hover:text-gray-700 p-1 rounded-lg hover:bg-gray-100"
              >
                <HiX className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left Column - Sprint Info */}
                <div className="lg:col-span-2 space-y-6">
                  {/* Goal */}
                  {selectedSprint.goal && (
                    <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-100 p-5">
                      <h3 className="text-sm font-semibold text-gray-900 mb-2 flex items-center">
                        <HiFlag className="w-4 h-4 mr-2 text-blue-600" />
                        Sprint Goal
                      </h3>
                      <p className="text-gray-700">{selectedSprint.goal}</p>
                    </div>
                  )}

                  {/* Issues Section */}
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">
                      Sprint Issues ({sprintIssues.length})
                    </h3>
                    {loadingIssues ? (
                      <div className="text-center py-8">
                        <div className="inline-block animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
                        <p className="text-gray-500 mt-2">Loading issues...</p>
                      </div>
                    ) : sprintIssues.length === 0 ? (
                      <div className="bg-gray-50 rounded-xl border border-gray-200 p-8 text-center">
                        <HiUserGroup className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                        <p className="text-gray-600">No issues assigned to this sprint yet.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {sprintIssues.map((issue) => (
                          <div
                            key={issue.id}
                            className="bg-white border border-gray-200 rounded-xl p-4 hover:border-blue-300 hover:shadow-sm transition-all"
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1 min-w-0">
                                <h4 className="font-medium text-gray-900 mb-1">
                                  {issue.title || issue.name}
                                </h4>
                                {issue.description && (
                                  <p className="text-sm text-gray-600 line-clamp-2">
                                    {issue.description}
                                  </p>
                                )}
                              </div>
                              <div className="flex items-center space-x-2 ml-4">
                                {issue.priority && (
                                  <span
                                    className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getPriorityBadge(issue.priority)}`}
                                  >
                                    {issue.priority}
                                  </span>
                                )}
                                {issue.status && (
                                  <span
                                    className={`px-2.5 py-1 rounded-full text-xs font-medium border ${getStatusBadge(issue.status)}`}
                                  >
                                    {issue.status.replace('_', ' ')}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                              {issue.assignee && (
                                <span className="flex items-center">
                                  <HiUserGroup className="w-4 h-4 mr-1" />
                                  {issue.assignee}
                                </span>
                              )}
                              {issue.storyPoints && (
                                <span className="flex items-center">
                                  <HiChartBar className="w-4 h-4 mr-1" />
                                  {issue.storyPoints} points
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Column - Stats & Actions */}
                <div className="space-y-6">
                  {/* Stats */}
                  <div className="bg-gray-50 rounded-xl border border-gray-200 p-5">
                    <h3 className="text-sm font-semibold text-gray-900 mb-4">
                      Sprint Metrics
                    </h3>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between text-sm text-gray-600 mb-1">
                          <span>Progress</span>
                          <span>{getProgressPercentage(selectedSprint)}%</span>
                        </div>
                        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-cyan-600"
                            style={{ width: `${getProgressPercentage(selectedSprint)}%` }}
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-white rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-gray-900">
                            {selectedSprint.issueCount || 0}
                          </div>
                          <div className="text-xs text-gray-600">Total Issues</div>
                        </div>
                        <div className="bg-white rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-gray-900">
                            {selectedSprint.completedIssues || 0}
                          </div>
                          <div className="text-xs text-gray-600">Completed</div>
                        </div>
                      </div>
                      {selectedSprint.velocity && (
                        <div className="bg-white rounded-lg p-3 text-center">
                          <div className="text-2xl font-bold text-gray-900">
                            {selectedSprint.velocity}
                          </div>
                          <div className="text-xs text-gray-600">Velocity Target</div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-100 p-5">
                    <h3 className="text-sm font-semibold text-gray-900 mb-4">
                      Sprint Actions
                    </h3>
                    <div className="space-y-3">
                      {(selectedSprint.status === 'ACTIVE' || selectedSprint.state === 'ACTIVE') && (
                        <button
                          onClick={() => handleCompleteSprint(selectedSprint.id)}
                          disabled={completing}
                          className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-green-600 text-white rounded-lg hover:from-emerald-700 hover:to-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
                        >
                          {completing ? (
                            <>
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              <span>Completing...</span>
                            </>
                          ) : (
                            <>
                              <HiCheckCircle className="w-4 h-4" />
                              <span>Complete Sprint</span>
                            </>
                          )}
                        </button>
                      )}
                      {(selectedSprint.status === 'PLANNED' || selectedSprint.state === 'PLANNED' || selectedSprint.status === 'UPCOMING' || selectedSprint.state === 'UPCOMING') && (
                        <button
                          onClick={() => handleStartSprint(selectedSprint.id)}
                          className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-cyan-600 text-white rounded-lg hover:from-blue-700 hover:to-cyan-700 transition-all flex items-center justify-center space-x-2"
                        >
                          <HiPlay className="w-4 h-4" />
                          <span>Start Sprint</span>
                        </button>
                      )}
                      <button
                        onClick={() => {
                          setShowSprintDetail(false);
                          setSelectedSprint(null);
                          setSprintIssues([]);
                        }}
                        className="w-full py-2.5 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        Close
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SprintPage;