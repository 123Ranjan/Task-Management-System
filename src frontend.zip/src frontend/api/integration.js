import api from './axios';

// Send a GitHub event (webhook simulation)
export const sendGithubEvent = async (event, payload) => {
  return api.post('/integrations/github', payload, {
    headers: { 'GitHub_Event': event }
  });
};

// Send a Jenkins event
export const sendJenkinsEvent = async (payload) => {
  return api.post('/integrations/jenkins', payload);
};

// Send a Docker event
export const sendDockerEvent = async (payload) => {
  return api.post('/integrations/docker', payload);
};

// Send a commit event
export const sendCommitEvent = async (message, author) => {
  return api.post('/integrations/commit', null, {
    params: { message, author }
  });
};

// Send a pull request event
export const sendPullRequestEvent = async (title, author) => {
  return api.post('/integrations/pullRequest', null, {
    params: { title, author }
  });
};

// (Optional) Get integration events/logs (mocked for now)
export const getIntegrationEvents = async (issueKey) => {
  // Call the real backend endpoint
  return api.get('/integrations/events', {
    params: { issueKey }
  });
};
