import axios from 'axios';

// Create axios instance with base URL
const api = axios.create({
  baseURL: 'http://localhost:8081/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Public endpoints that don't need authentication
const publicEndpoints = [
  '/userAuthentication/login',
  '/userAuthentication/register',
  '/userAuthentication/check',
];

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    // Skip adding token for public endpoints
    const isPublicEndpoint = publicEndpoints.some(endpoint =>
      config.url?.includes(endpoint)
    );

    if (!isPublicEndpoint) {
      const token = localStorage.getItem('token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    // Log the error for debugging
    console.error('API Error:', {
      url: error.config?.url,
      status: error.response?.status,
      message: error.response?.data?.message || error.message
    });

    // Only auto-logout on 401 (Unauthorized/Authentication errors)
    // Don't logout on 403 (Forbidden/Permission errors) as the user is authenticated but lacks permission
    if (error.response?.status === 401) {
      const errorMessage = error.response?.data?.message || '';

      // Check if it's a genuine authentication error (invalid/expired token)
      const isAuthError =
        errorMessage.toLowerCase().includes('token') ||
        errorMessage.toLowerCase().includes('unauthorized') ||
        errorMessage.toLowerCase().includes('authentication') ||
        errorMessage.toLowerCase().includes('expired') ||
        !localStorage.getItem('token');

      if (isAuthError) {
        console.log('Authentication error detected, logging out...');
        localStorage.removeItem('token');
        localStorage.removeItem('username');
        localStorage.removeItem('userId');
        // Redirect to login if not already there
        if (window.location.pathname !== '/login' && window.location.pathname !== '/register') {
          window.location.href = '/login';
        }
      }
    }
    return Promise.reject(error);
  }
);

export default api;

