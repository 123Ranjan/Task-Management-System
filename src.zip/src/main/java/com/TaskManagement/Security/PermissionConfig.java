package com.TaskManagement.Security;

import java.util.*;

import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Enum.Role;

public class PermissionConfig {

    private static final Map<Role, Set<Permission>> ROLE_PERMISSIONS = new HashMap<>();

    static {
        // ADMIN - Full access to everything
        ROLE_PERMISSIONS.put(Role.ADMIN, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_CREATE,
                Permission.ISSUE_EDIT,
                Permission.ISSUE_DELETE,
                Permission.COMMENT_ADD,
                Permission.COMMENT_DELETE,
                Permission.BOARD_VIEW,
                Permission.BOARD_CREATE,
                Permission.BOARD_EDIT,
                Permission.BOARD_DELETE,
                Permission.SPRINT_VIEW,
                Permission.SPRINT_CREATE,
                Permission.SPRINT_EDIT,
                Permission.SPRINT_START,
                Permission.SPRINT_CLOSE,
                Permission.WORKFLOW_VIEW,
                Permission.WORKFLOW_CREATE,
                Permission.WORKFLOW_EDIT,
                Permission.NOTIFICATION_VIEW,
                Permission.NOTIFICATION_SEND,
                Permission.USER_MANAGE,
                Permission.USER_VIEW
        )));

        // MANAGER - Can manage projects, sprints, and workflows
        ROLE_PERMISSIONS.put(Role.MANAGER, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_CREATE,
                Permission.ISSUE_EDIT,
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.BOARD_CREATE,
                Permission.BOARD_EDIT,
                Permission.SPRINT_VIEW,
                Permission.SPRINT_CREATE,
                Permission.SPRINT_EDIT,
                Permission.SPRINT_START,
                Permission.SPRINT_CLOSE,
                Permission.WORKFLOW_VIEW,
                Permission.WORKFLOW_CREATE,
                Permission.WORKFLOW_EDIT,
                Permission.NOTIFICATION_VIEW,
                Permission.NOTIFICATION_SEND,
                Permission.USER_VIEW
        )));

        // DEVELOPER - Can work on issues and view boards/sprints
        ROLE_PERMISSIONS.put(Role.DEVELOPER, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_CREATE,
                Permission.ISSUE_EDIT,
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.SPRINT_VIEW,
                Permission.WORKFLOW_VIEW,
                Permission.NOTIFICATION_VIEW
        )));

        // TESTER - Can view and test, add comments, limited editing
        ROLE_PERMISSIONS.put(Role.TESTER, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_EDIT,  // Can update issue status (testing results)
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.SPRINT_VIEW,
                Permission.WORKFLOW_VIEW,
                Permission.NOTIFICATION_VIEW
        )));

        // DEVOPS - Can view all, manage workflows and deployments
        ROLE_PERMISSIONS.put(Role.DEVOPS, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_EDIT,
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.SPRINT_VIEW,
                Permission.SPRINT_EDIT,
                Permission.WORKFLOW_VIEW,
                Permission.WORKFLOW_EDIT,
                Permission.NOTIFICATION_VIEW,
                Permission.NOTIFICATION_SEND
        )));

        // PRODUCTION - Read-only access to production issues
        ROLE_PERMISSIONS.put(Role.PRODUCTION, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.SPRINT_VIEW,
                Permission.NOTIFICATION_VIEW
        )));

        // SUPPORT - Can view and comment, create support issues
        ROLE_PERMISSIONS.put(Role.SUPPORT, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.ISSUE_CREATE,  // Can create support tickets
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.NOTIFICATION_VIEW
        )));

        // NON_TECH - Very limited access, view-only
        ROLE_PERMISSIONS.put(Role.NON_TECH, new HashSet<>(Arrays.asList(
                Permission.ISSUE_VIEW,
                Permission.COMMENT_ADD,
                Permission.BOARD_VIEW,
                Permission.NOTIFICATION_VIEW
        )));
    }

    public static Set<Permission> getPermissions(Role role) {
        return ROLE_PERMISSIONS.getOrDefault(role, Collections.emptySet());
    }

    public static Map<Role, Set<Permission>> getAllRolePermissions() {
        return ROLE_PERMISSIONS;
    }

    public static boolean hasPermission(Role role, Permission permission) {
        Set<Permission> permissions = getPermissions(role);
        return permissions.contains(permission);
    }
}
