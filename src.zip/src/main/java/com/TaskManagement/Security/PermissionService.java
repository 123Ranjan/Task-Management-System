package com.TaskManagement.Security;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Enum.Role;

@Service
public class PermissionService {

    private static final Logger logger = LoggerFactory.getLogger(PermissionService.class);

    /**
     * Check if the current authenticated user has the required permission
     */
    public boolean hasPermission(Permission permission) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        logger.debug("Checking permission: {}", permission);
        logger.debug("Authentication object: {}", authentication);

        if (authentication == null || !authentication.isAuthenticated()) {
            logger.warn("Authentication is null or not authenticated");
            return false;
        }

        // Log all authorities
        logger.debug("Authorities: {}", authentication.getAuthorities());

        // Get user's role from authorities
        Role userRole = authentication.getAuthorities().stream()
                .map(authority -> {
                    String authorityStr = authority.getAuthority();
                    logger.debug("Processing authority: {}", authorityStr);
                    String roleName = authorityStr.replace("ROLE_", "");
                    logger.debug("Extracted role name: {}", roleName);
                    try {
                        Role role = Role.valueOf(roleName);
                        logger.debug("Parsed role: {}", role);
                        return role;
                    } catch (IllegalArgumentException e) {
                        logger.warn("Could not parse role: {}", roleName, e);
                        return null;
                    }
                })
                .filter(role -> role != null)
                .findFirst()
                .orElse(null);

        if (userRole == null) {
            logger.warn("User role is null after parsing authorities");
            return false;
        }

        logger.debug("User role: {}", userRole);

        Set<Permission> permissions = PermissionConfig.getPermissions(userRole);
        logger.debug("Permissions for role {}: {}", userRole, permissions);

        boolean hasPermission = permissions.contains(permission);
        logger.debug("Has permission {}: {}", permission, hasPermission);

        return hasPermission;
    }

    /**
     * Check if a specific role has the required permission
     */
    public boolean hasPermission(Role role, Permission permission) {
        return PermissionConfig.hasPermission(role, permission);
    }

    /**
     * Require permission or throw AccessDeniedException
     */
    public void requirePermission(Permission permission) {
        if (!hasPermission(permission)) {
            Role userRole = getCurrentUserRole();
            String errorMsg = "You do not have permission to perform this action: " + permission;
            if (userRole != null) {
                errorMsg += " (Your role: " + userRole + ")";
            } else {
                errorMsg += " (Could not determine your role)";
            }
            logger.error(errorMsg);
            throw new AccessDeniedException(errorMsg);
        }
    }

    /**
     * Get current user's role
     */
    public Role getCurrentUserRole() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }

        return authentication.getAuthorities().stream()
                .map(authority -> {
                    String roleName = authority.getAuthority().replace("ROLE_", "");
                    try {
                        return Role.valueOf(roleName);
                    } catch (IllegalArgumentException e) {
                        return null;
                    }
                })
                .filter(role -> role != null)
                .findFirst()
                .orElse(null);
    }
}
