package com.TaskManagement.Enum;

public enum TaskStatus {
OPEN,IN_PROGRESS,COMPLETE,BLOCK
}
