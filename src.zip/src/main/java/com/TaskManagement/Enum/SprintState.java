package com.TaskManagement.Enum;


public enum SprintState {

	PLANNED,ACTIVE,COMPLETED,ABORTED,INCOMPLETE
}
