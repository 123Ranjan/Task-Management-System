package com.TaskManagement.Enum;

public enum IssueType {

	BUG,TASK,STORY,EPIC
}
