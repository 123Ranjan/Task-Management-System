package com.TaskManagement.Enum;

public enum IssueStatus {

	OPEN,IN_PROGRESS,RESOLVED,CLOSED,TODO,IN_REVIEW,DONE,REOPEN,BLOCKS,DEPLOYMENT
}
