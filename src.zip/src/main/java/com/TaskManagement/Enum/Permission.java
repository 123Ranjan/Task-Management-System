package com.TaskManagement.Enum;

public enum Permission {

	// Issue permissions
	ISSUE_VIEW,
	ISSUE_CREATE,
	ISSUE_EDIT,
	ISSUE_DELETE,

	// Comment permissions
	COMMENT_ADD,
	COMMENT_DELETE,

	// Board permissions
	BOARD_VIEW,
	BOARD_CREATE,
	BOARD_EDIT,
	BOARD_DELETE,

	// Sprint permissions
	SPRINT_VIEW,
	SPRINT_CREATE,
	SPRINT_EDIT,
	SPRINT_START,
	SPRINT_CLOSE,

	// Workflow permissions
	WORKFLOW_VIEW,
	WORKFLOW_CREATE,
	WORKFLOW_EDIT,

	// Notification permissions
	NOTIFICATION_VIEW,
	NOTIFICATION_SEND,

	// User management
	USER_MANAGE,
	USER_VIEW
}
