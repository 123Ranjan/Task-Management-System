package com.TaskManagement.Enum;


public enum BoardType {

	SCRUM, KANBAN
}
