package com.TaskManagement.Enum;

public enum PriorityTask {
HIGH,LOW,MEDIUM
}
