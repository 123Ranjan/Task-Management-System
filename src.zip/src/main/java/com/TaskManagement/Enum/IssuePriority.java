package com.TaskManagement.Enum;

public enum IssuePriority {

	HIGH,MEDIUM,LOW,CRITICAL
}
