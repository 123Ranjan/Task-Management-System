package com.TaskManagement.Enum;

public enum Role {
    ADMIN,
    DEVELOPER,
    MANAGER,
    TESTER,
    PRODUCTION,
    SUPPORT,
    NON_TECH,
    DEVOPS
}
