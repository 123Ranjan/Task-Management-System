package com.TaskManagement.DTO;

import java.util.Set;

import lombok.*;

@Data
//@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AuthenticationResponseDTO {
	
	private String token;
	private String message;
	private Long userId;
	private String userName;
	private String role;
	private Set<String> permissions;

	
	public AuthenticationResponseDTO(String token, String message) {
		this.token = token;
		this.message = message;
	}

	public AuthenticationResponseDTO(String token, String message, Long userId, String userName) {
		this.token = token;
		this.message = message;
		this.userId = userId;
		this.userName = userName;
	}

	public AuthenticationResponseDTO(String token, String message, Long userId, String userName, String role, Set<String> permissions) {
		this.token = token;
		this.message = message;
		this.userId = userId;
		this.userName = userName;
		this.role = role;
		this.permissions = permissions;
	}

	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public Set<String> getPermissions() {
		return permissions;
	}
	public void setPermissions(Set<String> permissions) {
		this.permissions = permissions;
	}
}

