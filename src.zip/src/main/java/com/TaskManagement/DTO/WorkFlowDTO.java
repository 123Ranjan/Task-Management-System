package com.TaskManagement.DTO;

import java.util.List;
import com.TaskManagement.Entity.Status;

public class WorkFlowDTO {
    private Long id;
    private String name;
    private List<WorkFlowTransactionDTO> transactions;
    private List<Status> statuses; // Add this field

    public WorkFlowDTO() {}

    public WorkFlowDTO(Long id, String name, List<WorkFlowTransactionDTO> transactions, List<Status> statuses) {
        this.id = id;
        this.name = name;
        this.transactions = transactions;
        this.statuses = statuses;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public List<WorkFlowTransactionDTO> getTransactions() { return transactions; }
    public void setTransactions(List<WorkFlowTransactionDTO> transactions) { this.transactions = transactions; }
    public List<Status> getStatuses() { return statuses; }
    public void setStatuses(List<Status> statuses) { this.statuses = statuses; }
}
