package com.TaskManagement.DTO;

import com.TaskManagement.Enum.Role;

public class WorkFlowTransactionDTO {
    private Long id;
    private String fromStatus;
    private String toStatus;
    private Long fromStatusId;
    private Long toStatusId;
    private String actionName;
    private Role role;

    public WorkFlowTransactionDTO() {}

    public WorkFlowTransactionDTO(Long id, String fromStatus, String toStatus, Long fromStatusId, Long toStatusId, String actionName, Role role) {
        this.id = id;
        this.fromStatus = fromStatus;
        this.toStatus = toStatus;
        this.fromStatusId = fromStatusId;
        this.toStatusId = toStatusId;
        this.actionName = actionName;
        this.role = role;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getFromStatus() { return fromStatus; }
    public void setFromStatus(String fromStatus) { this.fromStatus = fromStatus; }
    public String getToStatus() { return toStatus; }
    public void setToStatus(String toStatus) { this.toStatus = toStatus; }
    public Long getFromStatusId() { return fromStatusId; }
    public void setFromStatusId(Long fromStatusId) { this.fromStatusId = fromStatusId; }
    public Long getToStatusId() { return toStatusId; }
    public void setToStatusId(Long toStatusId) { this.toStatusId = toStatusId; }
    public String getActionName() { return actionName; }
    public void setActionName(String actionName) { this.actionName = actionName; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }
}
