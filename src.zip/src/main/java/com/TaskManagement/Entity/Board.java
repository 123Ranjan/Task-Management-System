package com.TaskManagement.Entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.TaskManagement.Enum.BoardType;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "boards")

@Data
@ToString(exclude = "columns")
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Board {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String boardName;
	private String projectKey;
	private BoardType boardType;
	private LocalDateTime createdAt = LocalDateTime.now();

	@JsonManagedReference
	@OneToMany(mappedBy = "board", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	@OrderBy("position")
	private List<BoardColumn> columns = new ArrayList<>();

	// Alias for boardName to support both frontend and backend naming conventions
	public String getName() {
		return boardName;
	}

	public void setName(String name) {
		this.boardName = name;
	}

	public List<BoardColumn> getColumns() {
		return columns;
	}
	public void setColumns(List<BoardColumn> columns) {
		this.columns = columns;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getBoardName() {
		return boardName;
	}
	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}
	public String getProjectKey() {
		return projectKey;
	}
	public void setProjectKey(String projectKey) {
		this.projectKey = projectKey;
	}
	public BoardType getBoardType() {
		return boardType;
	}
	public void setBoardType(BoardType boardType) {
		this.boardType = boardType;
	}
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
	
}
