package com.TaskManagement.Entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "issue_links")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class IssueLink {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "source_issue_id")
	private Long sourceIssueId;

	@Column(name = "target_issue_id")
	private Long targetIssueId;

	private String linkType;
}
