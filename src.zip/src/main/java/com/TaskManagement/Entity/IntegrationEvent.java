package com.TaskManagement.Entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "integration_event")
public class IntegrationEvent {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String issueKey;
    private String eventType;
    private String message;
    private String author;
    private LocalDateTime timestamp = LocalDateTime.now();

    public IntegrationEvent() {}
    public IntegrationEvent(String issueKey, String eventType, String message, String author) {
        this.issueKey = issueKey;
        this.eventType = eventType;
        this.message = message;
        this.author = author;
        this.timestamp = LocalDateTime.now();
    }
    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getIssueKey() { return issueKey; }
    public void setIssueKey(String issueKey) { this.issueKey = issueKey; }
    public String getEventType() { return eventType; }
    public void setEventType(String eventType) { this.eventType = eventType; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }
}
