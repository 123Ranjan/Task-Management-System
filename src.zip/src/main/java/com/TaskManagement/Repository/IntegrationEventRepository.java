package com.TaskManagement.Repository;

import com.TaskManagement.Entity.IntegrationEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IntegrationEventRepository extends JpaRepository<IntegrationEvent, Long> {
    List<IntegrationEvent> findByIssueKey(String issueKey);
}
