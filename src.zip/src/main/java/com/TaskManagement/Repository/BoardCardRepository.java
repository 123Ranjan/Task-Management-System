package com.TaskManagement.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.TaskManagement.Entity.BoardCard;

@Repository
public interface BoardCardRepository extends JpaRepository<BoardCard, Long> {

	@Query("SELECT bc FROM BoardCard bc WHERE bc.boardId = :boardId AND bc.column.id = :columnId ORDER BY bc.position")
	List<BoardCard> findByBoardIdAndColumnIdOrderByPosition(@Param("boardId") Long boardId, @Param("columnId") Long columnId);

	List<BoardCard> findByBoardIdOrderByPosition(Long boardId);

	Optional<BoardCard> findByIssueId(Long issueId);

	List<BoardCard> findByIssueIdAndBoardId(Long issueId, Long boardId);

	@Query("SELECT COUNT(bc) FROM BoardCard bc WHERE bc.boardId = :boardId AND bc.column.id = :columnId")
	long countByBoardIdAndColumnId(@Param("boardId") Long boardId, @Param("columnId") Long columnId);
}
