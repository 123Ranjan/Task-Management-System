package com.TaskManagement.Repository;

import com.TaskManagement.Entity.Sprint;
import com.TaskManagement.Enum.SprintState;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.Optional;

public class SprintRepositoryImpl implements SprintRepositoryCustom {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Optional<Sprint> findCurrentSprintForBoard(Long projectId) {
        String jpql = "SELECT s FROM Sprint s WHERE s.projectId = :projectId AND (s.state = :active OR s.state = :planned) ORDER BY s.state DESC, s.startDate DESC";
        TypedQuery<Sprint> query = entityManager.createQuery(jpql, Sprint.class);
        query.setParameter("projectId", projectId);
        query.setParameter("active", SprintState.ACTIVE);
        query.setParameter("planned", SprintState.PLANNED);
        query.setMaxResults(1);
        return query.getResultList().stream().findFirst();
    }
}
