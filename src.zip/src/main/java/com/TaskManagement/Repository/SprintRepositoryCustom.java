package com.TaskManagement.Repository;

import com.TaskManagement.Entity.Sprint;
import com.TaskManagement.Enum.SprintState;
import java.util.Optional;

public interface SprintRepositoryCustom {
    Optional<Sprint> findCurrentSprintForBoard(Long projectId);
}
