package com.TaskManagement.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.BoardCardDTO;
import com.TaskManagement.Entity.BoardCard;
import com.TaskManagement.Entity.BoardColumn;
import com.TaskManagement.Entity.Issue;
import com.TaskManagement.Repository.BoardCardRepository;
import com.TaskManagement.Repository.BoardColumnRepository;
import com.TaskManagement.Repository.IssueRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/boardCard")
@RequiredArgsConstructor
public class BoardCardController {

	@Autowired
	private BoardCardRepository boardCardRepository;

	@Autowired
	private IssueRepository issueRepository;

	@Autowired
	private BoardColumnRepository boardColumnRepository;

	/**
	 * Get all cards for a specific board with issue details
	 * @param boardId - the board ID
	 * @return List of BoardCardDTO with issue details
	 */
	@GetMapping("/board/{boardId}")
	public ResponseEntity<List<BoardCardDTO>> getCardsByBoard(@PathVariable Long boardId) {
		List<BoardCard> cards = boardCardRepository.findByBoardIdOrderByPosition(boardId);
		List<BoardCardDTO> cardDTOs = new ArrayList<>();

		for (BoardCard card : cards) {
			BoardCardDTO dto = new BoardCardDTO();
			dto.setId(card.getId());
			dto.setIssueId(card.getIssueId());
			dto.setBoardId(card.getBoardId());
			dto.setColumnId(card.getColumn() != null ? card.getColumn().getId() : null);
			dto.setPosition(card.getPosition());

			// Fetch issue details
			if (card.getIssueId() != null) {
				Issue issue = issueRepository.findById(card.getIssueId()).orElse(null);
				if (issue != null) {
					dto.setIssueKey(issue.getIssueKey());
					dto.setIssueTitle(issue.getIssueTitle());
					dto.setIssueDescription(issue.getIssueDescription());
					dto.setIssuePriority(issue.getIssuePriority() != null ? issue.getIssuePriority().name() : null);
					dto.setIssueStatus(issue.getIssueStatus() != null ? issue.getIssueStatus().name() : null);
					dto.setIssueType(issue.getIssueType() != null ? issue.getIssueType().name() : null);
					dto.setAssignedEmail(issue.getAssignedEmail());
				}
			}

			cardDTOs.add(dto);
		}

		return ResponseEntity.ok(cardDTOs);
	}

	/**
	 * Move a card to a different column
	 * @param cardId - the card ID
	 * @param newColumnId - the new column ID
	 * @return Success message
	 */
	@PutMapping("/{cardId}/move/{newColumnId}")
	public ResponseEntity<String> moveCard(@PathVariable Long cardId, @PathVariable Long newColumnId) {
		BoardCard card = boardCardRepository.findById(cardId)
			.orElseThrow(() -> new RuntimeException("Card not found with id: " + cardId));

		// Find the new column
		BoardColumn newColumn = boardColumnRepository.findById(newColumnId)
			.orElseThrow(() -> new RuntimeException("Column not found with id: " + newColumnId));

		// Update the card's column
		card.setColumn(newColumn);
		boardCardRepository.save(card);

		// Update the issue status based on column name
		if (card.getIssueId() != null) {
			Issue issue = issueRepository.findById(card.getIssueId()).orElse(null);
			if (issue != null) {
				String columnName = newColumn.getColumnName() != null ?
					newColumn.getColumnName().toUpperCase() :
					(newColumn.getName() != null ? newColumn.getName().toUpperCase() : "");

				// Map column names to issue statuses
				if (columnName.contains("TODO") || columnName.contains("BACKLOG")) {
					issue.setIssueStatus(com.TaskManagement.Enum.IssueStatus.TODO);
				} else if (columnName.contains("PROGRESS") || columnName.contains("DOING")) {
					issue.setIssueStatus(com.TaskManagement.Enum.IssueStatus.IN_PROGRESS);
				} else if (columnName.contains("REVIEW")) {
					issue.setIssueStatus(com.TaskManagement.Enum.IssueStatus.IN_REVIEW);
				} else if (columnName.contains("TEST")) {
					issue.setIssueStatus(com.TaskManagement.Enum.IssueStatus.IN_REVIEW); // Use IN_REVIEW for testing
				} else if (columnName.contains("DONE") || columnName.contains("COMPLETE")) {
					issue.setIssueStatus(com.TaskManagement.Enum.IssueStatus.DONE);
				}

				issueRepository.save(issue);
			}
		}

		return ResponseEntity.ok("Card moved successfully");
	}
}

