package com.TaskManagement.Controller;

import com.TaskManagement.Entity.IntegrationEvent;
import com.TaskManagement.Service.IntegrationEventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/integrations/events")
public class IntegrationEventController {
    @Autowired
    private IntegrationEventService integrationEventService;

    @GetMapping
    public ResponseEntity<List<IntegrationEvent>> getEvents(@RequestParam(required = false) String issueKey) {
        if (issueKey == null || issueKey.trim().isEmpty()) {
            // Return empty list if no issueKey provided, instead of error
            return ResponseEntity.ok(List.of());
        }
        List<IntegrationEvent> events = integrationEventService.getEventsByIssueKey(issueKey);
        return ResponseEntity.ok(events);
    }
}
