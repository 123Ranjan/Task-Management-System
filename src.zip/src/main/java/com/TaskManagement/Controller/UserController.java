package com.TaskManagement.Controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.ChangePasswordDTO;
import com.TaskManagement.Entity.User;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Enum.Role;
import com.TaskManagement.Security.PermissionConfig;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private PermissionService permissionService;

    @GetMapping("/all")
    public ResponseEntity<List<Map<String, Object>>> getAllUsers() {
        permissionService.requirePermission(Permission.USER_VIEW);
        List<User> users = userService.getAllUsers();
        List<Map<String, Object>> userList = new ArrayList<>();

        for (User user : users) {
            Map<String, Object> userMap = new HashMap<>();
            userMap.put("id", user.getId());
            userMap.put("username", user.getUserName());
            userMap.put("email", user.getUserEmail());
            userMap.put("role", user.getRole() != null ? user.getRole().name() : null);
            userMap.put("active", user.isActive());
            userList.add(userMap);
        }

        return ResponseEntity.ok(userList);
    }

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getCurrentUserProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        User user = userService.getUserByEmail(email);

        // Get user permissions
        Set<Permission> permissions = PermissionConfig.getPermissions(user.getRole());
        Set<String> permissionStrings = new HashSet<>();
        for (Permission p : permissions) {
            permissionStrings.add(p.name());
        }

        Map<String, Object> profile = new HashMap<>();
        profile.put("id", user.getId());
        profile.put("username", user.getUserName());
        profile.put("email", user.getUserEmail());
        profile.put("role", user.getRole() != null ? user.getRole().name() : null);
        profile.put("permissions", permissionStrings);
        profile.put("active", user.isActive());
        profile.put("createdAt", user.getCreatedAt());
        profile.put("assignedIssuesCount", 0); // TODO: Implement actual count
        profile.put("notificationsCount", 0); // TODO: Implement actual count

        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<Map<String, Object>> updateProfile(@RequestBody Map<String, Object> updates) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        User user = userService.getUserByEmail(email);

        // Update fields if provided
        if (updates.containsKey("username")) {
            user.setUserName((String) updates.get("username"));
        }

        // Save the updated user
        userService.saveUser(user);

        Map<String, Object> profile = new HashMap<>();
        profile.put("id", user.getId());
        profile.put("username", user.getUserName());
        profile.put("email", user.getUserEmail());
        profile.put("role", user.getRole() != null ? user.getRole().name() : null);

        return ResponseEntity.ok(profile);
    }

    @PutMapping("/password")
    public ResponseEntity<Map<String, String>> changePassword(@RequestBody ChangePasswordDTO passwordDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();

        try {
            userService.changePassword(email, passwordDTO.getCurrentPassword(), passwordDTO.getNewPassword());

            Map<String, String> response = new HashMap<>();
            response.put("message", "Password changed successfully");
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            Map<String, String> response = new HashMap<>();
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

    @PutMapping("/{id}/role")
    public ResponseEntity<Map<String, Object>> updateUserRole(@PathVariable Long id, @RequestParam Role role) {
        permissionService.requirePermission(Permission.USER_MANAGE);
        User updated = userService.updateRole(id, role);

        Map<String, Object> userMap = new HashMap<>();
        userMap.put("id", updated.getId());
        userMap.put("username", updated.getUserName());
        userMap.put("email", updated.getUserEmail());
        userMap.put("role", updated.getRole() != null ? updated.getRole().name() : null);
        userMap.put("active", updated.isActive());
        return ResponseEntity.ok(userMap);
    }

    @PutMapping("/{id}/active")
    public ResponseEntity<Map<String, Object>> setUserActive(@PathVariable Long id, @RequestParam boolean active) {
        permissionService.requirePermission(Permission.USER_MANAGE);
        User updated = userService.setActive(id, active);

        Map<String, Object> userMap = new HashMap<>();
        userMap.put("id", updated.getId());
        userMap.put("username", updated.getUserName());
        userMap.put("email", updated.getUserEmail());
        userMap.put("role", updated.getRole() != null ? updated.getRole().name() : null);
        userMap.put("active", updated.isActive());
        return ResponseEntity.ok(userMap);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Long id) {
        // permission checked in service as well; do it here for consistent 403
        permissionService.requirePermission(Permission.USER_MANAGE);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String email = authentication.getName();
        User currentUser = userService.getUserByEmail(email);

        userService.deleteUser(id, currentUser);

        Map<String, String> response = new HashMap<>();
        response.put("message", "User deleted successfully");
        return ResponseEntity.ok(response);
    }
}
