package com.TaskManagement.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

import com.TaskManagement.DTO.EmailLogDTO;
import com.TaskManagement.Entity.Notification;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.NotificationService;

import lombok.*;

@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
public class NotificationController {

	@Autowired
	private NotificationService notification;
	
	@Autowired
	private PermissionService permissionService;

	@GetMapping
	public ResponseEntity<List<Notification>> getNotifications(@AuthenticationPrincipal UserDetails userDetails) {
		permissionService.requirePermission(Permission.NOTIFICATION_VIEW);
		String email = userDetails.getUsername();
		List<Notification> notifications = notification.getNotificationsForUser(email);
		return ResponseEntity.ok(notifications);
	}

	@PostMapping("/send")
	public ResponseEntity<String> sendEmail(@RequestBody EmailLogDTO dto) {
		permissionService.requirePermission(Permission.NOTIFICATION_SEND);
		notification.sendEmail(dto);
		return ResponseEntity.ok("Email sent successfully");
	}

	@PutMapping("/{id}/read")
	public ResponseEntity<Void> markAsRead(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails) {
        permissionService.requirePermission(Permission.NOTIFICATION_VIEW);
        notification.markAsRead(id, userDetails.getUsername());
        return ResponseEntity.ok().build();
    }

    @PutMapping("/read-all")
    public ResponseEntity<Void> markAllAsRead(@AuthenticationPrincipal UserDetails userDetails) {
        permissionService.requirePermission(Permission.NOTIFICATION_VIEW);
        notification.markAllAsRead(userDetails.getUsername());
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNotification(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails) {
        permissionService.requirePermission(Permission.NOTIFICATION_VIEW);
        notification.deleteNotification(id, userDetails.getUsername());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/unread-count")
    public ResponseEntity<Integer> getUnreadCount(@AuthenticationPrincipal UserDetails userDetails) {
        permissionService.requirePermission(Permission.NOTIFICATION_VIEW);
        String email = userDetails.getUsername();
        int count = notification.getUnreadCountForUser(email);
        return ResponseEntity.ok(count);
    }
}
