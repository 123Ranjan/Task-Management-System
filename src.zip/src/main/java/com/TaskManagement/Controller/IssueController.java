package com.TaskManagement.Controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.IssueDTO;
import com.TaskManagement.Entity.IssueComments;
import com.TaskManagement.Enum.IssueStatus;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.IssueService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/issues")
@RequiredArgsConstructor
public class IssueController {

	@Autowired
	private IssueService issueService;
	
	@Autowired
	private PermissionService permissionService;


	@PostMapping("/create")
	public ResponseEntity<IssueDTO>create(@RequestBody IssueDTO dto, @RequestHeader(value = "X-User_Email", required = false) String userEmail){
		permissionService.requirePermission(Permission.ISSUE_CREATE);
		// If reporterEmail is not set in payload, use header (current user) or security context
		String reporter = dto.getReporterEmail();
		if((reporter == null || reporter.isEmpty())) {
			if(userEmail != null && !userEmail.isEmpty()) {
				reporter = userEmail;
			} else {
				Authentication auth = SecurityContextHolder.getContext().getAuthentication();
				if(auth != null) reporter = auth.getName();
			}
			if(reporter != null) dto.setReporterEmail(reporter);
		}
		// Prevent assigning to self
		if(dto.getAssignedEmail() != null && dto.getReporterEmail()!=null && dto.getAssignedEmail().equals(dto.getReporterEmail())) {
			throw new RuntimeException("Cannot assign issue to yourself");
		}
		IssueDTO created = issueService.createIssue(dto);
		return ResponseEntity.ok(created);
	}

	@GetMapping("/{id}")
	public ResponseEntity<IssueDTO>getByIssueId(@PathVariable Long id){
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		return ResponseEntity.ok(issueService.getById(id));
	}

	@GetMapping("/assign/{assignedEmail}")
	public ResponseEntity<List<IssueDTO>>getByAssignedEmail(@PathVariable String assignedEmail){
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		return ResponseEntity.ok(issueService.getByAssignedEmail(assignedEmail));
	}

	@PatchMapping("/{id}/status")
	public ResponseEntity<IssueDTO>updateStatus(@PathVariable Long id, 
												@RequestParam IssueStatus issueStatus,
												@RequestHeader(value="X-User_Email",required = false) String user){
		permissionService.requirePermission(Permission.ISSUE_EDIT);
		return ResponseEntity.ok(issueService.updateStatus(id, issueStatus,user));
		
	}

	@PostMapping("/{id}/comments")
	public ResponseEntity<IssueComments> addComments(@PathVariable Long id,
        @RequestBody Map<String, String> body,
        @RequestHeader(value = "X-User_Email", required = false) String user) {
    permissionService.requirePermission(Permission.COMMENT_ADD);
    String commentBody = body.get("body");
    String author = user;
    if (author == null || author.isEmpty()) {
        // Try to get from security context (JWT)
        org.springframework.security.core.Authentication auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.getName() != null && !auth.getName().equals("anonymousUser")) {
            author = auth.getName();
        }
    }
    if (author == null || author.isEmpty()) {
        throw new RuntimeException("Could not determine comment author email");
    }
    return ResponseEntity.ok(issueService.addComment(id, author, commentBody));
}

	@GetMapping("/{id}/comments")
	public ResponseEntity<List<IssueComments>> getComments(@PathVariable Long id) {
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		return ResponseEntity.ok(issueService.getComments(id));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Map<String, String>> deleteIssue(@PathVariable Long id) {
		permissionService.requirePermission(Permission.ISSUE_DELETE);
		issueService.deleteIssue(id);
		return ResponseEntity.ok(Map.of("message", "Issue deleted successfully"));
	}

	@DeleteMapping("/{id}/comments/{commentId}")
	public ResponseEntity<Map<String, String>> deleteComment(@PathVariable Long id, @PathVariable Long commentId) {
		permissionService.requirePermission(Permission.COMMENT_DELETE);
		issueService.deleteComment(id, commentId);
		return ResponseEntity.ok(Map.of("message", "Comment deleted successfully"));
	}

	@GetMapping("/search")
	public ResponseEntity<List<IssueDTO>> searchIssues(@RequestParam("q") String query) {
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		String q = query.toLowerCase();
		List<IssueDTO> all = issueService.search(Map.of());
		List<IssueDTO> filtered = all.stream()
			.filter(i -> (i.getIssueTitle() != null && i.getIssueTitle().toLowerCase().contains(q)) ||
				(i.getIssueKey() != null && i.getIssueKey().toLowerCase().contains(q)))
			.collect(Collectors.toList());
		return ResponseEntity.ok(filtered);
	}

	@PutMapping("/{id}")
	public ResponseEntity<IssueDTO> updateIssue(@PathVariable Long id, @RequestBody IssueDTO dto) {
		permissionService.requirePermission(Permission.ISSUE_EDIT);
		IssueDTO updated = issueService.updateIssue(id, dto);
		return ResponseEntity.ok(updated);
	}
}
