package com.TaskManagement.Controller;

import com.TaskManagement.Entity.IssueLink;
import com.TaskManagement.Service.IssueLinkService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class IssueLinkController {

	private final IssueLinkService issueLinkService;

	// Create link
	@PostMapping("/api/issueLinks/create")
	public ResponseEntity<IssueLink> create(@RequestBody IssueLink link) {
		return ResponseEntity.ok(
				issueLinkService.createLink(
						link.getSourceIssueId(),
						link.getTargetIssueId(),
						link.getLinkType()
				)
		);
	}

	// Get by source issue
	@GetMapping("/api/issueLinks/source/{id}")
	public ResponseEntity<List<IssueLink>> getBySource(@PathVariable Long id) {
		return ResponseEntity.ok(issueLinkService.getLinksBySource(id));
	}

	// Get by target issue
	@GetMapping("/api/issueLinks/target/{id}")
	public ResponseEntity<List<IssueLink>> getByTarget(@PathVariable Long id) {
		return ResponseEntity.ok(issueLinkService.getLinksByTarget(id));
	}

	// Jira style endpoint
	@GetMapping("/api/issues/{id}/links")
	public ResponseEntity<List<IssueLink>> getLinksForIssue(@PathVariable Long id) {
		return ResponseEntity.ok(issueLinkService.getLinksBySource(id));
	}

	// Delete link
	@DeleteMapping("/api/issueLinks/{id}")
	public ResponseEntity<Void> delete(@PathVariable Long id) {
		issueLinkService.deleteLink(id);
		return ResponseEntity.noContent().build();
	}
}
