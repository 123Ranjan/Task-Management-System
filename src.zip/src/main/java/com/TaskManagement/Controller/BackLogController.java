package com.TaskManagement.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.IssueDTO;
import com.TaskManagement.Entity.Issue;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.BackLogService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping({"/api/backLogs", "/api/backlog"})
@RequiredArgsConstructor
public class BackLogController {
	
	
	@Autowired
	private BackLogService backLogService;
	
	@Autowired
	private PermissionService permissionService;


	@GetMapping("/{projectId}")
	public ResponseEntity<List<IssueDTO>>getBackLogs(@PathVariable(required=false)Long projectId){
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		return ResponseEntity.ok(backLogService.getBackLogDTOs(projectId));
	}
	
	@GetMapping("/{projectId}/hierarchy")
	public ResponseEntity<Map<String,Object>>getHierachry(@PathVariable(required=false) Long projectId ){
		permissionService.requirePermission(Permission.ISSUE_VIEW);
		return ResponseEntity.ok(backLogService.getBackLogHierarchy(projectId));
	}
	@PostMapping("/{projectId}/record")
	public ResponseEntity<String>record(@PathVariable(required=false) Long projectId,@RequestBody List<Long> orderIds){
		permissionService.requirePermission(Permission.ISSUE_EDIT);
		backLogService.recordBacklog(projectId, orderIds);
		return ResponseEntity.ok("BackLog Recored");
	}

	@PostMapping("/{issueId}/moveToBoard")
	public ResponseEntity<String>moveToBoard(@PathVariable Long issueId, @RequestBody Map<String, Object> request){
		permissionService.requirePermission(Permission.ISSUE_EDIT);
		Long boardId = Long.valueOf(request.get("boardId").toString());
		backLogService.moveIssueToBoard(issueId, boardId);
		return ResponseEntity.ok("Issue moved to board successfully");
	}

	@PutMapping("add-to_sprint/{issueId}")
	public ResponseEntity<Issue>addToSprint(@PathVariable Long issueId,@PathVariable Long sprintId){
		permissionService.requirePermission(Permission.SPRINT_EDIT);
		return ResponseEntity.ok(backLogService.addIssueToSprint(issueId, sprintId));
	}

}
