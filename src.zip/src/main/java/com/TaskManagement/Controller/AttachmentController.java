package com.TaskManagement.Controller;

import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.TaskManagement.Entity.Attachment;
import com.TaskManagement.Service.AttachmentService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.InputStream;
import java.io.OutputStream;

@RestController
@RequestMapping("/api/file_upload")
@CrossOrigin(origins = "http://localhost:3000", allowCredentials = "true")
public class AttachmentController {

	@Autowired
	private AttachmentService attachmentService;
	
	@PostMapping("/upload")
	public ResponseEntity<Attachment> ulpoad(@RequestParam Long issueId, @RequestParam MultipartFile file, @RequestParam(required = false) String uploadedBy) {
	    // If uploadedBy is not provided, get from security context
	    if (uploadedBy == null || uploadedBy.isEmpty()) {
	        org.springframework.security.core.Authentication auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
	        if (auth != null) {
	            uploadedBy = auth.getName();
	        } else {
	            uploadedBy = "unknown";
	        }
	    }
	    Attachment saved = attachmentService.upload(issueId, file, uploadedBy);
	    return ResponseEntity.ok(saved);
	}
	
	@GetMapping("/issue/{issueId}")
	public ResponseEntity<List<Attachment>> listForIssue(@PathVariable Long issueId) {
	    return ResponseEntity.ok(attachmentService.listForIssue(issueId));
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteAttachment(@PathVariable Long id) {
	    attachmentService.delete(id);
	    return ResponseEntity.ok("Attachment deleted");
	}

	@DeleteMapping("/delete/{attachmentId}")
	public ResponseEntity<String> deleteAttachmentFromDatabase(@PathVariable Long attachmentId) {
	    try {
	        attachmentService.deleteAttachmentFromDatabase(attachmentId);
	        return ResponseEntity.ok("Attachment deleted from database");
	    } catch (Exception e) {
	        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete attachment");
	    }
	}

	@GetMapping("/{id}/download")
	public void downloadPdf(@PathVariable Long id, HttpServletResponse response) {
	    String filename = attachmentService.getDownloadFilename(id);
	    response.setContentType("application/pdf");
	    response.setHeader(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"");
	    try (InputStream is = attachmentService.downloadStream(id)) {
	        IOUtils.copy(is, response.getOutputStream());
	        response.flushBuffer();
	    } catch (Exception e) {
	        response.setStatus(HttpServletResponse.SC_NOT_FOUND);
	    }
	}
}
