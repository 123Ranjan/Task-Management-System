package com.TaskManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.WorkFlowDTO;
import com.TaskManagement.Entity.Status;
import com.TaskManagement.Entity.WorkFlow;
import com.TaskManagement.Entity.WorkFlowTransaction;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.WorkFlowService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/workflows")  // Changed to lowercase to match frontend - fixed missing leading slash
@RequiredArgsConstructor
public class WorkFlowController {
	
	
	@Autowired
	private WorkFlowService workflowService;
	
	@Autowired
	private PermissionService permissionService;


	@PostMapping("/create")
	public ResponseEntity<WorkFlowDTO> create(@RequestBody WorkFlow workFlow) {
		permissionService.requirePermission(Permission.WORKFLOW_CREATE);
		WorkFlow wf = workflowService.createworkFlow(workFlow.getName(), workFlow.getTransactions());
		return ResponseEntity.ok(workflowService.toDTO(wf));
	}

	@GetMapping("/all")
	public ResponseEntity<?> getAll() {
		try {
			permissionService.requirePermission(Permission.WORKFLOW_VIEW);
			List<WorkFlowDTO> workflows = workflowService.getAllWorkFlowDTOs();
			return ResponseEntity.ok(workflows);
		} catch (Exception e) {
			// Log the error and return a meaningful message
			System.err.println("Error fetching workflows: " + e.getMessage());
			e.printStackTrace();
			return ResponseEntity.status(500).body("Error fetching workflows: " + e.getMessage());
		}
	}
	
	@GetMapping("/{name}")
	public ResponseEntity<WorkFlowDTO> getByName(@PathVariable String name) {
		permissionService.requirePermission(Permission.WORKFLOW_VIEW);
		return ResponseEntity.ok(workflowService.toDTO(workflowService.getWorkflow(name)));
	}

	// STATUS ENDPOINTS
	@PostMapping("/status")
	public ResponseEntity<Status> createStatus(@RequestBody Status status) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    Status created = workflowService.createStatus(status);
	    return ResponseEntity.ok(created);
	}

	@PutMapping("/status/{id}")
	public ResponseEntity<Status> updateStatus(@PathVariable Long id, @RequestBody Status status) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    Status updated = workflowService.updateStatus(id, status);
	    return ResponseEntity.ok(updated);
	}

	@DeleteMapping("/status/{id}")
	public ResponseEntity<Void> deleteStatus(@PathVariable Long id) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    workflowService.deleteStatus(id);
	    return ResponseEntity.noContent().build();
	}

	@GetMapping("/status")
	public ResponseEntity<List<Status>> getAllStatuses() {
	    permissionService.requirePermission(Permission.WORKFLOW_VIEW);
	    return ResponseEntity.ok(workflowService.getAllStatuses());
	}

	@GetMapping("/status/{id}")
	public ResponseEntity<Status> getStatus(@PathVariable Long id) {
	    permissionService.requirePermission(Permission.WORKFLOW_VIEW);
	    return ResponseEntity.ok(workflowService.getStatus(id));
	}

	// TRANSITION (WorkFlowTransaction) ENDPOINTS
	@PostMapping("/transition")
	public ResponseEntity<WorkFlowTransaction> createTransition(@RequestBody WorkFlowTransaction transaction,
	                                                           @RequestParam Long fromStatusId,
	                                                           @RequestParam Long toStatusId,
	                                                           @RequestParam Long workFlowId) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    WorkFlowTransaction created = workflowService.createTransition(transaction, fromStatusId, toStatusId, workFlowId);
	    return ResponseEntity.ok(created);
	}

	@PutMapping("/transition/{id}")
	public ResponseEntity<WorkFlowTransaction> updateTransition(@PathVariable Long id,
	                                                           @RequestBody WorkFlowTransaction transaction,
	                                                           @RequestParam Long fromStatusId,
	                                                           @RequestParam Long toStatusId,
	                                                           @RequestParam Long workFlowId) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    WorkFlowTransaction updated = workflowService.updateTransition(id, transaction, fromStatusId, toStatusId, workFlowId);
	    return ResponseEntity.ok(updated);
	}

	@DeleteMapping("/transition/{id}")
	public ResponseEntity<Void> deleteTransition(@PathVariable Long id) {
	    permissionService.requirePermission(Permission.WORKFLOW_CREATE);
	    workflowService.deleteTransition(id);
	    return ResponseEntity.noContent().build();
	}

	@GetMapping("/transition")
	public ResponseEntity<List<WorkFlowTransaction>> getAllTransitions() {
	    permissionService.requirePermission(Permission.WORKFLOW_VIEW);
	    return ResponseEntity.ok(workflowService.getAllTransitions());
	}

}


