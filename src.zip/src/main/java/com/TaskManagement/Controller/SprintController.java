package com.TaskManagement.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.TaskManagement.DTO.IssueDTO;
import com.TaskManagement.Entity.Issue;
import com.TaskManagement.Entity.Sprint;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Security.PermissionService;
import com.TaskManagement.Service.IssueService;
import com.TaskManagement.Service.SprintService;

@RestController
@RequestMapping("/api/sprints")
public class SprintController {

	@Autowired
	private SprintService sprintService;
	
	@Autowired
	private IssueService issueService;

	@Autowired
	private PermissionService permissionService;

	@GetMapping
	public ResponseEntity<List<Sprint>> getAllSprints() {
		permissionService.requirePermission(Permission.SPRINT_VIEW);
		return ResponseEntity.ok(sprintService.getAllSprints());
	}

	@GetMapping("/byBoard/{boardId}")
	public ResponseEntity<List<Sprint>> getSprintsByBoard(@PathVariable Long boardId) {
		permissionService.requirePermission(Permission.SPRINT_VIEW);
		return ResponseEntity.ok(sprintService.getSprintsByBoard(boardId));
	}

	@PostMapping("/create")
	public ResponseEntity<Sprint> createSprint(@RequestBody Sprint sprint) {
		permissionService.requirePermission(Permission.SPRINT_CREATE);
		return ResponseEntity.ok(sprintService.createSprint(sprint));
	}
	
	@PutMapping("/assign/{sprintId}/{issueId}")
	public ResponseEntity<Issue> assignIssueToSprint(@PathVariable Long sprintId, @PathVariable Long issueId) {
		permissionService.requirePermission(Permission.SPRINT_EDIT);
		return ResponseEntity.ok(sprintService.assignIssueToSprint(sprintId, issueId));
	}
	
	@PutMapping("/{sprintId}/start")
	public ResponseEntity<Sprint> startSprint(@PathVariable Long sprintId) {
		permissionService.requirePermission(Permission.SPRINT_START);
		return ResponseEntity.ok(sprintService.startSprint(sprintId));
	}

	@PutMapping("/{sprintId}/close")
	public ResponseEntity<Sprint> closeSprint(@PathVariable Long sprintId) {
		permissionService.requirePermission(Permission.SPRINT_CLOSE);
		return ResponseEntity.ok(sprintService.closeSprint(sprintId));
	}

	@GetMapping("/{sprintId}/burnDown")
	public ResponseEntity<Map<String,Object>> getBurnDown(@PathVariable Long sprintId) {
		permissionService.requirePermission(Permission.SPRINT_VIEW);
		return ResponseEntity.ok(sprintService.getBurnDownDate(sprintId));
	}

	@GetMapping("/{sprintId}/issues")
	public ResponseEntity<List<IssueDTO>> getSprintIssues(@PathVariable Long sprintId) {
		permissionService.requirePermission(Permission.SPRINT_VIEW);
		return ResponseEntity.ok(issueService.getBySprint(sprintId));
	}

	@GetMapping("/current/{projectId}")
	public ResponseEntity<Sprint> getCurrentSprintForBoard(@PathVariable Long projectId) {
		permissionService.requirePermission(Permission.SPRINT_VIEW);
		return ResponseEntity.ok(sprintService.getCurrentSprintForBoard(projectId));
	}
}
