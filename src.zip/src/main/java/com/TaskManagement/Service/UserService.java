package com.TaskManagement.Service;

import java.util.Optional;
import java.util.Set;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManagement.DTO.AuthenticationResponseDTO;
import com.TaskManagement.DTO.LoginRequestDTO;
import com.TaskManagement.DTO.RegisterRequestDTO;
import com.TaskManagement.Entity.User;
import com.TaskManagement.Enum.Permission;
import com.TaskManagement.Repository.UserRepository;
import com.TaskManagement.Security.JWTUtil;
import com.TaskManagement.Security.PermissionConfig;
import com.TaskManagement.Enum.Role;
import org.springframework.security.crypto.password.PasswordEncoder;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private JWTUtil jwtUtil;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	public List<User> getAllUsers() {
		return userRepo.findAll();
	}

	public AuthenticationResponseDTO register(RegisterRequestDTO request) {
		
		Optional<User>existing = userRepo.findByUserEmail(request.getUserEmail());
		if(existing.isPresent()) {
			throw new RuntimeException("User already exist");
		}
		User user = new User();
		user.setUserName(request.getUserName());
		user.setUserEmail(request.getUserEmail());
		user.setPassword(passwordEncoder.encode(request.getPassword()));
		user.setRole(request.getRole());
		user.setCreatedAt(java.time.LocalDateTime.now());
		userRepo.save(user);
		String token = jwtUtil.generateToken(user);

		// Get user's role and permissions
		Role userRole = user.getRole();
		Set<Permission> permissions = PermissionConfig.getPermissions(userRole);

		// Convert permissions to strings
		Set<String> permissionStrings = new java.util.HashSet<>();
		for (Permission p : permissions) {
			permissionStrings.add(p.name());
		}

		return new AuthenticationResponseDTO(
			token,
			"User registered successfully",
			user.getId(),
			user.getUserName(),
			userRole.name(),
			permissionStrings
		);
	}
	
	public AuthenticationResponseDTO login(LoginRequestDTO dto) {

		User user = userRepo.findByUserEmail(dto.getUserEmail())
				.orElseThrow(()-> new RuntimeException("Account not found. Please register."));

		if(!passwordEncoder.matches(dto.getPassword(), user.getPassword())) {
			throw new RuntimeException("Invalid password. Please try again.");
		}
		String token = jwtUtil.generateToken(user);

		// Get user's role and permissions
		Role userRole = user.getRole();
		Set<Permission> permissions = PermissionConfig.getPermissions(userRole);

		// Convert permissions to strings
		Set<String> permissionStrings = new java.util.HashSet<>();
		for (Permission p : permissions) {
			permissionStrings.add(p.name());
		}

		return new AuthenticationResponseDTO(
			token,
			"Login successful",
			user.getId(),
			user.getUserName(),
			userRole.name(),
			permissionStrings
		);
	}
	
	public User updateRole(Long id, Role role) {
		User user = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		user.setRole(role);
		return userRepo.save(user);
	}

	public User setActive(Long id, boolean active) {
		User user = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		user.setActive(active);
		return userRepo.save(user);
	}
	
	public void deleteUser(Long id, User currentUser) {
		Set<Permission> perm = PermissionConfig.getPermissions(currentUser.getRole());
		if (!perm.contains(Permission.USER_MANAGE)) {
			throw new RuntimeException("Access denied");
		}
		User toDelete = userRepo.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
		userRepo.delete(toDelete);
	}

	public User getUserByEmail(String email) {
		return userRepo.findByUserEmail(email)
				.orElseThrow(() -> new RuntimeException("User not found"));
	}

	public User getUserById(Long id) {
		return userRepo.findById(id)
				.orElseThrow(() -> new RuntimeException("User not found"));
	}

	public User saveUser(User user) {
		return userRepo.save(user);
	}

	public void changePassword(String email, String currentPassword, String newPassword) {
		User user = userRepo.findByUserEmail(email)
				.orElseThrow(() -> new RuntimeException("User not found"));

		// Verify current password
		if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
			throw new RuntimeException("Current password is incorrect");
		}

		// Update to new password
		user.setPassword(passwordEncoder.encode(newPassword));
		userRepo.save(user);
	}
}
