package com.TaskManagement.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManagement.DTO.WorkFlowDTO;
import com.TaskManagement.DTO.WorkFlowTransactionDTO;
import com.TaskManagement.Entity.Status;
import com.TaskManagement.Entity.WorkFlow;
import com.TaskManagement.Entity.WorkFlowTransaction;
import com.TaskManagement.Repository.StatusRepository;
import com.TaskManagement.Repository.WorkFlowTransactionRepository;
import com.TaskManagement.Repository.WorkflowRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class WorkFlowService {
	
	
	@Autowired
	private WorkflowRepository workFlowRepo;
	
	@Autowired
	private WorkFlowTransactionRepository transactionRepo;
	
	@Autowired
	private StatusRepository statusRepository;

	public WorkFlow createworkFlow(String name,List<WorkFlowTransaction> transactions) {
		
		WorkFlow wf= new WorkFlow();
		wf.setName(name);
		for(WorkFlowTransaction t: transactions) {
			t.setWorkFlow(wf);
		}
		wf.setTransactions(transactions);
		return workFlowRepo.save(wf);
		
	}
	
	public WorkFlow getWorkflow(String name) {
		return workFlowRepo.findByName(name).orElseThrow(()-> new RuntimeException("WorkFlow not found"));
	}
	
	public List<WorkFlow>getAllWorkFlows(){
		return workFlowRepo.findAll();
	}
	
	// TODO: Implement custom status-based transaction permission logic if needed in the future


	// STATUS CRUD METHODS
	public Status createStatus(Status status) {
	    if (statusRepository.existsByName(status.getName())) {
	        throw new RuntimeException("Status name already exists");
	    }
	    return statusRepository.save(status);
	}

	public Status updateStatus(Long id, Status status) {
	    Status existing = statusRepository.findById(id)
	        .orElseThrow(() -> new RuntimeException("Status not found"));
	    existing.setName(status.getName());
	    existing.setDescription(status.getDescription());
	    existing.setColor(status.getColor());
	    return statusRepository.save(existing);
	}

	public void deleteStatus(Long id) {
	    if (!statusRepository.existsById(id)) {
	        throw new RuntimeException("Status not found");
	    }
	    statusRepository.deleteById(id);
	}

	public List<Status> getAllStatuses() {
	    return statusRepository.findAll();
	}

	public Status getStatus(Long id) {
	    return statusRepository.findById(id)
	        .orElseThrow(() -> new RuntimeException("Status not found"));
	}

	// TRANSITION (WorkFlowTransaction) CRUD METHODS
    public WorkFlowTransaction createTransition(WorkFlowTransaction transaction, Long fromStatusId, Long toStatusId, Long workFlowId) {
        Status fromStatus = statusRepository.findById(fromStatusId)
            .orElseThrow(() -> new RuntimeException("From Status not found"));
        Status toStatus = statusRepository.findById(toStatusId)
            .orElseThrow(() -> new RuntimeException("To Status not found"));
        WorkFlow workFlow = workFlowRepo.findById(workFlowId)
            .orElseThrow(() -> new RuntimeException("WorkFlow not found"));
        transaction.setFromStatus(fromStatus);
        transaction.setToStatus(toStatus);
        transaction.setWorkFlow(workFlow);
        return transactionRepo.save(transaction);
    }

    public WorkFlowTransaction updateTransition(Long id, WorkFlowTransaction transaction, Long fromStatusId, Long toStatusId, Long workFlowId) {
        WorkFlowTransaction existing = transactionRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("Transition not found"));
        Status fromStatus = statusRepository.findById(fromStatusId)
            .orElseThrow(() -> new RuntimeException("From Status not found"));
        Status toStatus = statusRepository.findById(toStatusId)
            .orElseThrow(() -> new RuntimeException("To Status not found"));
        WorkFlow workFlow = workFlowRepo.findById(workFlowId)
            .orElseThrow(() -> new RuntimeException("WorkFlow not found"));
        existing.setFromStatus(fromStatus);
        existing.setToStatus(toStatus);
        existing.setActionName(transaction.getActionName());
        existing.setRole(transaction.getRole());
        existing.setWorkFlow(workFlow);
        return transactionRepo.save(existing);
    }

    public void deleteTransition(Long id) {
        if (!transactionRepo.existsById(id)) {
            throw new RuntimeException("Transition not found");
        }
        transactionRepo.deleteById(id);
    }

    public List<WorkFlowTransaction> getAllTransitions() {
        return transactionRepo.findAll();
    }

    public List<WorkFlowDTO> getAllWorkFlowDTOs() {
        List<WorkFlow> workflows = workFlowRepo.findAll();
        if (workflows == null) return List.of();
        return workflows.stream()
            .map(this::toDTO)
            .collect(Collectors.toList());
    }

    public WorkFlowDTO toDTO(WorkFlow wf) {
        List<WorkFlowTransactionDTO> txDTOs = (wf.getTransactions() != null)
            ? wf.getTransactions().stream().filter(java.util.Objects::nonNull).map(this::toDTO).collect(Collectors.toList())
            : List.of();
        // Collect all statuses referenced by transactions
        List<Status> statuses = wf.getTransactions() != null ?
            wf.getTransactions().stream()
                .flatMap(tx -> List.of(tx.getFromStatus(), tx.getToStatus()).stream())
                .filter(java.util.Objects::nonNull)
                .distinct()
                .collect(Collectors.toList()) : List.of();
        return new WorkFlowDTO(wf.getId(), wf.getName(), txDTOs, statuses);
    }

    public WorkFlowTransactionDTO toDTO(WorkFlowTransaction tx) {
        return new WorkFlowTransactionDTO(
            tx.getId(),
            tx.getFromStatus() != null ? tx.getFromStatus().getName() : null,
            tx.getToStatus() != null ? tx.getToStatus().getName() : null,
            tx.getFromStatus() != null ? tx.getFromStatus().getId() : null,
            tx.getToStatus() != null ? tx.getToStatus().getId() : null,
            tx.getActionName(),
            tx.getRole()
        );
    }
}

