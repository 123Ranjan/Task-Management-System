package com.TaskManagement.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.io.InputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

@Service
public class SupabaseStorageService {
    @Value("${supabase.url}")
    private String supabaseUrl;
    @Value("${supabase.secret}")
    private String supabaseSecret;
    @Value("${supabase.bucket}")
    private String bucket;

    private final WebClient webClient = WebClient.builder().build();

    public String upload(MultipartFile file, String folder) {
        try {
            String fileName = file.getOriginalFilename();
            String storagePath = folder + "/" + fileName;
            String uploadUrl = supabaseUrl + "/storage/v1/object/" + bucket + "/" + storagePath + "?upsert=true";

            String response = webClient.put()
                    .uri(uploadUrl)
                    .header("Authorization", "Bearer " + supabaseSecret)
                    .header("Content-Type", file.getContentType())
                    .bodyValue(file.getBytes())
                    .retrieve()
                    .onStatus(
                        status -> !status.is2xxSuccessful(),
                        clientResponse -> clientResponse.bodyToMono(String.class).map(body -> new RuntimeException("Supabase upload failed: " + body))
                    )
                    .bodyToMono(String.class)
                    .block();

            return storagePath;
        } catch (Exception e) {
            e.printStackTrace(); // Log the error for debugging
            throw new RuntimeException("Failed to upload file to Supabase Storage: " + e.getMessage(), e);
        }
    }

    public InputStream download(String storagePath) {
        try {
            String urlStr = supabaseUrl + "/storage/v1/object/public/" + bucket + "/" + storagePath;
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Authorization", "Bearer " + supabaseSecret);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed to download file from Supabase Storage");
            }
            return conn.getInputStream();
        } catch (IOException e) {
            throw new RuntimeException("Failed to download file from Supabase Storage", e);
        }
    }

    public void delete(String storagePath) {
        // Implement Supabase Storage delete logic here (using HTTP DELETE)
        // For now, this is a placeholder
    }
}
