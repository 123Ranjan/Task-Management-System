package com.TaskManagement.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManagement.DTO.IssueDTO;
import com.TaskManagement.Entity.Board;
import com.TaskManagement.Entity.BoardCard;
import com.TaskManagement.Entity.BoardColumn;
import com.TaskManagement.Entity.Issue;
import com.TaskManagement.Entity.Sprint;
import com.TaskManagement.Enum.SprintState;
import com.TaskManagement.Repository.BoardCardRepository;
import com.TaskManagement.Repository.BoardRepository;
import com.TaskManagement.Repository.IssueRepository;
import com.TaskManagement.Repository.SprintRepository;

import jakarta.transaction.Transactional;

@Service

public class BackLogService {
	@Autowired
	private IssueRepository issueRepo;
	
	@Autowired
	private SprintRepository sprintRepo;
	
	@Autowired
	private IssueService issueService;

	@Autowired
	private BoardRepository boardRepo;

	@Autowired
	private BoardCardRepository boardCardRepo;

	public List<Issue>getBackLog(Long projectId){
		if(projectId == null) {
			// If no projectId, return all issues not in a sprint
			return issueRepo.findBySprintIdIsNull();
		}
		return issueRepo.findByProjectIdAndSprintIdIsNullOrderByBackLogPosition(projectId);
	}
	
	public List<IssueDTO> getBackLogDTOs(Long projectId) {
		List<Issue> issues = getBackLog(projectId);
		return issues.stream()
				.map(issue -> issueService.convertToDTO(issue))
				.collect(Collectors.toList());
	}

	@Transactional
	public void moveIssueToBoard(Long issueId, Long boardId) {
		Issue issue = issueRepo.findById(issueId)
				.orElseThrow(() -> new RuntimeException("Issue not found"));

		// Get the board
		Board board = boardRepo.findById(boardId)
				.orElseThrow(() -> new RuntimeException("Board not found"));

		// Get or create first column
		// Get or create first column
		List<BoardColumn> columns = board.getColumns();
		if (columns == null || columns.isEmpty()) {
			// Auto-create a default "To Do" column
			BoardColumn firstColumn = new BoardColumn();
			firstColumn.setColumnName("To Do");  // Fixed: use setColumnName()
			firstColumn.setBoard(board);
			firstColumn.setPosition(0);
			firstColumn.setStatusKey("todo");    // Add status key if needed
			firstColumn.setWipLimit(0);          // Set default WIP limit

			// Initialize if null
			if (columns == null) {
				board.setColumns(new ArrayList<>());
				columns = board.getColumns();
			}

			// Add the new column
			columns.add(firstColumn);
			boardRepo.save(board);  // Save the board with the new column
		}
		// Sort columns by position to get first column
		BoardColumn firstColumn = columns.stream()
				.sorted((a, b) -> Integer.compare(
						a.getPosition() != null ? a.getPosition() : 0,
						b.getPosition() != null ? b.getPosition() : 0))
				.findFirst()
				.orElseThrow(() -> new RuntimeException("Board has no columns"));

		// Remove from backlog - set sprintId to -1 to indicate "on board but not in sprint"
		issue.setSprintId(-1L);
		issue.setBackLogPosition(null);
		issueRepo.save(issue);

		// Check if card already exists for this issue on this board
		List<BoardCard> existingCards = boardCardRepo.findByIssueIdAndBoardId(issueId, boardId);
		if (!existingCards.isEmpty()) {
			// Card already exists, don't create duplicate
			return;
		}

		// Create board card
		BoardCard card = new BoardCard();
		card.setIssueId(issueId);
		card.setBoardId(boardId);
		card.setColumn(firstColumn);
		card.setPosition(0); // Add at top of column
		boardCardRepo.save(card);
	}

	@Transactional
	public void recordBacklog(Long projectId, List<Long>orderIssueId) {
		int post=0;
		for(Long issueId :orderIssueId ) {
			Issue issue = issueRepo.findById(issueId).orElseThrow(()-> new RuntimeException("Issue not found"));
			issue.setBackLogPosition(post++);
			issueRepo.save(issue);
			
		}
	}
	
	@Transactional
	public Issue addIssueToSprint(Long issueId,Long sprintId) {
		
		Issue issue = issueRepo.findById(issueId).orElseThrow(()-> new RuntimeException("Issue not found"));
		Sprint sprint = sprintRepo.findById(sprintId).orElseThrow(()-> new RuntimeException("Sprint not found"));
		
		SprintState status= sprint.getState();
		if(status!=SprintState.PLANNED && status != SprintState.ACTIVE ) {
			throw new RuntimeException("Can not add issue to sprint in state : "+status);
			
		}
		issue.setSprintId(sprintId);
		issue.setBackLogPosition(null);
		issueRepo.save(issue);
		return issue;
		
	}
	
	@SuppressWarnings("unchecked")
	public Map<String,Object>getBackLogHierarchy(Long projectId){
		
		List<Issue>backLog= getBackLog(projectId);
		Map<Long,Map<String,Object>>epicMap= new LinkedHashMap<>();
		
		
		for(Issue i :backLog) {
			if(i.getIssueType() !=null && "EPIC".equalsIgnoreCase(i.getIssueType().name())) {
				
				Map<String,Object>data=new LinkedHashMap<>();
				data.put("epic", i);
				data.put("stories", new ArrayList<Issue>());
				data.put("subtask", new HashMap<Long,List<Issue>>());
				epicMap.put(i.getId(), data);
				
			}
			
			
		}
		
		
		
		for(Issue i:backLog) {
			
			if(i.getIssueType()  != null && "STORY".equalsIgnoreCase(i.getIssueType().name())){
				Long eId= i.getEpicId();
				
				if(eId != null && epicMap.containsKey(eId) ) {
					List<Issue> stories= (List<Issue>)epicMap.get(eId).get("stories");
					stories.add(i);
				}
			}
		}
		
		
		
		for(Issue i :backLog) {
			
			if(i.getIssueType() !=null && "SUBTASK".equalsIgnoreCase(i.getIssueType().name()) ) {
				
				Issue parent = i.getSourceIssue();
				
				if(parent != null) continue;
				
					
					for(Map<String,Object> epicDate:epicMap.values() ) {
						
						List<Issue> stories= (List<Issue>)epicDate.get("stories");
						
						
						for(Issue story:stories) {
							if(story.getId().equals(parent)) {
								
								
								Map<Long,List<Issue>>subMap= (Map<Long,List<Issue>>)epicDate.get("subTasks");
								
								List<Issue>subTasks = subMap.get(parent.getId());
								if(subTasks == null) {
									subTasks= new ArrayList<>();
									subMap.put(parent.getId(), subTasks);
								}
								subTasks.add(i);
								
								break;
							}
							
						}
						
					}
					
				}
				
			}
		return Collections.singletonMap("epics", epicMap);
	}
}
