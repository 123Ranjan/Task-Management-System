package com.TaskManagement.Service;

import com.TaskManagement.Entity.IssueLink;
import com.TaskManagement.Repository.IssueLinkRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class IssueLinkService {

	private final IssueLinkRepository issueLinkRepository;

	public IssueLink createLink(Long sourceId, Long targetId, String linkType) {

		IssueLink link = new IssueLink();
		link.setSourceIssueId(sourceId);
		link.setTargetIssueId(targetId);
		link.setLinkType(linkType);

		return issueLinkRepository.save(link);
	}

	public List<IssueLink> getLinksBySource(Long sourceId) {
		return issueLinkRepository.findBySourceIssueId(sourceId);
	}

	public List<IssueLink> getLinksByTarget(Long targetId) {
		return issueLinkRepository.findByTargetIssueId(targetId);
	}

	public void deleteLink(Long id) {
		issueLinkRepository.deleteById(id);
	}
}
