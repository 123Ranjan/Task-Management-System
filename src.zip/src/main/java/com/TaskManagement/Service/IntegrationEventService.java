package com.TaskManagement.Service;

import com.TaskManagement.Entity.IntegrationEvent;
import com.TaskManagement.Repository.IntegrationEventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IntegrationEventService {
    @Autowired
    private IntegrationEventRepository integrationEventRepository;

    public IntegrationEvent saveEvent(IntegrationEvent event) {
        return integrationEventRepository.save(event);
    }

    public List<IntegrationEvent> getEventsByIssueKey(String issueKey) {
        return integrationEventRepository.findByIssueKey(issueKey);
    }
}
