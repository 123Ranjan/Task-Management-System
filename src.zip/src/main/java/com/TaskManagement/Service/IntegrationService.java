package com.TaskManagement.Service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManagement.Client.IssueClient;
import com.TaskManagement.Entity.IntegrationEvent;
import com.TaskManagement.Enum.IssueStatus;
import com.TaskManagement.Service.IntegrationEventService;

@Service
public class IntegrationService {
	
	@Autowired
	private IssueClient issueclient;
	
	@Autowired
	private IntegrationEventService integrationEventService;

	public void handleCommitMessage(String commitMsg,String author) {
		String regex = "([A-Z]+-\\d+)";
		Matcher matcher= java.util.regex.Pattern.compile(regex).matcher(commitMsg);
		
		if(matcher.find()) {
			String issueKey = matcher.group(1);
			
			Long issueId= Long.valueOf(issueKey.split("-")[1]);
			
			try {
				issueclient.status(issueId,IssueStatus.DONE, author);
				issueclient.commit(issueId, author, "Automarically close by commit:"+commitMsg);
			} catch (Exception e) {
				System.err.println("[IntegrationService] Error updating issue status/commit: " + e.getMessage());
			}
			integrationEventService.saveEvent(new IntegrationEvent(issueKey, "commit", commitMsg, author));
		}
}
	
	public void handlePullRequest(String title,String author) {
        String regex = "([A-Z]+-\\d+)";
        Matcher matcher= java.util.regex.Pattern.compile(regex).matcher(title);
        String issueKey = null;
        Long issueId = null;
        if(matcher.find()) {
            issueKey = matcher.group(1);
            try {
                issueId = Long.valueOf(issueKey.split("-")[1]);
                issueclient.status(issueId,IssueStatus.IN_PROGRESS , issueKey);
                issueclient.commit(issueId, author, "Pull Request opened:"+title);
            } catch (Exception e) {
                System.err.println("[IntegrationService] Error updating issue status/commit: " + e.getMessage());
            }
        } else {
            System.err.println("[IntegrationService] Could not extract issue key from pull request title: " + title);
        }
        // Always save the event, even if issueKey is null
        integrationEventService.saveEvent(new IntegrationEvent(issueKey != null ? issueKey : "UNKNOWN", "pullRequest", title, author));
}
	
	public void processGithubEvent(String event,Map<String,Object>payload) {
		
		if(event.equals("PUSH")){

			
			Object commitObj  = payload.get("commits");
			if(!(commitObj instanceof List)) {
				System.out.println("No commits found");
				return;
			}
			
			List<?> commits= (List<?>)commitObj;
			
			for(Object obj :commits ) {
				
				if(!(obj instanceof Map)) continue;
				
				Map<String,Object> c = (Map<String,Object>)obj;
				
				String msg = (String) c.get("message");
				
				Map<String,Object> authorMap = (Map<String,Object>) c.get("author");
				String author = authorMap !=null ?(String)authorMap.get("name"): "Unknown";
				try {
					extractIssueKeyAndUpdate(msg,author);
				} catch (Exception e) {
					System.err.println("[IntegrationService] Error in extractIssueKeyAndUpdate: " + e.getMessage());
				}
				// Save event regardless
				String issueKey = extractIssueKey(msg);
				if(issueKey != null) {
					integrationEventService.saveEvent(new IntegrationEvent(issueKey, "github", msg, author));
				}
			}
		}
		
		else if("Pull_Request".equals(event)) {
			Object prObj= payload.get("Pull_Request");
			
			if(!(prObj instanceof Map) ) {
				System.out.println("No pull_request found in payload");
				return;
			}
			
			Map<String,Object> pr =(Map<String,Object>)prObj;
			String title = (String)pr.get("title");
			
			
			Map<String,Object>userMap= (Map<String,Object>)pr.getOrDefault("user",Map.class);
			
			String author = (String)userMap.getOrDefault("login", "Unknown");
			try {
				extractIssueKeyandMoveInprogress(title,author);
			} catch (Exception e) {
				System.err.println("[IntegrationService] Error in extractIssueKeyandMoveInprogress: " + e.getMessage());
			}
			String issueKey = extractIssueKey(title);
			if(issueKey != null) {
				integrationEventService.saveEvent(new IntegrationEvent(issueKey, "github_pull_request", title, author));
			}
		}
	}
	
	
	
	private void extractIssueKeyAndUpdate(String commitMsg,String user) {
		
		String regex = "([A-Z]+-\\d+)";
		Matcher m = Pattern.compile(regex).matcher(commitMsg);
		
		
		if(m.find()) {
			Long issueId = Long.parseLong(m.group(1).split("-")[1]);

			try {
				issueclient.status(issueId, IssueStatus.DONE, user);
				issueclient.commit(issueId, user, "Auto_closed via commit"+commitMsg);
			} catch (Exception e) {
				System.err.println("[IntegrationService] Error updating issue status/commit: " + e.getMessage());
			}
		}
	}

	
	private void extractIssueKeyandMoveInprogress(String title, String user) {
		
		String regex = "([A-Z]+-\\d+)";
		Matcher m = Pattern.compile(regex).matcher(title);
		
		if(m.find()) {
			
			Long issueId= Long.parseLong(m.group(1).split("-")[1]);
			try {
				issueclient.status(issueId, IssueStatus.IN_PROGRESS, user);
			} catch (Exception e) {
				System.err.println("[IntegrationService] Error updating issue status: " + e.getMessage());
			}
		}
	}
	
	
	public void processJenkinsEvent(Map<String,Object> body) {
		 
		String jobName = (String)body.get("name");
		String result = (String)body.get("result");
		String log = (String)body.get("log");
		
		Matcher m = Pattern.compile("([A-Z]+-\\d+)").matcher(jobName);
		
		if(m.find()) {
			String issueKey = m.group(1);
			Long issueId = Long.parseLong(issueKey.split("-")[1]);

			try {
				if(result.equals("FAILURE")) {
					issueclient.commit(issueId, "Jenkins", "Build Failed\n''''\n"+log+"\n''''");
				}
			} catch (Exception e) {
				System.err.println("[IntegrationService] Error updating Jenkins commit: " + e.getMessage());
			}
			if(result.equals("FAILURE")) {
				integrationEventService.saveEvent(new IntegrationEvent(issueKey, "jenkins", jobName + " | " + log, "jenkins"));
			}
		}
	}
	
	public void proceesDockerEvent(Map<String,Object>payload) {
		
		String status = (String) payload.get("status");
	    String image =(String) payload.get("from");
	    
	    Map<String,Object> actor=(Map<String,Object>) payload.get("Actor");
	    Map<String,Object> attributes=actor !=null? (Map<String,Object>)actor.get("Attribute"):null;
	    
	    String containerName=attributes !=null? (String)attributes.get("Name"):"";
	    String imageName=attributes !=null? (String)attributes.get("image"):image;
	    
	    String issueKey=extractIssueKey(containerName+""+imageName);
	    
	    if(issueKey == null) {
	    	System.out.println("No issue key found in docker payload");
	    	return;
	    }
	    
	    Long issueId = Long.parseLong(issueKey.split("-")[1]);
	    try {
		    switch(status.toLowerCase()) {

		    case "start":

		    	issueclient.status(issueId, IssueStatus.DEPLOYMENT, "Docker");
		    	issueclient.commit(issueId, "Docker", "Container started |Image:" + imageName);
		    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Container started |Image:" + imageName, "docker"));
		    	break;

		    case "die":
		    	issueclient.status(issueId,IssueStatus.BLOCKS , "Docker");
		    	issueclient.commit(issueId, "Docker", "Container crashed|Image:"+imageName);
		    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Container crashed|Image:"+imageName, "docker"));
		    	break;


		    case "pull"	:
		    	issueclient.commit(issueId, "Docker", "Image pulled:"+imageName);
		    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Image pulled:"+imageName, "docker"));
		    	break;

		    case "build":

		    	issueclient.commit(issueId, "docker", "Docker image build :"+imageName);
		    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Docker image build :"+imageName, "docker"));
		    	break;

		    default:
		    	issueclient.commit(issueId, "Docker", "Docker Event:" +status+"|Image"+imageName);
		    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Docker Event:" +status+"|Image"+imageName, "docker"));
		    }
	    } catch (Exception e) {
	    	System.err.println("[IntegrationService] Error updating Docker event: " + e.getMessage());
	    	// Save event anyway
	    	integrationEventService.saveEvent(new IntegrationEvent(issueKey, "docker", "Docker Event (error):" +status+"|Image"+imageName, "docker"));
	    }
	}
	
	private String extractIssueKey(String text) {
		if(text == null) return null;
		
		Matcher matcher = Pattern.compile("[A-Z]+-\\d+").matcher(text);
		if(matcher.find()) {
			return matcher.group(1);
		}
		
		return null;
	}
}
