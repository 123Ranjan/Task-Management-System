package com.TaskManagement.Service;

import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.TaskManagement.DTO.EmailLogDTO;
import com.TaskManagement.Entity.Notification;
import com.TaskManagement.Repository.EmailLogRepository;
import com.TaskManagement.Repository.NotificationRepository;
import jakarta.mail.Message;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;


@Service
public class NotificationService {

    @Autowired
    private EmailLogRepository logRepo;

    @Autowired
    private NotificationRepository notificationRepo;


  public void sendEmail(EmailLogDTO dto) {
	  final String fromEmail = "example@gmail.com";
	  final String password = "";
  
	  Properties props = new Properties();
	  props.put("mail.smtp.host", "smtp.gmail.com");
	  props.put("mail.smtp.port", "587");
	  props.put("mail.smtp.auth", "true");
	  props.put("mail.smtp.starttls.enable", "true");
	  
	  Session session = Session.getInstance(props, new jakarta.mail.Authenticator() {
		  protected PasswordAuthentication getPasswordAuthentication() {
		  return new PasswordAuthentication(fromEmail, password);
		  }
	  });
	  	
	  try {
		  Message msg = new MimeMessage(session);
		  msg.setFrom(new InternetAddress(fromEmail));
		  msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(dto.getRecipientEmail()));
		  msg.setSubject(dto.getSubject());
		  msg.setText(dto.getBody());
		  
		  Transport.send(msg);
		  System.out.println("Email sent successfully");
		  
	  } catch (Exception e) {
		  throw new RuntimeException("Failed to send an email", e);
	  }
	  
  }

  public void createNotification(String recipientEmail, String message) {
      Notification notification = Notification.builder()
          .recipientEmail(recipientEmail)
          .message(message)
          .readStatus(false)
          .createdAt(java.time.LocalDateTime.now())
          .build();
      notificationRepo.save(notification);
  }

  public List<Notification> getNotificationsForUser(String recipientEmail) {
      return notificationRepo.findByRecipientEmailOrderByCreatedAtDesc(recipientEmail);
  }

  public void markAsRead(Long id, String recipientEmail) {
      Notification notification = notificationRepo.findById(id)
          .filter(n -> n.getRecipientEmail().equals(recipientEmail))
          .orElseThrow(() -> new RuntimeException("Notification not found or not authorized"));
      notification.setReadStatus(true);
      notificationRepo.save(notification);
  }

  public void markAllAsRead(String recipientEmail) {
      List<Notification> notifications = notificationRepo.findByRecipientEmailOrderByCreatedAtDesc(recipientEmail);
      for (Notification n : notifications) {
          n.setReadStatus(true);
      }
      notificationRepo.saveAll(notifications);
  }

  public void deleteNotification(Long id, String recipientEmail) {
      Notification notification = notificationRepo.findById(id)
          .filter(n -> n.getRecipientEmail().equals(recipientEmail))
          .orElseThrow(() -> new RuntimeException("Notification not found or not authorized"));
      notificationRepo.delete(notification);
  }

  public int getUnreadCountForUser(String recipientEmail) {
      return notificationRepo.countByRecipientEmailAndReadStatusFalse(recipientEmail);
  }

}
