package com.TaskManagement.Service;

import java.io.InputStream;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.TaskManagement.Entity.Attachment;
import com.TaskManagement.Repository.AttachmentRepository;

import jakarta.transaction.Transactional;

@Service
public class AttachmentService {

    @Autowired
    private AttachmentRepository attachmentRepo;

    @Autowired
    private SupabaseStorageService supabaseStorageService;

    @Transactional
    public Attachment upload(Long issueId, MultipartFile file, String uploadedBy) {
        String storagePath = supabaseStorageService.upload(file, "issue-" + issueId);
        Attachment attach = new Attachment();
        attach.setIssueId(issueId);
        attach.setFileName(file.getOriginalFilename());
        attach.setContentType(file.getContentType());
        attach.setFileSize(file.getSize());
        attach.setStoragePath(storagePath);
        attach.setUploadedBy(uploadedBy);
        return attachmentRepo.save(attach);
    }

    public InputStream downloadStream(Long id) {
        Attachment attach = attachmentRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Attachment not found with id: " + id));
        return supabaseStorageService.download(attach.getStoragePath());
    }

    public String getDownloadFilename(Long id) {
        return attachmentRepo.findById(id).map(Attachment::getFileName)
                .orElse("file.pdf");
    }

    public String getContentType(Long id) {
        return attachmentRepo.findById(id).map(Attachment::getContentType)
                .orElse("application/pdf");
    }

    public List<Attachment> listForIssue(Long issueId) {
        return attachmentRepo.findByIssueId(issueId);
    }

    @Transactional
    public void delete(Long id) {
        Attachment attach = attachmentRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Attachment not found"));
        // Delete from Supabase Storage
        if (attach.getStoragePath() != null) {
            supabaseStorageService.delete(attach.getStoragePath());
        }
        attachmentRepo.deleteById(id);
    }

    @Transactional
    public void deleteAttachmentFromDatabase(Long attachmentId) {
        Attachment attachment = attachmentRepo.findById(attachmentId)
                .orElseThrow(() -> new RuntimeException("Attachment not found"));
        if (attachment.getStoragePath() != null) {
            supabaseStorageService.delete(attachment.getStoragePath());
        }
        attachmentRepo.delete(attachment);
    }

    public String getStoragePath(Long id) {
        Attachment attach = attachmentRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Attachment not found"));
        return attach.getStoragePath();
    }
}
