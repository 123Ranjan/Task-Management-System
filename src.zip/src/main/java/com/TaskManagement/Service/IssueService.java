package com.TaskManagement.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.TaskManagement.Client.UserClient;
import com.TaskManagement.DTO.IssueDTO;
import com.TaskManagement.Entity.Issue;
import com.TaskManagement.Entity.IssueComments;
import com.TaskManagement.Entity.Label;
import com.TaskManagement.Entity.Sprint;
import com.TaskManagement.Enum.IssueStatus;
import com.TaskManagement.Enum.Role;
import com.TaskManagement.Enum.IssueType;
import com.TaskManagement.Enum.IssuePriority;
import com.TaskManagement.Repository.BoardCardRepository;
import com.TaskManagement.Repository.IssueCommentRepository;
import com.TaskManagement.Repository.IssueLinkRepository;
import com.TaskManagement.Repository.IssueRepository;
import com.TaskManagement.Repository.LabelRepository;
import com.TaskManagement.Repository.SprintRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class IssueService {
	
	@Autowired
	private IssueRepository issueRepo;
	
	@Autowired
	private LabelRepository labelRepo;
	
	@Autowired
	private SprintRepository sprintRepo;
	
	@Autowired
	private IssueCommentRepository issueCommentRepo;
	
	@Autowired
	private WorkFlowService workFlowService;
	@Autowired
	private UserClient userClient;
	
	@Autowired
	private BoardCardRepository boardCardRepo;

	@Autowired
	private IssueLinkRepository issueLinkRepo;

	@Autowired
	private NotificationService notificationService;

	public IssueService(IssueRepository issueRepo,LabelRepository lableRepo,SprintRepository sprintRepo,IssueCommentRepository issueCommentRepo) {
		this.issueRepo=issueRepo;
		this.labelRepo=lableRepo;
		this.sprintRepo=sprintRepo;
		this.issueCommentRepo=issueCommentRepo;
	}
	private String generateKey(Long id) {
		return "PROJ-"+id;
	}

	@Transactional
	public IssueDTO createIssue(IssueDTO dto) {
		Issue  issue = new Issue();
		
		// Generate a temporary key first, then update after save with actual ID
		issue.setIssueKey("TEMP-" + System.currentTimeMillis());

		// Map fields with safe defaults
		issue.setIssueTitle(dto.getIssueTitle() != null ? dto.getIssueTitle() : "Untitled");
		issue.setIssueDescription(dto.getIssueDescription());
		issue.setIssueType(dto.getIssueType() != null ? dto.getIssueType() : IssueType.TASK);
		issue.setIssuePriority(dto.getIssuePriority() != null ? dto.getIssuePriority() : IssuePriority.MEDIUM);

		// Default status
		IssueStatus statusToSet = dto.getIssueStatus() != null ? dto.getIssueStatus() : IssueStatus.TODO;
		issue.setIssueStatus(statusToSet);

		// Reporter email - if null will remain null; controller tries to set from header
		issue.setReporterEmail(dto.getReporterEmail());

		// Prevent assigning to reporter
		if(dto.getAssignedEmail() != null && dto.getReporterEmail() != null && dto.getAssignedEmail().equals(dto.getReporterEmail())) {
			throw new RuntimeException("Cannot assign issue to the reporter");
		}
		// Notify assignee if assigned
		if(dto.getAssignedEmail() != null && !dto.getAssignedEmail().isEmpty()) {
			notificationService.createNotification(
				dto.getAssignedEmail(),
				"You have been assigned a new issue: " + (dto.getIssueTitle() != null ? dto.getIssueTitle() : "Untitled")
			);
		}
		issue.setAssignedEmail(dto.getAssignedEmail());
		issue.setDueDate(dto.getDueDate());
		issue.setProjectId(dto.getProjectId());

		if(dto.getLabels() != null) {
			for(String labelName : dto.getLabels()) {
				Label label = labelRepo.findByLabelName(labelName).orElse(null);
				if(label == null) {
					label = new Label(labelName);
					labelRepo.save(label);
				}
				issue.getLabels().add(label);
			}
		}
		
		Issue savedIssue = issueRepo.save(issue);
		// Now update with proper key using the generated ID
		savedIssue.setIssueKey(generateKey(savedIssue.getId()));
		issueRepo.save(savedIssue);
		return toDTO(savedIssue);
	}
	
	
	public IssueDTO getById(Long id ) {
		Issue issue = issueRepo.findById(id).orElseThrow(()-> new RuntimeException("Issue not found"));
		return toDTO(issue);
	} 
	
	public List<IssueDTO>getByAssignedEmail(String assignedEmail){
		return issueRepo.findByAssignedEmail(assignedEmail).stream().map(this::toDTO).collect(Collectors.toList());
	}
	
	public List<IssueDTO>getBySprint(Long sprintId){
		return issueRepo.findBySprintId(sprintId).stream().map(this::toDTO).collect(Collectors.toList());
	}
	public List<IssueDTO>getByEpicId(Long epicId){
		return issueRepo.findByEpicId(epicId).stream().map(this::toDTO).collect(Collectors.toList());
	}
	
	@Transactional
	public IssueComments addComment(Long issueId, String authorEmail, String body) {
		Issue issue = issueRepo.findById(issueId).orElseThrow(() -> new RuntimeException("Issue not found"));
		IssueComments comment = new IssueComments();
		comment.setIssueId(issueId);
		comment.setAuthorEmail(authorEmail);
		comment.setBody(body); // This sets the 'Body' field in the entity

		issueCommentRepo.save(comment);
		return comment;
		
	}
	@Transactional
	public IssueDTO updateStatus(Long id,IssueStatus toStatus,String userOfficialEmail) {

		Issue issue = issueRepo.findById(id).orElseThrow(()-> new RuntimeException("Issue not found"));

		IssueStatus newStatus =IssueStatus.valueOf(userOfficialEmail);
		issue.setIssueStatus(newStatus);
		issue.setUpdatedAt(LocalDateTime.now());
		IssueStatus fromStatus=issue.getIssueStatus();
		Long workFlowId = issue.getWorkFlowId();
		if(workFlowId==null) {
			throw new RuntimeException("workFlow notassigned to issue");
		}
		Set<String> userRoleStrings = userClient.getRole(userOfficialEmail);
		Set<Role> userRole = userRoleStrings.stream()
				.map(Role::valueOf)
				.collect(Collectors.toSet());
		issue.setIssueStatus(toStatus);
		issueRepo.save(issue);
		addComment(id,userOfficialEmail,"Status changed from "+fromStatus+"->"+toStatus);
		return toDTO(issue);
	}

	@Transactional
	public Sprint createSprint(Sprint sprint) {
		return sprintRepo.save(sprint);
	}
	
	public List<IssueDTO>search(Map<String,String> filters){
		
		if(filters.containsKey("assign")) return getByAssignedEmail(filters.get("assign"));
		if(filters.containsKey("sprint")) {
			Long sprintId= Long.valueOf(filters.get("sprint"));
			
			return getBySprint(sprintId);
		}
		
		if(filters.containsKey("status")) {
			IssueStatus status= IssueStatus.valueOf(filters.get("status").toUpperCase() );
			
			return issueRepo.findByIssueStatus(status).stream().map(this::toDTO).collect(Collectors.toList());
		}
		
		return issueRepo.findAll().stream().map(this::toDTO).collect(Collectors.toList());
	}
	 
	public IssueDTO convertToDTO(Issue issue) {
		IssueDTO dto = new IssueDTO();
		dto.setId(issue.getId()); // Important: Set the ID so frontend can reference it
		dto.setIssueTitle(issue.getIssueTitle());
		dto.setIssueKey(issue.getIssueKey());
		dto.setIssueDescription(issue.getIssueDescription());
		dto.setIssueType(issue.getIssueType());
		dto.setIssuePriority(issue.getIssuePriority());
		dto.setIssueStatus(issue.getIssueStatus());
		dto.setAssignedEmail(issue.getAssignedEmail());
		dto.setReporterEmail(issue.getReporterEmail());
		dto.setEpicId(issue.getEpicId());
		dto.setSprintId(issue.getSprintId());
		dto.setProjectId(issue.getProjectId());
		dto.setCreatedAt(issue.getCreatedAt());
		dto.setDueDate(issue.getDueDate());
		dto.setUpdatedAt(issue.getUpdatedAt());
		dto.setWorkFlowId(issue.getWorkFlowId());
		dto.setSourceIssueId(issue.getSourceIssue() != null ? issue.getSourceIssue().getId() : null);
		dto.setTargetIssueId(issue.getTargetIssueId() != null ? issue.getTargetIssueId().getId() : null);
		dto.setBackLogPosition(issue.getBackLogPosition());

		// Safely handle labels - avoid lazy initialization exception
		try {
			if (issue.getLabels() != null && !issue.getLabels().isEmpty()) {
				dto.setLabels(issue.getLabels().stream().map(Label::getLabelName).collect(Collectors.toSet()));
			}
		} catch (Exception e) {
			// If labels can't be loaded, just skip them
			dto.setLabels(new java.util.HashSet<>());
		}

		return dto;
	}

	private IssueDTO toDTO(Issue issue) {
		return convertToDTO(issue);
	}

	public List<IssueComments> getComments(Long issueId) {
		// ensure issue exists
		issueRepo.findById(issueId).orElseThrow(() -> new RuntimeException("Issue not found"));
		return issueCommentRepo.findByIssueIdOrderByCreatedAt(issueId);
	}

	@Transactional
	public void deleteComment(Long issueId, Long commentId) {
		// ensure issue exists
		issueRepo.findById(issueId).orElseThrow(() -> new RuntimeException("Issue not found"));

		IssueComments comment = issueCommentRepo.findById(commentId)
				.orElseThrow(() -> new RuntimeException("Comment not found"));

		if (comment.getIssueId() == null || !comment.getIssueId().equals(issueId)) {
			throw new RuntimeException("Comment does not belong to this issue");
		}

		issueCommentRepo.delete(comment);
	}

	@Transactional
	public void deleteIssue(Long issueId) {
		// ensure issue exists
		issueRepo.findById(issueId).orElseThrow(() -> new RuntimeException("Issue not found"));

		// Remove board cards referencing this issue
		boardCardRepo.findByIssueId(issueId).ifPresent(boardCardRepo::delete);

		// Remove comments
		List<IssueComments> comments = issueCommentRepo.findByIssueIdOrderByCreatedAt(issueId);
		issueCommentRepo.deleteAll(comments);

		// Remove links (source/target)
		issueLinkRepo.deleteAll(issueLinkRepo.findBySourceIssueId(issueId));
		issueLinkRepo.deleteAll(issueLinkRepo.findByTargetIssueId(issueId));

		// Finally delete issue
		issueRepo.deleteById(issueId);
	}

	@Transactional
    public IssueDTO updateIssue(Long id, IssueDTO dto) {
        Issue issue = issueRepo.findById(id).orElseThrow(() -> new RuntimeException("Issue not found"));
        // Update fields
        if (dto.getIssueTitle() != null) issue.setIssueTitle(dto.getIssueTitle());
        if (dto.getIssueDescription() != null) issue.setIssueDescription(dto.getIssueDescription());
        if (dto.getIssueType() != null) issue.setIssueType(dto.getIssueType());
        if (dto.getIssuePriority() != null) issue.setIssuePriority(dto.getIssuePriority());
        if (dto.getIssueStatus() != null) issue.setIssueStatus(dto.getIssueStatus());
        if (dto.getAssignedEmail() != null) issue.setAssignedEmail(dto.getAssignedEmail());
        if (dto.getReporterEmail() != null) issue.setReporterEmail(dto.getReporterEmail());
        if (dto.getEpicId() != null) issue.setEpicId(dto.getEpicId());
        if (dto.getSprintId() != null) issue.setSprintId(dto.getSprintId());
        if (dto.getProjectId() != null) issue.setProjectId(dto.getProjectId());
        if (dto.getDueDate() != null) issue.setDueDate(dto.getDueDate());
        issue.setUpdatedAt(LocalDateTime.now());
        // Update labels
        if (dto.getLabels() != null) {
            issue.getLabels().clear();
            for (String labelName : dto.getLabels()) {
                Label label = labelRepo.findByLabelName(labelName).orElse(null);
                if (label == null) {
                    label = new Label(labelName);
                    labelRepo.save(label);
                }
                issue.getLabels().add(label);
            }
        }
        Issue updated = issueRepo.save(issue);
        return toDTO(updated);
    }

}
